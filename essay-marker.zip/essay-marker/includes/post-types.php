<?php
defined( 'ABSPATH' ) || exit;

/* We use custom DB tables instead of CPTs for assignments/submissions,
   but we register a lightweight CPT as a permalink anchor if needed. */

add_action( 'init', 'em_register_roles' );
function em_register_roles() {
    /* Add essay-related caps to editor/admin */
    $admin = get_role( 'administrator' );
    if ( $admin ) {
        $admin->add_cap( 'em_mark_essays' );
        $admin->add_cap( 'em_manage_assignments' );
        $admin->add_cap( 'em_view_all_submissions' );
    }
    $editor = get_role( 'editor' );
    if ( $editor ) {
        $editor->add_cap( 'em_mark_essays' );
        $editor->add_cap( 'em_manage_assignments' );
        $editor->add_cap( 'em_view_all_submissions' );
    }
}
