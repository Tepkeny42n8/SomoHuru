<?php
defined( 'ABSPATH' ) || exit;
/* Metaboxes are minimal — assignment management happens in the admin panel */
