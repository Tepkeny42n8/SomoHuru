<?php
defined( 'ABSPATH' ) || exit;

/* ================================================================
   [em_submit] — Student essay submission form
================================================================ */
add_shortcode( 'em_submit', 'em_shortcode_submit' );
function em_shortcode_submit( $atts ) {
    $atts        = shortcode_atts( array( 'assignment_id' => 0 ), $atts );
    $asgn_id     = (int) $atts['assignment_id'];

    if ( ! is_user_logged_in() ) {
        return '<div class="em-notice em-notice-warn">Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to submit an essay.</div>';
    }

    /* Build assignment list or single */
    if ( $asgn_id ) {
        $assignments = array( em_get_assignment( $asgn_id ) );
    } else {
        $assignments = em_get_assignments( array( 'status' => 'active' ) );
    }

    if ( empty( $assignments ) || ( count( $assignments ) === 1 && ! $assignments[0] ) ) {
        return '<div class="em-notice em-notice-info">No active assignments at this time.</div>';
    }

    ob_start();
    ?>
    <div class="em-wrap em-submit-wrap">
        <div class="em-assignment-selector" id="em-assignment-selector">
            <?php if ( ! $asgn_id ) : ?>
            <h2 class="em-h2">Choose an Assignment</h2>
            <div class="em-assignment-grid">
            <?php foreach ( $assignments as $a ) : if ( ! $a ) { continue; } ?>
                <div class="em-asgn-card" data-id="<?php echo $a->id; ?>">
                    <div class="em-asgn-card-head">
                        <h3><?php echo esc_html( $a->title ); ?></h3>
                        <?php if ( $a->due_date ) : ?>
                        <span class="em-due">Due: <?php echo esc_html( date( 'j M Y', strtotime( $a->due_date ) ) ); ?></span>
                        <?php endif; ?>
                    </div>
                    <p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $a->description ), 25 ) ); ?></p>
                    <div class="em-asgn-meta">
                        <?php if ( $a->word_min || $a->word_max ) : ?>
                        <span>&#128221; <?php
                        if ( $a->word_min && $a->word_max ) { echo $a->word_min . '–' . $a->word_max . ' words'; }
                        elseif ( $a->word_min )             { echo 'Min ' . $a->word_min . ' words'; }
                        else                                { echo 'Max ' . $a->word_max . ' words'; }
                        ?></span>
                        <?php endif; ?>
                        <span>&#9733; <?php echo $a->max_score; ?> marks</span>
                    </div>
                    <button class="em-btn em-btn-primary em-select-asgn" data-id="<?php echo $a->id; ?>">Write Essay &rarr;</button>
                </div>
            <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="em-submit-form-wrap" id="em-submit-form-wrap" <?php echo $asgn_id ? '' : 'style="display:none"'; ?>>
            <?php
            $current_a = $asgn_id ? em_get_assignment( $asgn_id ) : null;
            $existing  = null;
            if ( $current_a ) {
                global $wpdb;
                $existing = $wpdb->get_row( $wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}em_submissions WHERE assignment_id=%d AND student_id=%d",
                    $current_a->id, get_current_user_id()
                ) );
            }
            ?>
            <?php if ( $existing ) : ?>
            <div class="em-notice em-notice-warn" style="margin-bottom:20px">
                You have already submitted this essay (<?php echo esc_html( date( 'j M Y', strtotime( $existing->submitted_at ) ) ); ?>).
                Submitting again will update your submission.
            </div>
            <?php endif; ?>

            <div class="em-assignment-brief" id="em-assignment-brief">
                <?php if ( $current_a ) : ?>
                <h2 class="em-h2"><?php echo esc_html( $current_a->title ); ?></h2>
                <?php if ( $current_a->description ) : ?>
                <div class="em-assignment-desc"><?php echo wp_kses_post( $current_a->description ); ?></div>
                <?php endif; ?>
                <div class="em-assignment-meta">
                    <?php if ( $current_a->due_date ) : ?>
                    <span>&#128197; Due: <?php echo esc_html( date( 'j M Y g:ia', strtotime( $current_a->due_date ) ) ); ?></span>
                    <?php endif; ?>
                    <?php if ( $current_a->word_min || $current_a->word_max ) : ?>
                    <span>&#128221; Word count: <?php
                    if ( $current_a->word_min && $current_a->word_max ) { echo $current_a->word_min . ' – ' . $current_a->word_max; }
                    elseif ( $current_a->word_min )                     { echo 'Min ' . $current_a->word_min; }
                    else                                                 { echo 'Max ' . $current_a->word_max; }
                    ?></span>
                    <?php endif; ?>
                    <span>&#9733; Max: <?php echo $current_a->max_score; ?> marks</span>
                </div>
                <?php endif; ?>
            </div>

            <form class="em-form" id="em-submit-form" novalidate>
                <input type="hidden" name="assignment_id" id="em-assignment-id" value="<?php echo $asgn_id; ?>">
                <input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'em_nonce' ) ); ?>">
                <input type="hidden" name="action" value="em_submit_essay">

                <div class="em-field">
                    <label for="em-essay-title">Essay Title <span class="em-optional">(optional)</span></label>
                    <input type="text" id="em-essay-title" name="title" placeholder="Give your essay a title..." value="<?php echo $existing ? esc_attr( $existing->title ) : ''; ?>">
                </div>

                <div class="em-field">
                    <label for="em-essay-content">Your Essay <span class="em-req">*</span></label>
                    <div class="em-editor-toolbar">
                        <button type="button" class="em-tb-btn" data-cmd="bold" title="Bold"><strong>B</strong></button>
                        <button type="button" class="em-tb-btn" data-cmd="italic" title="Italic"><em>I</em></button>
                        <button type="button" class="em-tb-btn" data-cmd="underline" title="Underline"><u>U</u></button>
                        <span class="em-tb-sep"></span>
                        <button type="button" class="em-tb-btn" data-cmd="insertUnorderedList" title="Bullet list">&#8226; List</button>
                        <button type="button" class="em-tb-btn" data-cmd="insertOrderedList" title="Numbered list">1. List</button>
                        <span class="em-word-count" id="em-wc">0 words</span>
                    </div>
                    <div class="em-editor" id="em-editor" contenteditable="true" spellcheck="true"><?php
                    if ( $existing ) { echo wp_kses_post( $existing->content ); }
                    ?></div>
                    <textarea name="content" id="em-content-hidden" style="display:none"></textarea>
                </div>

                <div class="em-submit-row">
                    <?php if ( ! $asgn_id ) : ?>
                    <button type="button" class="em-btn em-btn-ghost" id="em-back-btn">&larr; Back</button>
                    <?php endif; ?>
                    <button type="submit" class="em-btn em-btn-primary" id="em-submit-btn">
                        <span class="em-btn-text">Submit Essay</span>
                        <span class="em-spinner" style="display:none">&#8987;</span>
                    </button>
                </div>

                <div class="em-form-message" id="em-form-message" style="display:none"></div>
            </form>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/* ================================================================
   [em_my_essays] — Student dashboard
================================================================ */
add_shortcode( 'em_my_essays', 'em_shortcode_my_essays' );
function em_shortcode_my_essays() {
    if ( ! is_user_logged_in() ) {
        return '<div class="em-notice em-notice-warn">Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to view your essays.</div>';
    }
    $user_id     = get_current_user_id();
    $submissions = em_get_submissions( array( 'student_id' => $user_id, 'limit' => 30 ) );

    ob_start();
    ?>
    <div class="em-wrap em-dashboard-wrap">
        <div class="em-dashboard-header">
            <h2 class="em-h2">My Essays</h2>
            <a href="<?php echo esc_url( home_url( '/submit-essay/' ) ); ?>" class="em-btn em-btn-primary">+ New Essay</a>
        </div>

        <?php if ( empty( $submissions ) ) : ?>
        <div class="em-empty">
            <div class="em-empty-icon">&#128221;</div>
            <h3>No essays yet</h3>
            <p>Submit your first essay to get started.</p>
            <a href="<?php echo esc_url( home_url( '/submit-essay/' ) ); ?>" class="em-btn em-btn-primary">Submit an Essay</a>
        </div>
        <?php else : ?>
        <div class="em-submissions-list">
        <?php foreach ( $submissions as $sub ) :
            $assignment = em_get_assignment( $sub->assignment_id );
            $mark       = em_get_mark( $sub->id );
            $status_map = array( 'submitted' => array( 'Submitted', '#2563eb' ), 'resubmitted' => array( 'Resubmitted', '#7c3aed' ), 'marked' => array( 'Marked', '#16a34a' ), 'pending' => array( 'Pending', '#d97706' ) );
            $status     = isset( $status_map[ $sub->status ] ) ? $status_map[ $sub->status ] : array( ucfirst( $sub->status ), '#6b7280' );
        ?>
        <div class="em-sub-card">
            <div class="em-sub-card-head">
                <div>
                    <h3 class="em-sub-title"><?php echo esc_html( $sub->title ?: ( $assignment ? $assignment->title : 'Essay' ) ); ?></h3>
                    <?php if ( $assignment ) : ?>
                    <p class="em-sub-asgn"><?php echo esc_html( $assignment->title ); ?></p>
                    <?php endif; ?>
                </div>
                <span class="em-status-badge" style="background:<?php echo esc_attr( $status[1] ); ?>20;color:<?php echo esc_attr( $status[1] ); ?>"><?php echo esc_html( $status[0] ); ?></span>
            </div>
            <div class="em-sub-card-meta">
                <span>&#128197; <?php echo esc_html( date( 'j M Y', strtotime( $sub->submitted_at ) ) ); ?></span>
                <span>&#128221; <?php echo number_format( $sub->word_count ); ?> words</span>
                <?php if ( $mark ) : ?>
                <span class="em-score-pill" style="background:<?php echo esc_attr( em_grade_colour( $mark->grade ) ); ?>">
                    <?php echo $mark->grade; ?> &nbsp; <?php echo number_format( $mark->percentage, 1 ); ?>%
                </span>
                <?php endif; ?>
            </div>
            <div class="em-sub-card-actions">
                <?php if ( $mark ) : ?>
                <a href="<?php echo esc_url( home_url( '/essay-results/?sub=' . $sub->id ) ); ?>" class="em-btn em-btn-sm em-btn-outline">View Feedback</a>
                <?php else : ?>
                <span class="em-awaiting">&#9203; Awaiting marking</span>
                <?php endif; ?>
                <a href="<?php echo esc_url( home_url( '/submit-essay/?assignment_id=' . $sub->assignment_id ) ); ?>" class="em-btn em-btn-sm em-btn-ghost">Edit / Resubmit</a>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/* ================================================================
   [em_results] — Show feedback for a submission
================================================================ */
add_shortcode( 'em_results', 'em_shortcode_results' );
function em_shortcode_results() {
    if ( ! is_user_logged_in() ) {
        return '<div class="em-notice em-notice-warn">Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a>.</div>';
    }
    $sub_id = isset( $_GET['sub'] ) ? (int) $_GET['sub'] : 0;
    if ( ! $sub_id ) {
        return '<div class="em-notice em-notice-warn">No submission specified.</div>';
    }
    $sub = em_get_submission( $sub_id );
    if ( ! $sub || (int) $sub->student_id !== get_current_user_id() ) {
        return '<div class="em-notice em-notice-warn">Submission not found or access denied.</div>';
    }
    $assignment = em_get_assignment( $sub->assignment_id );
    $marks      = em_get_marks_for_submission( $sub_id );
    $comments   = em_get_inline_comments( $sub_id );
    $rubric     = $assignment ? em_get_rubric( $assignment ) : em_default_rubric();

    ob_start();
    ?>
    <div class="em-wrap em-results-wrap">
        <div class="em-results-header">
            <a href="<?php echo esc_url( home_url( '/my-essays/' ) ); ?>" class="em-back-link">&larr; My Essays</a>
            <h2 class="em-h2"><?php echo esc_html( $sub->title ?: ( $assignment ? $assignment->title : 'Essay Feedback' ) ); ?></h2>
            <?php if ( $assignment ) : ?>
            <p class="em-results-asgn">Assignment: <?php echo esc_html( $assignment->title ); ?> &nbsp;&bull;&nbsp; Submitted <?php echo esc_html( date( 'j M Y', strtotime( $sub->submitted_at ) ) ); ?></p>
            <?php endif; ?>
        </div>

        <?php if ( empty( $marks ) ) : ?>
        <div class="em-notice em-notice-info">Your essay has been submitted and is awaiting marking. Check back soon!</div>
        <?php else : ?>

        <?php foreach ( $marks as $mark ) :
            $type_label = $mark->marker_type === 'ai' ? '&#129302; AI Feedback' : '&#127979; Teacher Feedback';
            $scores     = json_decode( $mark->scores, true );
            if ( ! is_array( $scores ) ) { $scores = array(); }
            $mark_comments = array();
            foreach ( $comments as $c ) {
                if ( $c->marker_type === $mark->marker_type ) {
                    $mark_comments[] = $c;
                }
            }
        ?>
        <div class="em-feedback-block em-feedback-<?php echo esc_attr( $mark->marker_type ); ?>">
            <div class="em-feedback-header">
                <h3><?php echo $type_label; ?></h3>
                <div class="em-grade-display" style="--grade-color:<?php echo esc_attr( em_grade_colour( $mark->grade ) ); ?>">
                    <div class="em-grade-letter"><?php echo esc_html( $mark->grade ); ?></div>
                    <div class="em-grade-pct"><?php echo number_format( $mark->percentage, 1 ); ?>%</div>
                </div>
            </div>

            <!-- Rubric scores -->
            <div class="em-rubric-scores">
                <h4>Scores by Criterion</h4>
                <div class="em-rubric-grid">
                <?php foreach ( $rubric as $criterion ) :
                    $scored = isset( $scores[ $criterion['id'] ] ) ? (float) $scores[ $criterion['id'] ] : 0;
                    $pct    = $criterion['max'] > 0 ? ( $scored / $criterion['max'] ) * 100 : 0;
                ?>
                <div class="em-rubric-row">
                    <div class="em-rubric-info">
                        <span class="em-rubric-name"><?php echo esc_html( $criterion['name'] ); ?></span>
                        <span class="em-rubric-score"><?php echo number_format( $scored, 1 ); ?> / <?php echo $criterion['max']; ?></span>
                    </div>
                    <div class="em-progress-bar">
                        <div class="em-progress-fill" style="width:<?php echo min( 100, $pct ); ?>%;background:<?php echo esc_attr( em_grade_colour( em_percentage_to_grade( $pct ) ) ); ?>"></div>
                    </div>
                    <?php if ( $criterion['description'] ) : ?>
                    <p class="em-rubric-desc"><?php echo esc_html( $criterion['description'] ); ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
                </div>
            </div>

            <!-- Overall feedback -->
            <?php if ( $mark->overall_feedback ) : ?>
            <div class="em-feedback-section">
                <h4>&#128203; Overall Feedback</h4>
                <div class="em-feedback-text"><?php echo wp_kses_post( $mark->overall_feedback ); ?></div>
            </div>
            <?php endif; ?>

            <!-- Strengths / Improvements -->
            <div class="em-strengths-improvements">
                <?php if ( $mark->strengths ) : ?>
                <div class="em-si-card em-si-strengths">
                    <h4>&#9989; Strengths</h4>
                    <p><?php echo nl2br( esc_html( $mark->strengths ) ); ?></p>
                </div>
                <?php endif; ?>
                <?php if ( $mark->improvements ) : ?>
                <div class="em-si-card em-si-improvements">
                    <h4>&#128161; Areas to Improve</h4>
                    <p><?php echo nl2br( esc_html( $mark->improvements ) ); ?></p>
                </div>
                <?php endif; ?>
            </div>

            <!-- Inline comments -->
            <?php if ( ! empty( $mark_comments ) ) : ?>
            <div class="em-feedback-section">
                <h4>&#128172; Inline Comments</h4>
                <div class="em-inline-list">
                <?php foreach ( $mark_comments as $ic ) :
                    $type_icon = $ic->comment_type === 'praise' ? '&#9989;' : ( $ic->comment_type === 'error' ? '&#10060;' : '&#128172;' );
                ?>
                <div class="em-inline-item em-ic-<?php echo esc_attr( $ic->comment_type ); ?>">
                    <div class="em-ic-quote"><?php echo $type_icon; ?> "<?php echo esc_html( $ic->selected_text ); ?>"</div>
                    <p class="em-ic-text"><?php echo esc_html( $ic->comment_text ); ?></p>
                </div>
                <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>

        <!-- Essay text -->
        <div class="em-essay-body em-essay-readonly">
            <h3>Your Essay</h3>
            <div class="em-essay-content"><?php echo wp_kses_post( $sub->content ); ?></div>
        </div>

        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
