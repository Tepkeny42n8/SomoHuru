<?php
defined( 'ABSPATH' ) || exit;

/* ================================================================
   SUBMIT ESSAY
================================================================ */
add_action( 'wp_ajax_em_submit_essay',        'em_ajax_submit_essay' );
add_action( 'wp_ajax_nopriv_em_submit_essay', 'em_ajax_submit_essay' );
function em_ajax_submit_essay() {
    if ( ! wp_verify_nonce( $_POST['nonce'], 'em_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( 'You must be logged in to submit an essay.' );
    }
    $assignment_id = (int) $_POST['assignment_id'];
    $assignment    = em_get_assignment( $assignment_id );
    if ( ! $assignment ) {
        wp_send_json_error( 'Assignment not found.' );
    }
    $content    = isset( $_POST['content'] ) ? wp_kses_post( stripslashes( $_POST['content'] ) ) : '';
    $word_count = str_word_count( wp_strip_all_tags( $content ) );
    if ( $assignment->word_min > 0 && $word_count < $assignment->word_min ) {
        wp_send_json_error( 'Your essay is too short. Minimum ' . $assignment->word_min . ' words required. You have ' . $word_count . '.' );
    }
    if ( $assignment->word_max > 0 && $word_count > $assignment->word_max ) {
        wp_send_json_error( 'Your essay is too long. Maximum ' . $assignment->word_max . ' words allowed. You have ' . $word_count . '.' );
    }
    $sub_id = em_save_submission( array(
        'assignment_id' => $assignment_id,
        'title'         => isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '',
        'content'       => $content,
    ) );
    if ( ! $sub_id ) {
        wp_send_json_error( 'Failed to save submission. Please try again.' );
    }
    wp_send_json_success( array(
        'submission_id' => $sub_id,
        'word_count'    => $word_count,
        'message'       => 'Essay submitted successfully! Your teacher will review it shortly.',
        'redirect'      => home_url( '/my-essays/' ),
    ) );
}

/* ================================================================
   SAVE MARK (teacher)
================================================================ */
add_action( 'wp_ajax_em_save_mark', 'em_ajax_save_mark' );
function em_ajax_save_mark() {
    if ( ! wp_verify_nonce( $_POST['nonce'], 'em_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }
    if ( ! em_user_can_mark() ) {
        wp_send_json_error( 'Permission denied.' );
    }
    $submission_id = (int) $_POST['submission_id'];
    $submission    = em_get_submission( $submission_id );
    if ( ! $submission ) {
        wp_send_json_error( 'Submission not found.' );
    }
    $raw_scores = isset( $_POST['scores'] ) ? $_POST['scores'] : array();
    $scores     = array();
    foreach ( $raw_scores as $k => $v ) {
        $scores[ sanitize_key( $k ) ] = (float) $v;
    }
    $mark_id = em_save_mark( array(
        'submission_id'    => $submission_id,
        'assignment_id'    => $submission->assignment_id,
        'student_id'       => $submission->student_id,
        'marker_type'      => 'teacher',
        'scores'           => $scores,
        'overall_feedback' => isset( $_POST['overall_feedback'] ) ? wp_kses_post( stripslashes( $_POST['overall_feedback'] ) ) : '',
        'strengths'        => isset( $_POST['strengths'] ) ? sanitize_textarea_field( stripslashes( $_POST['strengths'] ) ) : '',
        'improvements'     => isset( $_POST['improvements'] ) ? sanitize_textarea_field( stripslashes( $_POST['improvements'] ) ) : '',
    ) );
    $mark = em_get_mark( $submission_id, 'teacher' );
    wp_send_json_success( array(
        'mark_id'    => $mark_id,
        'percentage' => $mark ? $mark->percentage : 0,
        'grade'      => $mark ? $mark->grade : '',
        'message'    => 'Essay marked successfully.',
    ) );
}

/* ================================================================
   ADD INLINE COMMENT
================================================================ */
add_action( 'wp_ajax_em_add_comment', 'em_ajax_add_comment' );
function em_ajax_add_comment() {
    if ( ! wp_verify_nonce( $_POST['nonce'], 'em_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }
    if ( ! em_user_can_mark() ) {
        wp_send_json_error( 'Permission denied.' );
    }
    $comment_id = em_save_inline_comment( array(
        'submission_id' => (int) $_POST['submission_id'],
        'mark_id'       => (int) ( isset( $_POST['mark_id'] ) ? $_POST['mark_id'] : 0 ),
        'selected_text' => isset( $_POST['selected_text'] ) ? sanitize_textarea_field( stripslashes( $_POST['selected_text'] ) ) : '',
        'comment_text'  => sanitize_textarea_field( stripslashes( $_POST['comment_text'] ) ),
        'char_start'    => isset( $_POST['char_start'] ) ? (int) $_POST['char_start'] : null,
        'char_end'      => isset( $_POST['char_end'] ) ? (int) $_POST['char_end'] : null,
        'comment_type'  => isset( $_POST['comment_type'] ) ? sanitize_key( $_POST['comment_type'] ) : 'comment',
        'marker_type'   => 'teacher',
    ) );
    wp_send_json_success( array( 'comment_id' => $comment_id ) );
}

/* ================================================================
   DELETE INLINE COMMENT
================================================================ */
add_action( 'wp_ajax_em_delete_comment', 'em_ajax_delete_comment' );
function em_ajax_delete_comment() {
    global $wpdb;
    if ( ! wp_verify_nonce( $_POST['nonce'], 'em_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }
    if ( ! em_user_can_mark() ) {
        wp_send_json_error( 'Permission denied.' );
    }
    $wpdb->delete( $wpdb->prefix . 'em_comments', array( 'id' => (int) $_POST['comment_id'] ) );
    wp_send_json_success();
}

/* ================================================================
   AI MARK ESSAY  (calls Claude API via Anthropic)
================================================================ */
add_action( 'wp_ajax_em_ai_mark', 'em_ajax_ai_mark' );
function em_ajax_ai_mark() {
    if ( ! wp_verify_nonce( $_POST['nonce'], 'em_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }
    if ( ! em_user_can_mark() ) {
        wp_send_json_error( 'Permission denied.' );
    }

    $submission_id = (int) $_POST['submission_id'];
    $submission    = em_get_submission( $submission_id );
    if ( ! $submission ) {
        wp_send_json_error( 'Submission not found.' );
    }

    $assignment = em_get_assignment( $submission->assignment_id );
    if ( ! $assignment ) {
        wp_send_json_error( 'Assignment not found.' );
    }

    $api_key = get_option( 'em_anthropic_api_key', '' );
    if ( empty( $api_key ) ) {
        wp_send_json_error( 'Anthropic API key not configured. Please add it in Essay Marker > Settings.' );
    }

    $rubric = em_get_rubric( $assignment );
    if ( empty( $rubric ) ) {
        $rubric = em_default_rubric();
    }

    /* Build rubric description for the prompt */
    $rubric_text = '';
    foreach ( $rubric as $criterion ) {
        $rubric_text .= '- ' . $criterion['name'] . ' (max ' . $criterion['max'] . ' points): ' . $criterion['description'] . "\n";
    }

    $essay_text = wp_strip_all_tags( $submission->content );

    $system_prompt = 'You are an expert essay marker. You will be given an essay and a marking rubric. Provide detailed, constructive feedback. Always respond ONLY with valid JSON — no preamble, no markdown code fences.';

    $user_prompt = "Assignment: " . $assignment->title . "\n\n";
    $user_prompt .= "Description: " . wp_strip_all_tags( $assignment->description ) . "\n\n";
    $user_prompt .= "Marking Rubric:\n" . $rubric_text . "\n";
    $user_prompt .= "Maximum total score: " . $assignment->max_score . "\n\n";
    $user_prompt .= "Essay to mark:\n---\n" . $essay_text . "\n---\n\n";
    $user_prompt .= 'Please return ONLY a JSON object with these exact keys:
{
  "scores": { "<criterion_id>": <numeric_score>, ... },
  "overall_feedback": "<detailed HTML feedback paragraph>",
  "strengths": "<2-3 specific strengths>",
  "improvements": "<2-3 specific areas for improvement>",
  "inline_comments": [
    { "selected_text": "<exact quote from essay, max 80 chars>", "comment_text": "<brief constructive note>", "comment_type": "comment|praise|error" }
  ]
}
Criterion IDs are: ' . implode( ', ', array_column( $rubric, 'id' ) ) . '.
Score each criterion out of its maximum. Be encouraging but honest. Inline comments array should have 3-6 items max.';

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
        'timeout' => 60,
        'headers' => array(
            'Content-Type'      => 'application/json',
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
        ),
        'body' => wp_json_encode( array(
            'model'      => 'claude-sonnet-4-20250514',
            'max_tokens' => 2000,
            'system'     => $system_prompt,
            'messages'   => array(
                array( 'role' => 'user', 'content' => $user_prompt ),
            ),
        ) ),
    ) );

    if ( is_wp_error( $response ) ) {
        wp_send_json_error( 'API request failed: ' . $response->get_error_message() );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( empty( $body['content'][0]['text'] ) ) {
        wp_send_json_error( 'Empty response from AI. Please try again.' );
    }

    $raw  = $body['content'][0]['text'];
    /* Strip any accidental fences */
    $raw  = preg_replace( '/^```json\s*/i', '', trim( $raw ) );
    $raw  = preg_replace( '/```\s*$/', '', $raw );
    $data = json_decode( trim( $raw ), true );

    if ( ! $data || ! isset( $data['scores'] ) ) {
        wp_send_json_error( 'AI returned invalid data. Raw: ' . esc_html( substr( $raw, 0, 200 ) ) );
    }

    /* Save the AI mark */
    $mark_id = em_save_mark( array(
        'submission_id'    => $submission_id,
        'assignment_id'    => $submission->assignment_id,
        'student_id'       => $submission->student_id,
        'marker_type'      => 'ai',
        'scores'           => $data['scores'],
        'overall_feedback' => isset( $data['overall_feedback'] ) ? $data['overall_feedback'] : '',
        'strengths'        => isset( $data['strengths'] ) ? $data['strengths'] : '',
        'improvements'     => isset( $data['improvements'] ) ? $data['improvements'] : '',
    ) );

    /* Save AI inline comments */
    if ( ! empty( $data['inline_comments'] ) && is_array( $data['inline_comments'] ) ) {
        foreach ( array_slice( $data['inline_comments'], 0, 8 ) as $ic ) {
            if ( ! empty( $ic['comment_text'] ) ) {
                em_save_inline_comment( array(
                    'submission_id' => $submission_id,
                    'mark_id'       => $mark_id,
                    'selected_text' => isset( $ic['selected_text'] ) ? $ic['selected_text'] : '',
                    'comment_text'  => $ic['comment_text'],
                    'comment_type'  => isset( $ic['comment_type'] ) ? $ic['comment_type'] : 'comment',
                    'marker_type'   => 'ai',
                ) );
            }
        }
    }

    $mark = em_get_mark( $submission_id, 'ai' );
    wp_send_json_success( array(
        'mark_id'          => $mark_id,
        'percentage'       => $mark ? $mark->percentage : 0,
        'grade'            => $mark ? $mark->grade : '',
        'total_score'      => $mark ? $mark->total_score : 0,
        'scores'           => $data['scores'],
        'overall_feedback' => isset( $data['overall_feedback'] ) ? $data['overall_feedback'] : '',
        'strengths'        => isset( $data['strengths'] ) ? $data['strengths'] : '',
        'improvements'     => isset( $data['improvements'] ) ? $data['improvements'] : '',
        'inline_comments'  => isset( $data['inline_comments'] ) ? $data['inline_comments'] : array(),
        'message'          => 'AI marking complete.',
    ) );
}

/* ================================================================
   LOAD SUBMISSION (for marking page)
================================================================ */
add_action( 'wp_ajax_em_load_submission', 'em_ajax_load_submission' );
function em_ajax_load_submission() {
    if ( ! wp_verify_nonce( $_POST['nonce'], 'em_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }
    if ( ! em_user_can_mark() ) {
        wp_send_json_error( 'Permission denied.' );
    }
    $sub = em_get_submission( (int) $_POST['submission_id'] );
    if ( ! $sub ) {
        wp_send_json_error( 'Not found.' );
    }
    $mark     = em_get_mark( $sub->id );
    $comments = em_get_inline_comments( $sub->id );
    $student  = get_userdata( $sub->student_id );
    wp_send_json_success( array(
        'submission' => $sub,
        'mark'       => $mark,
        'comments'   => $comments,
        'student'    => $student ? array( 'display_name' => $student->display_name, 'email' => $student->user_email ) : array(),
    ) );
}
