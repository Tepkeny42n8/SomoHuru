<?php
defined( 'ABSPATH' ) || exit;

function em_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    /* Assignments table — teachers create assignments with rubrics */
    dbDelta( "CREATE TABLE {$wpdb->prefix}em_assignments (
        id          bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        title       varchar(255) NOT NULL,
        description longtext,
        rubric      longtext COMMENT 'JSON: array of criteria objects',
        max_score   int(11) NOT NULL DEFAULT 100,
        word_min    int(11) DEFAULT 0,
        word_max    int(11) DEFAULT 0,
        due_date    datetime DEFAULT NULL,
        course_id   bigint(20) UNSIGNED DEFAULT 0,
        created_by  bigint(20) UNSIGNED NOT NULL,
        status      varchar(20) NOT NULL DEFAULT 'active',
        created_at  datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY created_by (created_by),
        KEY status (status)
    ) $charset;" );

    /* Submissions table — student essay submissions */
    dbDelta( "CREATE TABLE {$wpdb->prefix}em_submissions (
        id            bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        assignment_id bigint(20) UNSIGNED NOT NULL,
        student_id    bigint(20) UNSIGNED NOT NULL,
        title         varchar(255),
        content       longtext NOT NULL,
        word_count    int(11) DEFAULT 0,
        status        varchar(30) NOT NULL DEFAULT 'submitted',
        submitted_at  datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY assignment_id (assignment_id),
        KEY student_id (student_id),
        KEY status (status)
    ) $charset;" );

    /* Marks table — teacher or AI feedback & scores */
    dbDelta( "CREATE TABLE {$wpdb->prefix}em_marks (
        id              bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        submission_id   bigint(20) UNSIGNED NOT NULL,
        assignment_id   bigint(20) UNSIGNED NOT NULL,
        student_id      bigint(20) UNSIGNED NOT NULL,
        marker_id       bigint(20) UNSIGNED NOT NULL DEFAULT 0,
        marker_type     varchar(20) NOT NULL DEFAULT 'teacher',
        scores          longtext COMMENT 'JSON: {criterion_id: score}',
        total_score     decimal(6,2) NOT NULL DEFAULT 0,
        percentage      decimal(5,2) NOT NULL DEFAULT 0,
        grade           varchar(10),
        overall_feedback longtext,
        strengths       text,
        improvements    text,
        marked_at       datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY one_mark_per_sub (submission_id, marker_type),
        KEY submission_id (submission_id),
        KEY student_id (student_id)
    ) $charset;" );

    /* Inline comments table — highlights on specific parts of the essay */
    dbDelta( "CREATE TABLE {$wpdb->prefix}em_comments (
        id            bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        submission_id bigint(20) UNSIGNED NOT NULL,
        mark_id       bigint(20) UNSIGNED NOT NULL DEFAULT 0,
        marker_id     bigint(20) UNSIGNED NOT NULL DEFAULT 0,
        marker_type   varchar(20) NOT NULL DEFAULT 'teacher',
        selected_text varchar(500),
        comment_text  text NOT NULL,
        char_start    int(11) DEFAULT NULL,
        char_end      int(11) DEFAULT NULL,
        comment_type  varchar(20) NOT NULL DEFAULT 'comment',
        created_at    datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY submission_id (submission_id),
        KEY mark_id (mark_id)
    ) $charset;" );
}
