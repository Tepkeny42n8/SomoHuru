<?php
defined( 'ABSPATH' ) || exit;

/* ================================================================
   ASSIGNMENTS
================================================================ */
function em_get_assignments( $args = array() ) {
    global $wpdb;
    $defaults = array( 'status' => 'active', 'limit' => 50, 'offset' => 0, 'course_id' => 0 );
    $args     = array_merge( $defaults, $args );
    $where    = 'WHERE 1=1';
    $params   = array();
    if ( $args['status'] ) {
        $where   .= ' AND status = %s';
        $params[] = $args['status'];
    }
    if ( $args['course_id'] ) {
        $where   .= ' AND course_id = %d';
        $params[] = (int) $args['course_id'];
    }
    $params[] = (int) $args['limit'];
    $params[] = (int) $args['offset'];
    $sql = "SELECT * FROM {$wpdb->prefix}em_assignments $where ORDER BY created_at DESC LIMIT %d OFFSET %d";
    return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
}

function em_get_assignment( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}em_assignments WHERE id = %d", $id ) );
}

function em_save_assignment( $data ) {
    global $wpdb;
    $row = array(
        'title'       => sanitize_text_field( $data['title'] ),
        'description' => wp_kses_post( $data['description'] ),
        'rubric'      => wp_json_encode( isset( $data['rubric'] ) ? $data['rubric'] : array() ),
        'max_score'   => (int) $data['max_score'],
        'word_min'    => (int) $data['word_min'],
        'word_max'    => (int) $data['word_max'],
        'due_date'    => ! empty( $data['due_date'] ) ? sanitize_text_field( $data['due_date'] ) : null,
        'course_id'   => (int) ( isset( $data['course_id'] ) ? $data['course_id'] : 0 ),
        'created_by'  => get_current_user_id(),
        'status'      => 'active',
    );
    if ( ! empty( $data['id'] ) ) {
        $wpdb->update( $wpdb->prefix . 'em_assignments', $row, array( 'id' => (int) $data['id'] ) );
        return (int) $data['id'];
    }
    $wpdb->insert( $wpdb->prefix . 'em_assignments', $row );
    return $wpdb->insert_id;
}

function em_get_rubric( $assignment ) {
    if ( is_numeric( $assignment ) ) {
        $assignment = em_get_assignment( $assignment );
    }
    if ( ! $assignment ) {
        return array();
    }
    $rubric = json_decode( $assignment->rubric, true );
    return is_array( $rubric ) ? $rubric : array();
}

/* ================================================================
   SUBMISSIONS
================================================================ */
function em_get_submissions( $args = array() ) {
    global $wpdb;
    $defaults = array( 'student_id' => 0, 'assignment_id' => 0, 'status' => '', 'limit' => 50, 'offset' => 0 );
    $args     = array_merge( $defaults, $args );
    $where    = 'WHERE 1=1';
    $params   = array();
    if ( $args['student_id'] ) {
        $where   .= ' AND student_id = %d';
        $params[] = (int) $args['student_id'];
    }
    if ( $args['assignment_id'] ) {
        $where   .= ' AND assignment_id = %d';
        $params[] = (int) $args['assignment_id'];
    }
    if ( $args['status'] ) {
        $where   .= ' AND status = %s';
        $params[] = $args['status'];
    }
    $params[] = (int) $args['limit'];
    $params[] = (int) $args['offset'];
    $sql = "SELECT * FROM {$wpdb->prefix}em_submissions $where ORDER BY submitted_at DESC LIMIT %d OFFSET %d";
    return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
}

function em_get_submission( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}em_submissions WHERE id = %d", $id ) );
}

function em_save_submission( $data ) {
    global $wpdb;
    $content    = wp_kses_post( $data['content'] );
    $word_count = str_word_count( wp_strip_all_tags( $content ) );
    $row = array(
        'assignment_id' => (int) $data['assignment_id'],
        'student_id'    => get_current_user_id(),
        'title'         => sanitize_text_field( isset( $data['title'] ) ? $data['title'] : '' ),
        'content'       => $content,
        'word_count'    => $word_count,
        'status'        => 'submitted',
        'submitted_at'  => current_time( 'mysql' ),
    );
    /* Check if already submitted — update instead */
    $existing = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}em_submissions WHERE assignment_id=%d AND student_id=%d",
        $row['assignment_id'], $row['student_id']
    ) );
    if ( $existing ) {
        $row['status'] = 'resubmitted';
        $wpdb->update( $wpdb->prefix . 'em_submissions', $row, array( 'id' => (int) $existing ) );
        return (int) $existing;
    }
    $wpdb->insert( $wpdb->prefix . 'em_submissions', $row );
    return $wpdb->insert_id;
}

/* ================================================================
   MARKS
================================================================ */
function em_get_mark( $submission_id, $marker_type = '' ) {
    global $wpdb;
    if ( $marker_type ) {
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}em_marks WHERE submission_id=%d AND marker_type=%s",
            $submission_id, $marker_type
        ) );
    }
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}em_marks WHERE submission_id=%d ORDER BY marked_at DESC",
        $submission_id
    ) );
}

function em_get_marks_for_submission( $submission_id ) {
    global $wpdb;
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}em_marks WHERE submission_id=%d ORDER BY marked_at DESC",
        $submission_id
    ) );
}

function em_save_mark( $data ) {
    global $wpdb;
    $scores     = isset( $data['scores'] ) ? $data['scores'] : array();
    $total      = 0;
    foreach ( $scores as $score ) {
        $total += (float) $score;
    }
    $assignment = em_get_assignment( $data['assignment_id'] );
    $max        = $assignment ? (float) $assignment->max_score : 100;
    $percentage = $max > 0 ? round( ( $total / $max ) * 100, 2 ) : 0;
    $grade      = em_percentage_to_grade( $percentage );
    $row = array(
        'submission_id'    => (int) $data['submission_id'],
        'assignment_id'    => (int) $data['assignment_id'],
        'student_id'       => (int) $data['student_id'],
        'marker_id'        => get_current_user_id(),
        'marker_type'      => sanitize_key( isset( $data['marker_type'] ) ? $data['marker_type'] : 'teacher' ),
        'scores'           => wp_json_encode( $scores ),
        'total_score'      => $total,
        'percentage'       => $percentage,
        'grade'            => $grade,
        'overall_feedback' => wp_kses_post( isset( $data['overall_feedback'] ) ? $data['overall_feedback'] : '' ),
        'strengths'        => sanitize_textarea_field( isset( $data['strengths'] ) ? $data['strengths'] : '' ),
        'improvements'     => sanitize_textarea_field( isset( $data['improvements'] ) ? $data['improvements'] : '' ),
        'marked_at'        => current_time( 'mysql' ),
    );
    $existing = em_get_mark( $row['submission_id'], $row['marker_type'] );
    if ( $existing ) {
        $wpdb->update( $wpdb->prefix . 'em_marks', $row, array( 'id' => $existing->id ) );
        /* Update submission status */
        $wpdb->update( $wpdb->prefix . 'em_submissions', array( 'status' => 'marked' ), array( 'id' => $row['submission_id'] ) );
        return $existing->id;
    }
    $wpdb->insert( $wpdb->prefix . 'em_marks', $row );
    $mark_id = $wpdb->insert_id;
    $wpdb->update( $wpdb->prefix . 'em_submissions', array( 'status' => 'marked' ), array( 'id' => $row['submission_id'] ) );
    return $mark_id;
}

/* ================================================================
   INLINE COMMENTS
================================================================ */
function em_get_inline_comments( $submission_id ) {
    global $wpdb;
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}em_comments WHERE submission_id=%d ORDER BY char_start ASC",
        $submission_id
    ) );
}

function em_save_inline_comment( $data ) {
    global $wpdb;
    $row = array(
        'submission_id' => (int) $data['submission_id'],
        'mark_id'       => (int) ( isset( $data['mark_id'] ) ? $data['mark_id'] : 0 ),
        'marker_id'     => get_current_user_id(),
        'marker_type'   => sanitize_key( isset( $data['marker_type'] ) ? $data['marker_type'] : 'teacher' ),
        'selected_text' => sanitize_textarea_field( isset( $data['selected_text'] ) ? $data['selected_text'] : '' ),
        'comment_text'  => sanitize_textarea_field( $data['comment_text'] ),
        'char_start'    => isset( $data['char_start'] ) ? (int) $data['char_start'] : null,
        'char_end'      => isset( $data['char_end'] ) ? (int) $data['char_end'] : null,
        'comment_type'  => sanitize_key( isset( $data['comment_type'] ) ? $data['comment_type'] : 'comment' ),
        'created_at'    => current_time( 'mysql' ),
    );
    $wpdb->insert( $wpdb->prefix . 'em_comments', $row );
    return $wpdb->insert_id;
}

/* ================================================================
   UTILITIES
================================================================ */
function em_percentage_to_grade( $pct ) {
    if ( $pct >= 80 ) { return 'A'; }
    if ( $pct >= 70 ) { return 'B'; }
    if ( $pct >= 60 ) { return 'C'; }
    if ( $pct >= 50 ) { return 'D'; }
    return 'E';
}

function em_grade_colour( $grade ) {
    $map = array( 'A' => '#16a34a', 'B' => '#2563eb', 'C' => '#d97706', 'D' => '#ea580c', 'E' => '#dc2626' );
    return isset( $map[ $grade ] ) ? $map[ $grade ] : '#6b7280';
}

function em_user_can_mark() {
    return current_user_can( 'em_mark_essays' ) || current_user_can( 'manage_options' );
}

function em_count_submissions( $assignment_id, $status = '' ) {
    global $wpdb;
    if ( $status ) {
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}em_submissions WHERE assignment_id=%d AND status=%s",
            $assignment_id, $status
        ) );
    }
    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}em_submissions WHERE assignment_id=%d",
        $assignment_id
    ) );
}

function em_default_rubric() {
    return array(
        array( 'id' => 'content',      'name' => 'Content & Ideas',        'description' => 'Relevance, depth and originality of ideas.',              'max' => 25 ),
        array( 'id' => 'structure',    'name' => 'Structure & Organisation','description' => 'Introduction, body paragraphs, and conclusion flow.',     'max' => 25 ),
        array( 'id' => 'language',     'name' => 'Language & Style',        'description' => 'Vocabulary, sentence variety and tone.',                  'max' => 25 ),
        array( 'id' => 'mechanics',    'name' => 'Grammar & Mechanics',     'description' => 'Spelling, punctuation and grammatical accuracy.',         'max' => 25 ),
    );
}
