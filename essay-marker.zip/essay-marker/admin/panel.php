<?php
defined( 'ABSPATH' ) || exit;

/* ================================================================
   ADMIN MENU
================================================================ */
add_action( 'admin_menu', 'em_admin_menu' );
function em_admin_menu() {
    add_menu_page(
        'Essay Marker',
        'Essay Marker',
        'manage_options',
        'essay-marker',
        'em_page_dashboard',
        'dashicons-edit-page',
        56
    );
    add_submenu_page( 'essay-marker', 'Dashboard',   'Dashboard',   'manage_options', 'essay-marker',              'em_page_dashboard' );
    add_submenu_page( 'essay-marker', 'Assignments',  'Assignments', 'manage_options', 'em-assignments',            'em_page_assignments' );
    add_submenu_page( 'essay-marker', 'Submissions',  'Submissions', 'manage_options', 'em-submissions',            'em_page_submissions' );
    add_submenu_page( 'essay-marker', 'Mark Essay',   'Mark Essay',  'manage_options', 'em-mark',                   'em_page_mark' );
    add_submenu_page( 'essay-marker', 'Settings',     'Settings',    'manage_options', 'em-settings',               'em_page_settings' );
}

/* ================================================================
   SAVE HANDLERS
================================================================ */
add_action( 'admin_init', 'em_admin_handle_forms' );
function em_admin_handle_forms() {
    /* Save assignment */
    if ( isset( $_POST['em_save_assignment'] ) && check_admin_referer( 'em_save_assignment' ) ) {
        $rubric = array();
        if ( ! empty( $_POST['rubric_id'] ) ) {
            foreach ( $_POST['rubric_id'] as $i => $rid ) {
                $rubric[] = array(
                    'id'          => sanitize_key( $rid ),
                    'name'        => sanitize_text_field( $_POST['rubric_name'][ $i ] ),
                    'description' => sanitize_textarea_field( $_POST['rubric_desc'][ $i ] ),
                    'max'         => (int) $_POST['rubric_max'][ $i ],
                );
            }
        }
        em_save_assignment( array_merge( $_POST, array( 'rubric' => $rubric ) ) );
        wp_redirect( admin_url( 'admin.php?page=em-assignments&saved=1' ) );
        exit;
    }

    /* Delete assignment */
    if ( isset( $_GET['em_delete_asgn'] ) && check_admin_referer( 'em_delete_asgn' ) ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'em_assignments', array( 'id' => (int) $_GET['em_delete_asgn'] ) );
        wp_redirect( admin_url( 'admin.php?page=em-assignments&deleted=1' ) );
        exit;
    }

    /* Save settings */
    if ( isset( $_POST['em_save_settings'] ) && check_admin_referer( 'em_save_settings' ) ) {
        update_option( 'em_anthropic_api_key', sanitize_text_field( $_POST['em_anthropic_api_key'] ) );
        update_option( 'em_ai_enabled',        isset( $_POST['em_ai_enabled'] ) ? 1 : 0 );
        wp_redirect( admin_url( 'admin.php?page=em-settings&saved=1' ) );
        exit;
    }
}

/* ================================================================
   DASHBOARD PAGE
================================================================ */
function em_page_dashboard() {
    global $wpdb;
    $total_assignments = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}em_assignments" );
    $total_submissions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}em_submissions" );
    $pending           = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}em_submissions WHERE status='submitted' OR status='resubmitted'" );
    $marked            = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}em_submissions WHERE status='marked'" );
    $ai_marks          = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}em_marks WHERE marker_type='ai'" );
    $avg_pct           = (float) $wpdb->get_var( "SELECT AVG(percentage) FROM {$wpdb->prefix}em_marks" );
    $recent            = $wpdb->get_results( "SELECT s.*, a.title as asgn_title FROM {$wpdb->prefix}em_submissions s LEFT JOIN {$wpdb->prefix}em_assignments a ON s.assignment_id=a.id ORDER BY s.submitted_at DESC LIMIT 8" );
    ?>
    <div class="wrap em-admin-wrap">
    <h1 class="em-admin-title">&#128221; Essay Marker — Dashboard</h1>
    <div class="em-stat-cards">
        <div class="em-stat-card"><div class="em-stat-num"><?php echo $total_assignments; ?></div><div class="em-stat-lbl">Assignments</div></div>
        <div class="em-stat-card"><div class="em-stat-num"><?php echo $total_submissions; ?></div><div class="em-stat-lbl">Submissions</div></div>
        <div class="em-stat-card em-stat-warn"><div class="em-stat-num"><?php echo $pending; ?></div><div class="em-stat-lbl">Awaiting Marking</div></div>
        <div class="em-stat-card em-stat-success"><div class="em-stat-num"><?php echo $marked; ?></div><div class="em-stat-lbl">Marked</div></div>
        <div class="em-stat-card em-stat-ai"><div class="em-stat-num"><?php echo $ai_marks; ?></div><div class="em-stat-lbl">AI Marks</div></div>
        <div class="em-stat-card"><div class="em-stat-num"><?php echo $avg_pct > 0 ? number_format( $avg_pct, 1 ) . '%' : '—'; ?></div><div class="em-stat-lbl">Average Score</div></div>
    </div>

    <div class="em-admin-actions">
        <a href="<?php echo admin_url( 'admin.php?page=em-assignments&action=new' ); ?>" class="button button-primary">+ New Assignment</a>
        <a href="<?php echo admin_url( 'admin.php?page=em-submissions' ); ?>" class="button">View All Submissions</a>
    </div>

    <h2 class="em-admin-subtitle">Recent Submissions</h2>
    <table class="wp-list-table widefat fixed striped em-table">
        <thead><tr>
            <th>Student</th><th>Essay</th><th>Assignment</th><th>Words</th><th>Status</th><th>Submitted</th><th>Action</th>
        </tr></thead>
        <tbody>
        <?php if ( empty( $recent ) ) : ?>
        <tr><td colspan="7" style="text-align:center;padding:20px;color:#888">No submissions yet.</td></tr>
        <?php else : ?>
        <?php foreach ( $recent as $row ) :
            $student = get_userdata( $row->student_id );
            $mark    = em_get_mark( $row->id );
        ?>
        <tr>
            <td><?php echo $student ? esc_html( $student->display_name ) : 'Unknown'; ?></td>
            <td><?php echo esc_html( $row->title ?: '(untitled)' ); ?></td>
            <td><?php echo esc_html( $row->asgn_title ); ?></td>
            <td><?php echo number_format( $row->word_count ); ?></td>
            <td>
                <?php if ( $mark ) : ?>
                <span class="em-admin-grade" style="background:<?php echo esc_attr( em_grade_colour( $mark->grade ) ); ?>"><?php echo esc_html( $mark->grade ); ?> <?php echo number_format( $mark->percentage, 1 ); ?>%</span>
                <?php else : ?>
                <span class="em-admin-pending">Pending</span>
                <?php endif; ?>
            </td>
            <td><?php echo esc_html( date( 'j M Y', strtotime( $row->submitted_at ) ) ); ?></td>
            <td><a href="<?php echo admin_url( 'admin.php?page=em-mark&sub=' . $row->id ); ?>" class="button button-small"><?php echo $mark ? 'Review' : 'Mark'; ?></a></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
    <?php
}

/* ================================================================
   ASSIGNMENTS PAGE
================================================================ */
function em_page_assignments() {
    $action = isset( $_GET['action'] ) ? $_GET['action'] : 'list';
    $edit_a = ( $action === 'edit' && isset( $_GET['id'] ) ) ? em_get_assignment( (int) $_GET['id'] ) : null;
    $is_new = $action === 'new' || $action === 'edit';

    if ( isset( $_GET['saved'] ) ) {
        echo '<div class="notice notice-success"><p>Assignment saved.</p></div>';
    }
    if ( isset( $_GET['deleted'] ) ) {
        echo '<div class="notice notice-success"><p>Assignment deleted.</p></div>';
    }

    if ( $is_new ) :
        $rubric = $edit_a ? em_get_rubric( $edit_a ) : em_default_rubric();
        ?>
        <div class="wrap em-admin-wrap">
        <h1><?php echo $edit_a ? 'Edit Assignment' : 'New Assignment'; ?></h1>
        <form method="post" class="em-admin-form">
            <?php wp_nonce_field( 'em_save_assignment' ); ?>
            <input type="hidden" name="id" value="<?php echo $edit_a ? $edit_a->id : ''; ?>">
            <input type="hidden" name="em_save_assignment" value="1">

            <table class="form-table">
                <tr><th>Title <span style="color:red">*</span></th><td><input type="text" name="title" class="regular-text" required value="<?php echo $edit_a ? esc_attr( $edit_a->title ) : ''; ?>"></td></tr>
                <tr><th>Description / Task</th><td><?php wp_editor( $edit_a ? $edit_a->description : '', 'description', array( 'textarea_name' => 'description', 'editor_height' => 200 ) ); ?></td></tr>
                <tr><th>Maximum Score</th><td><input type="number" name="max_score" value="<?php echo $edit_a ? $edit_a->max_score : 100; ?>" min="1" max="1000"></td></tr>
                <tr><th>Word Count Min</th><td><input type="number" name="word_min" value="<?php echo $edit_a ? $edit_a->word_min : 0; ?>" min="0" placeholder="0 = no limit"></td></tr>
                <tr><th>Word Count Max</th><td><input type="number" name="word_max" value="<?php echo $edit_a ? $edit_a->word_max : 0; ?>" min="0" placeholder="0 = no limit"></td></tr>
                <tr><th>Due Date</th><td><input type="datetime-local" name="due_date" value="<?php echo $edit_a && $edit_a->due_date ? esc_attr( date( 'Y-m-d\TH:i', strtotime( $edit_a->due_date ) ) ) : ''; ?>"></td></tr>
            </table>

            <h2 style="margin-top:24px">Marking Rubric</h2>
            <p style="color:#666">Define the criteria and their maximum scores. They must add up to the total maximum score.</p>

            <div id="em-rubric-builder">
            <?php foreach ( $rubric as $i => $criterion ) : ?>
            <div class="em-rubric-criterion" data-idx="<?php echo $i; ?>">
                <div class="em-rc-row">
                    <input type="hidden" name="rubric_id[]" value="<?php echo esc_attr( $criterion['id'] ); ?>">
                    <div class="em-rc-field">
                        <label>Criterion Name</label>
                        <input type="text" name="rubric_name[]" value="<?php echo esc_attr( $criterion['name'] ); ?>" required class="regular-text">
                    </div>
                    <div class="em-rc-field em-rc-max">
                        <label>Max Score</label>
                        <input type="number" name="rubric_max[]" value="<?php echo $criterion['max']; ?>" min="1" max="500">
                    </div>
                    <button type="button" class="button em-remove-criterion" title="Remove">&#10005;</button>
                </div>
                <div class="em-rc-field" style="margin-top:8px">
                    <label>Description</label>
                    <input type="text" name="rubric_desc[]" value="<?php echo esc_attr( $criterion['description'] ); ?>" class="large-text" placeholder="What does this criterion assess?">
                </div>
            </div>
            <?php endforeach; ?>
            </div>

            <button type="button" class="button" id="em-add-criterion" style="margin-top:10px">+ Add Criterion</button>

            <p class="submit">
                <button type="submit" class="button button-primary">Save Assignment</button>
                <a href="<?php echo admin_url( 'admin.php?page=em-assignments' ); ?>" class="button">Cancel</a>
            </p>
        </form>
        </div>
        <?php
    else :
        $assignments = em_get_assignments( array( 'status' => '' ) );
        ?>
        <div class="wrap em-admin-wrap">
        <h1>Assignments <a href="<?php echo admin_url( 'admin.php?page=em-assignments&action=new' ); ?>" class="page-title-action">+ New</a></h1>
        <table class="wp-list-table widefat fixed striped em-table">
            <thead><tr><th>Title</th><th>Max Score</th><th>Submissions</th><th>Due</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if ( empty( $assignments ) ) : ?>
            <tr><td colspan="6" style="text-align:center;padding:20px;color:#888">No assignments yet. <a href="<?php echo admin_url( 'admin.php?page=em-assignments&action=new' ); ?>">Create one</a>.</td></tr>
            <?php else : ?>
            <?php foreach ( $assignments as $a ) :
                $count = em_count_submissions( $a->id );
                $pend  = em_count_submissions( $a->id, 'submitted' ) + em_count_submissions( $a->id, 'resubmitted' );
            ?>
            <tr>
                <td><strong><?php echo esc_html( $a->title ); ?></strong></td>
                <td><?php echo $a->max_score; ?></td>
                <td><?php echo $count; ?> total <?php echo $pend ? '<span class="em-admin-pending">(' . $pend . ' pending)</span>' : ''; ?></td>
                <td><?php echo $a->due_date ? esc_html( date( 'j M Y', strtotime( $a->due_date ) ) ) : '—'; ?></td>
                <td><?php echo esc_html( ucfirst( $a->status ) ); ?></td>
                <td>
                    <a href="<?php echo admin_url( 'admin.php?page=em-assignments&action=edit&id=' . $a->id ); ?>" class="button button-small">Edit</a>
                    <a href="<?php echo admin_url( 'admin.php?page=em-submissions&assignment_id=' . $a->id ); ?>" class="button button-small">Submissions</a>
                    <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=em-assignments&em_delete_asgn=' . $a->id ), 'em_delete_asgn' ); ?>" class="button button-small" onclick="return confirm('Delete this assignment?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php
    endif;
}

/* ================================================================
   SUBMISSIONS PAGE
================================================================ */
function em_page_submissions() {
    global $wpdb;
    $asgn_id = isset( $_GET['assignment_id'] ) ? (int) $_GET['assignment_id'] : 0;
    $args    = array( 'limit' => 50 );
    if ( $asgn_id ) { $args['assignment_id'] = $asgn_id; }
    $submissions  = em_get_submissions( $args );
    $assignments  = em_get_assignments( array( 'status' => '' ) );
    ?>
    <div class="wrap em-admin-wrap">
    <h1>Submissions</h1>

    <div class="em-filter-bar" style="margin-bottom:20px">
        <select onchange="location.href='<?php echo admin_url( 'admin.php?page=em-submissions' ); ?>&assignment_id='+this.value">
            <option value="">All Assignments</option>
            <?php foreach ( $assignments as $a ) : ?>
            <option value="<?php echo $a->id; ?>" <?php selected( $asgn_id, $a->id ); ?>><?php echo esc_html( $a->title ); ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <table class="wp-list-table widefat fixed striped em-table">
        <thead><tr><th>Student</th><th>Essay Title</th><th>Assignment</th><th>Words</th><th>Submitted</th><th>Status</th><th>Mark</th><th>Action</th></tr></thead>
        <tbody>
        <?php if ( empty( $submissions ) ) : ?>
        <tr><td colspan="8" style="text-align:center;padding:20px;color:#888">No submissions yet.</td></tr>
        <?php else : ?>
        <?php foreach ( $submissions as $sub ) :
            $student    = get_userdata( $sub->student_id );
            $assignment = em_get_assignment( $sub->assignment_id );
            $mark       = em_get_mark( $sub->id );
        ?>
        <tr>
            <td><?php echo $student ? esc_html( $student->display_name ) : 'Unknown'; ?></td>
            <td><?php echo esc_html( $sub->title ?: '(untitled)' ); ?></td>
            <td><?php echo $assignment ? esc_html( $assignment->title ) : '—'; ?></td>
            <td><?php echo number_format( $sub->word_count ); ?></td>
            <td><?php echo esc_html( date( 'j M Y', strtotime( $sub->submitted_at ) ) ); ?></td>
            <td><?php echo esc_html( ucfirst( $sub->status ) ); ?></td>
            <td><?php if ( $mark ) : ?>
                <span class="em-admin-grade" style="background:<?php echo esc_attr( em_grade_colour( $mark->grade ) ); ?>"><?php echo esc_html( $mark->grade ); ?> <?php echo number_format( $mark->percentage, 1 ); ?>%</span>
            <?php else : ?>
                <span class="em-admin-pending">Pending</span>
            <?php endif; ?></td>
            <td><a href="<?php echo admin_url( 'admin.php?page=em-mark&sub=' . $sub->id ); ?>" class="button button-primary button-small"><?php echo $mark ? 'Review' : 'Mark'; ?></a></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
    <?php
}

/* ================================================================
   MARK ESSAY PAGE
================================================================ */
function em_page_mark() {
    $sub_id = isset( $_GET['sub'] ) ? (int) $_GET['sub'] : 0;
    if ( ! $sub_id ) {
        echo '<div class="wrap"><div class="notice notice-error"><p>No submission selected.</p></div></div>';
        return;
    }
    $sub        = em_get_submission( $sub_id );
    if ( ! $sub ) {
        echo '<div class="wrap"><div class="notice notice-error"><p>Submission not found.</p></div></div>';
        return;
    }
    $assignment = em_get_assignment( $sub->assignment_id );
    $student    = get_userdata( $sub->student_id );
    $rubric     = $assignment ? em_get_rubric( $assignment ) : em_default_rubric();
    $mark       = em_get_mark( $sub_id, 'teacher' );
    $ai_mark    = em_get_mark( $sub_id, 'ai' );
    $comments   = em_get_inline_comments( $sub_id );
    $scores     = $mark ? json_decode( $mark->scores, true ) : array();
    $ai_scores  = $ai_mark ? json_decode( $ai_mark->scores, true ) : array();
    $ai_enabled = get_option( 'em_ai_enabled', 0 );
    $api_key    = get_option( 'em_anthropic_api_key', '' );
    ?>
    <div class="wrap em-admin-wrap em-mark-wrap">
    <div class="em-mark-header">
        <div>
            <h1>&#9997; Mark Essay</h1>
            <p>
                <strong><?php echo $student ? esc_html( $student->display_name ) : 'Unknown'; ?></strong>
                &nbsp;&bull;&nbsp; <?php echo $assignment ? esc_html( $assignment->title ) : ''; ?>
                &nbsp;&bull;&nbsp; <?php echo number_format( $sub->word_count ); ?> words
                &nbsp;&bull;&nbsp; Submitted <?php echo esc_html( date( 'j M Y g:ia', strtotime( $sub->submitted_at ) ) ); ?>
            </p>
        </div>
        <div class="em-mark-header-actions">
            <?php if ( $ai_enabled && $api_key ) : ?>
            <button class="button button-large" id="em-ai-mark-btn" data-sub="<?php echo $sub_id; ?>">
                &#129302; AI Mark This Essay
            </button>
            <?php endif; ?>
            <a href="<?php echo admin_url( 'admin.php?page=em-submissions' ); ?>" class="button">&larr; Back</a>
        </div>
    </div>

    <div class="em-mark-layout">

        <!-- LEFT: Essay text -->
        <div class="em-essay-panel" id="em-essay-panel">
            <div class="em-essay-panel-header">
                <h3>Essay</h3>
                <span class="em-essay-hint">Select text to add an inline comment</span>
            </div>
            <div class="em-essay-body" id="em-essay-body" data-sub="<?php echo $sub_id; ?>">
                <?php echo wp_kses_post( $sub->content ); ?>
            </div>

            <!-- Inline comments -->
            <div class="em-inline-comments-admin" id="em-inline-comments-admin">
                <?php if ( ! empty( $comments ) ) : ?>
                <h4 style="margin-top:20px">Inline Comments</h4>
                <?php foreach ( $comments as $c ) :
                    $type_icon = $c->comment_type === 'praise' ? '&#9989;' : ( $c->comment_type === 'error' ? '&#10060;' : '&#128172;' );
                    $who       = $c->marker_type === 'ai' ? '&#129302; AI' : '&#127979; Teacher';
                ?>
                <div class="em-ic-admin-item em-ic-<?php echo esc_attr( $c->comment_type ); ?>" data-id="<?php echo $c->id; ?>">
                    <div class="em-ic-admin-meta"><?php echo $who; ?> &bull; <?php echo $type_icon; ?> <?php echo esc_html( ucfirst( $c->comment_type ) ); ?></div>
                    <?php if ( $c->selected_text ) : ?>
                    <div class="em-ic-admin-quote">"<?php echo esc_html( $c->selected_text ); ?>"</div>
                    <?php endif; ?>
                    <p class="em-ic-admin-text"><?php echo esc_html( $c->comment_text ); ?></p>
                    <button class="button button-small em-delete-comment" data-id="<?php echo $c->id; ?>">&#10005; Remove</button>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- RIGHT: Marking form -->
        <div class="em-marking-panel">

            <!-- AI mark summary (if exists) -->
            <?php if ( $ai_mark ) : ?>
            <div class="em-ai-mark-summary">
                <div class="em-ais-header">
                    <span>&#129302; AI Suggestion</span>
                    <span class="em-admin-grade" style="background:<?php echo esc_attr( em_grade_colour( $ai_mark->grade ) ); ?>"><?php echo esc_html( $ai_mark->grade ); ?> <?php echo number_format( $ai_mark->percentage, 1 ); ?>%</span>
                </div>
                <?php if ( $ai_mark->overall_feedback ) : ?>
                <p style="font-size:13px;color:#555;margin:6px 0 0"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $ai_mark->overall_feedback ), 30 ) ); ?></p>
                <?php endif; ?>
                <button class="button button-small" id="em-adopt-ai-scores" style="margin-top:8px">&#8593; Use AI Scores</button>
            </div>
            <?php endif; ?>

            <form id="em-mark-form">
                <input type="hidden" name="submission_id" value="<?php echo $sub_id; ?>">
                <input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'em_nonce' ) ); ?>">
                <input type="hidden" name="action" value="em_save_mark">

                <!-- Rubric scores -->
                <div class="em-marking-section">
                    <h3>Rubric Scores</h3>
                    <?php
                    $total_max = 0;
                    foreach ( $rubric as $criterion ) { $total_max += $criterion['max']; }
                    ?>
                    <div class="em-rubric-form" data-max="<?php echo $total_max; ?>">
                    <?php foreach ( $rubric as $criterion ) :
                        $current_score  = isset( $scores[ $criterion['id'] ] ) ? (float) $scores[ $criterion['id'] ] : '';
                        $ai_score       = isset( $ai_scores[ $criterion['id'] ] ) ? (float) $ai_scores[ $criterion['id'] ] : null;
                    ?>
                    <div class="em-rc-input-row">
                        <label class="em-rc-label">
                            <?php echo esc_html( $criterion['name'] ); ?>
                            <small><?php echo esc_html( $criterion['description'] ); ?></small>
                        </label>
                        <div class="em-rc-score-wrap">
                            <?php if ( $ai_score !== null ) : ?>
                            <span class="em-ai-hint">AI: <?php echo $ai_score; ?></span>
                            <?php endif; ?>
                            <input type="number" class="em-score-input" name="scores[<?php echo esc_attr( $criterion['id'] ); ?>]"
                                   value="<?php echo esc_attr( $current_score ); ?>"
                                   min="0" max="<?php echo $criterion['max']; ?>" step="0.5"
                                   placeholder="0"
                                   data-ai="<?php echo $ai_score !== null ? $ai_score : ''; ?>"
                                   data-criterion="<?php echo esc_attr( $criterion['id'] ); ?>">
                            <span class="em-rc-max">/ <?php echo $criterion['max']; ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    </div>

                    <div class="em-total-score-display">
                        Total: <strong id="em-total-display"><?php echo $mark ? number_format( $mark->total_score, 1 ) : '0'; ?></strong>
                        / <?php echo $total_max; ?>
                        &nbsp;
                        <strong id="em-pct-display"><?php echo $mark ? number_format( $mark->percentage, 1 ) : '0'; ?>%</strong>
                        &nbsp;
                        <strong id="em-grade-display" style="color:<?php echo $mark ? esc_attr( em_grade_colour( $mark->grade ) ) : '#888'; ?>"><?php echo $mark ? esc_html( $mark->grade ) : '—'; ?></strong>
                    </div>
                </div>

                <!-- Feedback -->
                <div class="em-marking-section">
                    <h3>Overall Feedback</h3>
                    <?php wp_editor( $mark ? $mark->overall_feedback : '', 'overall_feedback', array(
                        'textarea_name' => 'overall_feedback',
                        'editor_height' => 160,
                        'teeny'         => true,
                        'media_buttons' => false,
                    ) ); ?>
                </div>

                <div class="em-marking-section em-two-col">
                    <div>
                        <h3>&#9989; Strengths</h3>
                        <textarea name="strengths" rows="4" class="widefat" placeholder="What did the student do well?"><?php echo $mark ? esc_textarea( $mark->strengths ) : ''; ?></textarea>
                    </div>
                    <div>
                        <h3>&#128161; Areas to Improve</h3>
                        <textarea name="improvements" rows="4" class="widefat" placeholder="What should the student work on?"><?php echo $mark ? esc_textarea( $mark->improvements ) : ''; ?></textarea>
                    </div>
                </div>

                <div class="em-mark-actions">
                    <button type="submit" class="button button-primary button-large" id="em-save-mark-btn">
                        &#10003; Save Mark
                    </button>
                    <span class="em-save-msg" id="em-save-msg" style="display:none"></span>
                </div>
            </form>

            <!-- Add inline comment panel (shown on text selection) -->
            <div class="em-inline-comment-form" id="em-inline-comment-form" style="display:none">
                <div class="em-icf-header">
                    <strong>Add Comment</strong>
                    <button type="button" id="em-icf-close" class="em-icf-close">&#10005;</button>
                </div>
                <div class="em-icf-selected" id="em-icf-selected"></div>
                <textarea id="em-icf-text" rows="3" placeholder="Your comment..."></textarea>
                <div class="em-icf-types">
                    <label><input type="radio" name="em_ic_type" value="comment" checked> &#128172; Comment</label>
                    <label><input type="radio" name="em_ic_type" value="praise"> &#9989; Praise</label>
                    <label><input type="radio" name="em_ic_type" value="error"> &#10060; Error</label>
                </div>
                <button class="button button-primary" id="em-icf-submit">Add Comment</button>
            </div>
        </div>
    </div>

    <!-- AI loading overlay -->
    <div class="em-ai-overlay" id="em-ai-overlay" style="display:none">
        <div class="em-ai-overlay-inner">
            <div class="em-ai-spinner"></div>
            <p>&#129302; AI is reading and marking the essay...</p>
            <small>This usually takes 10–20 seconds</small>
        </div>
    </div>

    <!-- Store AI scores for "use AI scores" button -->
    <script>
    var EM_AI_SCORES = <?php echo wp_json_encode( $ai_scores ); ?>;
    var EM_SUB_ID    = <?php echo $sub_id; ?>;
    var EM_MAX_SCORE = <?php echo $assignment ? (int) $assignment->max_score : 100; ?>;
    </script>
    </div>
    <?php
}

/* ================================================================
   SETTINGS PAGE
================================================================ */
function em_page_settings() {
    $api_key    = get_option( 'em_anthropic_api_key', '' );
    $ai_enabled = get_option( 'em_ai_enabled', 0 );
    if ( isset( $_GET['saved'] ) ) {
        echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }
    ?>
    <div class="wrap em-admin-wrap">
    <h1>&#9881; Essay Marker Settings</h1>
    <form method="post">
        <?php wp_nonce_field( 'em_save_settings' ); ?>
        <input type="hidden" name="em_save_settings" value="1">
        <table class="form-table">
            <tr>
                <th><label for="em_ai_enabled">Enable AI Marking</label></th>
                <td>
                    <label>
                        <input type="checkbox" name="em_ai_enabled" id="em_ai_enabled" value="1" <?php checked( $ai_enabled, 1 ); ?>>
                        Enable the AI marking feature (requires an Anthropic API key)
                    </label>
                </td>
            </tr>
            <tr>
                <th><label for="em_anthropic_api_key">Anthropic API Key</label></th>
                <td>
                    <input type="password" name="em_anthropic_api_key" id="em_anthropic_api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" placeholder="sk-ant-...">
                    <p class="description">Get your API key from <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a>. Used to power the AI marking feature (Claude).</p>
                    <?php if ( $api_key ) : ?>
                    <p class="description" style="color:green">&#10003; API key is set.</p>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <p class="submit"><button type="submit" class="button button-primary">Save Settings</button></p>
    </form>

    <hr>
    <h2>Shortcodes</h2>
    <table class="widefat" style="max-width:700px">
        <thead><tr><th>Shortcode</th><th>Description</th></tr></thead>
        <tbody>
            <tr><td><code>[em_submit]</code></td><td>Essay submission form (all active assignments)</td></tr>
            <tr><td><code>[em_submit assignment_id="5"]</code></td><td>Submission form for a specific assignment</td></tr>
            <tr><td><code>[em_my_essays]</code></td><td>Student dashboard — their submitted essays and marks</td></tr>
            <tr><td><code>[em_results]</code></td><td>Full feedback page for a submission (uses ?sub= URL param)</td></tr>
        </tbody>
    </table>
    </div>
    <?php
}
