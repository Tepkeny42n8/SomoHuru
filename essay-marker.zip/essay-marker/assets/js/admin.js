(function ($) {
    'use strict';

    /* ================================================================
       LIVE SCORE CALCULATION
    ================================================================ */
    function recalcTotal() {
        var $inputs  = $('.em-score-input');
        var total    = 0;
        var max      = parseInt( EM_MAX_SCORE, 10 ) || 100;
        $inputs.each(function () {
            var v = parseFloat( $(this).val() ) || 0;
            total += v;
        });
        var pct   = max > 0 ? Math.min( 100, ( total / max ) * 100 ) : 0;
        var grade = pctToGrade( pct );
        var colour = gradeColour( grade );
        $('#em-total-display').text( total.toFixed(1) );
        $('#em-pct-display').text( pct.toFixed(1) + '%' );
        $('#em-grade-display').text( grade ).css('color', colour );
    }

    function pctToGrade(p) {
        if ( p >= 80 ) { return 'A'; }
        if ( p >= 70 ) { return 'B'; }
        if ( p >= 60 ) { return 'C'; }
        if ( p >= 50 ) { return 'D'; }
        return 'E';
    }

    function gradeColour(g) {
        var map = { A: '#16a34a', B: '#2563eb', C: '#d97706', D: '#ea580c', E: '#dc2626' };
        return map[g] || '#6b7280';
    }

    $(document).on('input change', '.em-score-input', recalcTotal);

    /* ================================================================
       ADOPT AI SCORES
    ================================================================ */
    $('#em-adopt-ai-scores').on('click', function () {
        if ( ! EM_AI_SCORES ) { return; }
        $.each( EM_AI_SCORES, function (key, val) {
            $('[data-criterion="' + key + '"]').val( val );
        });
        recalcTotal();
    });

    /* ================================================================
       SAVE MARK (AJAX)
    ================================================================ */
    $('#em-mark-form').on('submit', function (e) {
        e.preventDefault();
        var $btn = $('#em-save-mark-btn');
        var $msg = $('#em-save-msg');
        $btn.prop('disabled', true).text('Saving...');
        /* Sync TinyMCE if present */
        if ( typeof tinyMCE !== 'undefined' && tinyMCE.get('overall_feedback') ) {
            tinyMCE.get('overall_feedback').save();
        }
        $.post( EM.ajax, $(this).serialize() + '&nonce=' + EM.nonce + '&action=em_save_mark', function (res) {
            if ( res.success ) {
                $msg.text('&#10003; Saved! Grade: ' + res.data.grade + ' (' + parseFloat(res.data.percentage).toFixed(1) + '%)').addClass('success').show();
                setTimeout(function () { $msg.fadeOut(); }, 4000 );
            } else {
                $msg.text( res.data || 'Error saving.' ).addClass('error').show();
            }
            $btn.prop('disabled', false).text('✓ Save Mark');
        }).fail(function () {
            $msg.text('Server error.').addClass('error').show();
            $btn.prop('disabled', false).text('✓ Save Mark');
        });
    });

    /* ================================================================
       AI MARKING
    ================================================================ */
    $('#em-ai-mark-btn').on('click', function () {
        if ( ! confirm('Send this essay to the AI for marking? Any existing AI mark will be replaced.') ) { return; }
        var $overlay = $('#em-ai-overlay');
        $overlay.show();
        $.post( EM.ajax, {
            action:        'em_ai_mark',
            submission_id: EM_SUB_ID,
            nonce:         EM.nonce,
        }, function (res) {
            $overlay.hide();
            if ( res.success ) {
                alert( '&#129302; AI marking complete!\nGrade: ' + res.data.grade + ' (' + parseFloat(res.data.percentage).toFixed(1) + '%)\nRefresh the page to see the results.' );
                location.reload();
            } else {
                alert( 'AI marking failed: ' + ( res.data || 'Unknown error.' ) );
            }
        }).fail(function () {
            $overlay.hide();
            alert('Server error during AI marking. Check your API key in Essay Marker > Settings.');
        });
    });

    /* ================================================================
       INLINE COMMENTS (text selection)
    ================================================================ */
    var $essayBody = $('#em-essay-body');
    var $icForm    = $('#em-inline-comment-form');
    var selectedText = '';
    var selStart = 0;
    var selEnd   = 0;

    $essayBody.on('mouseup touchend', function () {
        var selection = window.getSelection();
        if ( ! selection || selection.isCollapsed || selection.toString().trim().length < 3 ) {
            return;
        }
        selectedText = selection.toString().trim().substring(0, 200);
        var range    = selection.getRangeAt(0);
        var preRange = document.createRange();
        preRange.setStart( $essayBody[0], 0 );
        preRange.setEnd( range.startContainer, range.startOffset );
        selStart = preRange.toString().length;
        selEnd   = selStart + selectedText.length;

        $('#em-icf-selected').text( '"' + selectedText.substring(0, 100) + ( selectedText.length > 100 ? '…' : '' ) + '"' );
        $('#em-icf-text').val('');
        $icForm.show();
        setTimeout(function () { $('#em-icf-text').focus(); }, 100);
    });

    $('#em-icf-close').on('click', function () {
        $icForm.hide();
        selectedText = '';
    });

    $('#em-icf-submit').on('click', function () {
        var text = $('#em-icf-text').val().trim();
        if ( ! text ) { alert('Please enter a comment.'); return; }
        var type = $('input[name="em_ic_type"]:checked').val() || 'comment';
        var $btn = $(this);
        $btn.prop('disabled', true).text('Adding...');
        $.post( EM.ajax, {
            action:        'em_add_comment',
            submission_id: EM_SUB_ID,
            nonce:         EM.nonce,
            selected_text: selectedText,
            comment_text:  text,
            char_start:    selStart,
            char_end:      selEnd,
            comment_type:  type,
            marker_type:   'teacher',
        }, function (res) {
            if ( res.success ) {
                $icForm.hide();
                selectedText = '';
                /* Append to list */
                var typeIcon  = type === 'praise' ? '&#9989;' : ( type === 'error' ? '&#10060;' : '&#128172;' );
                var quoteHtml = selectedText ? '<div class="em-ic-admin-quote">"' + escHtml( selectedText ) + '"</div>' : '';
                var html = '<div class="em-ic-admin-item em-ic-' + type + '" data-id="' + res.data.comment_id + '">' +
                           '<div class="em-ic-admin-meta">&#127979; Teacher &bull; ' + typeIcon + ' ' + ucfirst(type) + '</div>' +
                           quoteHtml +
                           '<p class="em-ic-admin-text">' + escHtml( text ) + '</p>' +
                           '<button class="button button-small em-delete-comment" data-id="' + res.data.comment_id + '">&#10005; Remove</button>' +
                           '</div>';
                var $container = $('#em-inline-comments-admin');
                if ( ! $container.find('h4').length ) {
                    $container.prepend('<h4 style="margin-top:20px">Inline Comments</h4>');
                }
                $container.append( html );
            } else {
                alert( res.data || 'Failed to add comment.' );
            }
            $btn.prop('disabled', false).text('Add Comment');
        });
    });

    /* Delete inline comment */
    $(document).on('click', '.em-delete-comment', function () {
        if ( ! confirm('Remove this comment?') ) { return; }
        var id  = $(this).data('id');
        var $el = $(this).closest('.em-ic-admin-item');
        $.post( EM.ajax, { action: 'em_delete_comment', comment_id: id, nonce: EM.nonce }, function (res) {
            if ( res.success ) { $el.fadeOut(200, function () { $(this).remove(); }); }
        });
    });

    /* ================================================================
       RUBRIC BUILDER (assignment editor)
    ================================================================ */
    var criterionIdx = $('.em-rubric-criterion').length;

    $('#em-add-criterion').on('click', function () {
        var id  = 'criterion_' + criterionIdx;
        var html = '<div class="em-rubric-criterion">' +
            '<div class="em-rc-row">' +
            '<input type="hidden" name="rubric_id[]" value="' + id + '">' +
            '<div class="em-rc-field"><label>Criterion Name</label><input type="text" name="rubric_name[]" required class="regular-text" placeholder="e.g. Language & Style"></div>' +
            '<div class="em-rc-field em-rc-max"><label>Max Score</label><input type="number" name="rubric_max[]" value="25" min="1" max="500"></div>' +
            '<button type="button" class="button em-remove-criterion" title="Remove">&#10005;</button>' +
            '</div>' +
            '<div class="em-rc-field" style="margin-top:8px"><label>Description</label><input type="text" name="rubric_desc[]" class="large-text" placeholder="What does this criterion assess?"></div>' +
            '</div>';
        $('#em-rubric-builder').append( html );
        criterionIdx++;
    });

    $(document).on('click', '.em-remove-criterion', function () {
        $(this).closest('.em-rubric-criterion').remove();
    });

    /* ================================================================
       HELPERS
    ================================================================ */
    function escHtml(str) {
        return $('<div>').text(str).html();
    }
    function ucfirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

}(jQuery));
