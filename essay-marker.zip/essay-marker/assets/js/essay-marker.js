(function ($) {
    'use strict';

    /* ================================================================
       ASSIGNMENT SELECTOR
    ================================================================ */
    $(document).on('click', '.em-select-asgn, .em-asgn-card', function (e) {
        if ( $(e.target).is('button') || $(e.target).closest('button').length ) {
            var btn   = $(e.target).closest('button');
            var id    = btn.data('id');
        } else {
            var id = $(this).data('id');
        }
        if ( ! id ) { return; }
        var $assignment = $('#em-assignment-selector');
        var $form       = $('#em-submit-form-wrap');
        if ( $assignment.length && $form.length ) {
            $('#em-assignment-id').val( id );
            loadAssignmentBrief( id );
            $assignment.hide();
            $form.show();
        }
    });

    $('#em-back-btn').on('click', function () {
        $('#em-submit-form-wrap').hide();
        $('#em-assignment-selector').show();
    });

    function loadAssignmentBrief( id ) {
        /* Find the card and update the brief */
        var $card = $('.em-asgn-card[data-id="' + id + '"]');
        if ( $card.length ) {
            var title = $card.find('h3').text();
            var desc  = $card.find('p').text();
            $('#em-assignment-brief').find('h2').text( title );
            $('#em-assignment-brief').find('.em-assignment-desc').text( desc );
        }
    }

    /* ================================================================
       RICH TEXT EDITOR (contenteditable)
    ================================================================ */
    var $editor  = $('#em-editor');
    var $hidden  = $('#em-content-hidden');
    var $wc      = $('#em-wc');

    if ( $editor.length ) {
        $editor.on('input', function () {
            var text = $editor.text();
            var words = text.trim() ? text.trim().split(/\s+/).length : 0;
            $wc.text( words + ' word' + ( words !== 1 ? 's' : '' ) );
            $hidden.val( $editor.html() );
        });

        $editor.on('paste', function (e) {
            e.preventDefault();
            var text = e.originalEvent.clipboardData.getData('text/plain');
            document.execCommand( 'insertText', false, text );
        });

        $(document).on('click', '.em-tb-btn', function () {
            var cmd = $(this).data('cmd');
            $editor.focus();
            document.execCommand( cmd, false, null );
            $hidden.val( $editor.html() );
        });
    }

    /* ================================================================
       SUBMIT FORM
    ================================================================ */
    $('#em-submit-form').on('submit', function (e) {
        e.preventDefault();
        var $form = $(this);
        var $btn  = $('#em-submit-btn');
        var $msg  = $('#em-form-message');
        var content = $editor.length ? $editor.html() : $hidden.val();
        if ( ! content.trim() || content === '<br>' ) {
            showMsg( $msg, 'Please write your essay before submitting.', 'em-notice-warn' );
            return;
        }
        $hidden.val( content );
        $btn.prop('disabled', true);
        $btn.find('.em-btn-text').hide();
        $btn.find('.em-spinner').show();
        var data = $form.serialize() + '&content=' + encodeURIComponent( content );
        $.post( EM.ajax, data, function (res) {
            if ( res.success ) {
                showMsg( $msg, res.data.message, 'em-notice-success' );
                setTimeout(function () {
                    if ( res.data.redirect ) { window.location.href = res.data.redirect; }
                }, 1500 );
            } else {
                showMsg( $msg, res.data || 'An error occurred.', 'em-notice-error' );
                $btn.prop('disabled', false);
                $btn.find('.em-btn-text').show();
                $btn.find('.em-spinner').hide();
            }
        }).fail(function () {
            showMsg( $msg, 'Server error. Please try again.', 'em-notice-error' );
            $btn.prop('disabled', false);
            $btn.find('.em-btn-text').show();
            $btn.find('.em-spinner').hide();
        });
    });

    function showMsg( $el, text, cls ) {
        $el.removeClass('em-notice-success em-notice-error em-notice-warn em-notice-info')
           .addClass('em-notice ' + cls)
           .text( text )
           .show();
        $('html, body').animate({ scrollTop: $el.offset().top - 80 }, 300);
    }

}(jQuery));
