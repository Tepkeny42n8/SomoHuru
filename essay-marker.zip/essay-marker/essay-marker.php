<?php
/**
 * Plugin Name:  Essay Marker
 * Plugin URI:   https://somohuru.co.ke
 * Description:  AI-powered essay marking. Students submit essays against rubrics; teachers and AI grade with inline comments, scores, and detailed feedback.
 * Version:      1.0.0
 * Author:       SomoHuru Team
 * License:      GPL-2.0+
 * Text Domain:  essay-marker
 */

defined( 'ABSPATH' ) || exit;

define( 'EM_VERSION', '1.0.0' );
define( 'EM_PATH',    plugin_dir_path( __FILE__ ) );
define( 'EM_URL',     plugin_dir_url( __FILE__ ) );

register_activation_hook( __FILE__,   'em_activate' );
register_deactivation_hook( __FILE__, 'em_deactivate' );

function em_activate() {
    require_once EM_PATH . 'includes/db.php';
    em_create_tables();
    em_create_pages();
    flush_rewrite_rules();
}

function em_deactivate() {
    flush_rewrite_rules();
}

require_once EM_PATH . 'includes/db.php';
require_once EM_PATH . 'includes/post-types.php';
require_once EM_PATH . 'includes/helpers.php';
require_once EM_PATH . 'includes/ajax.php';
require_once EM_PATH . 'includes/shortcodes.php';
require_once EM_PATH . 'includes/metaboxes.php';
require_once EM_PATH . 'admin/panel.php';

/* ---- Frontend assets ---- */
add_action( 'wp_enqueue_scripts', 'em_frontend_assets' );
function em_frontend_assets() {
    wp_enqueue_style( 'em-style', EM_URL . 'assets/css/essay-marker.css', array(), EM_VERSION );
    wp_enqueue_script( 'em-js', EM_URL . 'assets/js/essay-marker.js', array( 'jquery' ), EM_VERSION, true );
    wp_localize_script( 'em-js', 'EM', array(
        'ajax'      => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'em_nonce' ),
        'user_id'   => get_current_user_id(),
        'logged_in' => is_user_logged_in() ? 1 : 0,
    ) );
}

/* ---- Admin assets ---- */
add_action( 'admin_enqueue_scripts', 'em_admin_assets' );
function em_admin_assets() {
    wp_enqueue_style( 'em-admin-css', EM_URL . 'assets/css/admin.css', array(), EM_VERSION );
    wp_enqueue_script( 'em-admin-js', EM_URL . 'assets/js/admin.js', array( 'jquery' ), EM_VERSION, true );
    wp_localize_script( 'em-admin-js', 'EM', array(
        'ajax'  => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'em_nonce' ),
    ) );
}

function em_create_pages() {
    $pages = array(
        array( 'title' => 'Submit Essay',  'slug' => 'submit-essay',  'content' => '[em_submit]' ),
        array( 'title' => 'My Essays',     'slug' => 'my-essays',     'content' => '[em_my_essays]' ),
        array( 'title' => 'Essay Results', 'slug' => 'essay-results', 'content' => '[em_results]' ),
    );
    foreach ( $pages as $page ) {
        if ( ! get_page_by_path( $page['slug'] ) ) {
            wp_insert_post( array(
                'post_title'   => $page['title'],
                'post_content' => $page['content'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_name'    => $page['slug'],
            ) );
        }
    }
}
