<?php
/**
 * Plugin Name: SomoHuru Web3 LMS
 * Plugin URI:  https://somohuru.com
 * Description: AI-powered K-12 LMS with Web3 integration — MetaMask login, NFT certificates, SOMO token rewards, IPFS storage, and DAO governance built into WordPress.
 * Version:     1.0.0
 * Author:      SomoHuru
 * License:     GPL-2.0+
 * Text Domain: somohuru-web3
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SOMO_VERSION',    '1.0.0' );
define( 'SOMO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SOMO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/* ──────────────────────────────────────────
   ACTIVATION / DEACTIVATION
────────────────────────────────────────── */
register_activation_hook( __FILE__, 'somo_activate' );
function somo_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    // Courses table
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_courses (
        id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title           VARCHAR(255) NOT NULL,
        description     TEXT,
        category        VARCHAR(100),
        difficulty      ENUM('beginner','intermediate','advanced') DEFAULT 'beginner',
        somo_reward     INT DEFAULT 10,
        nft_enabled     TINYINT(1) DEFAULT 1,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    // Lessons table
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_lessons (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        course_id   BIGINT UNSIGNED NOT NULL,
        title       VARCHAR(255) NOT NULL,
        content     LONGTEXT,
        video_url   VARCHAR(500),
        sort_order  INT DEFAULT 0,
        somo_reward INT DEFAULT 5
    ) $charset;" );

    // Enrollments / progress
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_progress (
        id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id         BIGINT UNSIGNED NOT NULL,
        course_id       BIGINT UNSIGNED,
        lesson_id       BIGINT UNSIGNED,
        status          ENUM('enrolled','in_progress','completed') DEFAULT 'enrolled',
        score           INT DEFAULT 0,
        completed_at    DATETIME,
        nft_minted      TINYINT(1) DEFAULT 0,
        nft_tx_hash     VARCHAR(100),
        tokens_awarded  INT DEFAULT 0
    ) $charset;" );

    // Quizzes
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_quizzes (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        lesson_id   BIGINT UNSIGNED NOT NULL,
        question    TEXT NOT NULL,
        options     LONGTEXT,
        answer      VARCHAR(10),
        points      INT DEFAULT 10
    ) $charset;" );

    // Token ledger
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_tokens (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id     BIGINT UNSIGNED NOT NULL,
        amount      INT NOT NULL,
        reason      VARCHAR(255),
        tx_hash     VARCHAR(100),
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    // DAO proposals
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_proposals (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        author_id   BIGINT UNSIGNED NOT NULL,
        title       VARCHAR(255) NOT NULL,
        description TEXT,
        votes_yes   INT DEFAULT 0,
        votes_no    INT DEFAULT 0,
        status      ENUM('open','closed','passed','rejected') DEFAULT 'open',
        ends_at     DATETIME,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    // DAO votes
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_votes (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        proposal_id BIGINT UNSIGNED NOT NULL,
        user_id     BIGINT UNSIGNED NOT NULL,
        vote        ENUM('yes','no') NOT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_vote (proposal_id, user_id)
    ) $charset;" );

    // NFT certificates
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}somo_nfts (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id     BIGINT UNSIGNED NOT NULL,
        course_id   BIGINT UNSIGNED NOT NULL,
        wallet      VARCHAR(100),
        ipfs_hash   VARCHAR(100),
        token_id    VARCHAR(100),
        tx_hash     VARCHAR(100),
        minted_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    // Default options
    add_option( 'somo_polygon_rpc',       'https://rpc-mumbai.maticvigil.com' );
    add_option( 'somo_contract_nft',      '' );
    add_option( 'somo_contract_token',    '' );
    add_option( 'somo_contract_dao',      '' );
    add_option( 'somo_pinata_api_key',    '' );
    add_option( 'somo_pinata_secret',     '' );
    add_option( 'somo_backend_url',       '' );
    add_option( 'somo_token_symbol',      'SOMO' );
    add_option( 'somo_platform_name',     'SomoHuru' );

    // Demo course
    $wpdb->insert( $wpdb->prefix . 'somo_courses', [
        'title'       => 'Introduction to Mathematics',
        'description' => 'Core math skills for K-8 learners. Covers arithmetic, fractions, and basic algebra.',
        'category'    => 'Mathematics',
        'difficulty'  => 'beginner',
        'somo_reward' => 50,
        'nft_enabled' => 1,
    ] );
    $course_id = $wpdb->insert_id;
    $lessons = [
        [ 'Numbers & Counting',     'Learn numbers from 1 to 100 and basic counting techniques.', 5 ],
        [ 'Addition & Subtraction', 'Master the fundamentals of adding and subtracting.',          5 ],
        [ 'Multiplication Tables',  'Learn times tables from 1 to 12.',                            5 ],
        [ 'Fractions Basics',       'Understanding halves, quarters, and thirds.',                 10 ],
    ];
    foreach ( $lessons as $i => $l ) {
        $wpdb->insert( $wpdb->prefix . 'somo_lessons', [
            'course_id'   => $course_id,
            'title'       => $l[0],
            'content'     => $l[1],
            'sort_order'  => $i + 1,
            'somo_reward' => $l[2],
        ] );
        $lid = $wpdb->insert_id;
        $wpdb->insert( $wpdb->prefix . 'somo_quizzes', [
            'lesson_id' => $lid,
            'question'  => 'What is 7 x 8?',
            'options'   => json_encode( ['A'=>'54','B'=>'56','C'=>'48','D'=>'63'] ),
            'answer'    => 'B',
            'points'    => 10,
        ] );
    }

    flush_rewrite_rules();
}

/* ──────────────────────────────────────────
   LOAD INCLUDES
────────────────────────────────────────── */
require_once SOMO_PLUGIN_DIR . 'includes/shortcodes.php';
require_once SOMO_PLUGIN_DIR . 'includes/ajax.php';
require_once SOMO_PLUGIN_DIR . 'includes/admin.php';
require_once SOMO_PLUGIN_DIR . 'includes/api.php';

/* ──────────────────────────────────────────
   ENQUEUE SCRIPTS & STYLES
────────────────────────────────────────── */
add_action( 'wp_enqueue_scripts', 'somo_enqueue' );
function somo_enqueue() {
    // Web3.js from CDN
    wp_enqueue_script( 'web3js', 'https://cdn.jsdelivr.net/npm/web3@1.10.0/dist/web3.min.js', [], null, true );
    // Our main plugin script
    wp_enqueue_script( 'somo-main', SOMO_PLUGIN_URL . 'assets/js/somo.js', ['jquery','web3js'], SOMO_VERSION, true );
    wp_enqueue_style(  'somo-style', SOMO_PLUGIN_URL . 'assets/css/somo.css', [], SOMO_VERSION );

    // Pass data to JS
    wp_localize_script( 'somo-main', 'somoData', [
        'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
        'nonce'          => wp_create_nonce( 'somo_nonce' ),
        'userId'         => get_current_user_id(),
        'polygonRpc'     => get_option( 'somo_polygon_rpc' ),
        'nftContract'    => get_option( 'somo_contract_nft' ),
        'tokenContract'  => get_option( 'somo_contract_token' ),
        'backendUrl'     => get_option( 'somo_backend_url' ),
        'tokenSymbol'    => get_option( 'somo_token_symbol', 'SOMO' ),
        'platformName'   => get_option( 'somo_platform_name', 'SomoHuru' ),
        'isLoggedIn'     => is_user_logged_in() ? 1 : 0,
        'walletAddress'  => is_user_logged_in() ? get_user_meta( get_current_user_id(), 'somo_wallet_address', true ) : '',
        'somoBalance'    => is_user_logged_in() ? somo_get_token_balance( get_current_user_id() ) : 0,
    ] );
}

/* ──────────────────────────────────────────
   HELPER FUNCTIONS
────────────────────────────────────────── */
function somo_get_token_balance( $user_id ) {
    global $wpdb;
    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT SUM(amount) FROM {$wpdb->prefix}somo_tokens WHERE user_id = %d", $user_id
    ) );
}

function somo_award_tokens( $user_id, $amount, $reason ) {
    global $wpdb;
    $wpdb->insert( $wpdb->prefix . 'somo_tokens', [
        'user_id'    => $user_id,
        'amount'     => $amount,
        'reason'     => $reason,
        'created_at' => current_time( 'mysql' ),
    ] );
}
