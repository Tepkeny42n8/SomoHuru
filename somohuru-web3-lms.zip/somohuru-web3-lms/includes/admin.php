<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', 'somo_admin_menu' );
function somo_admin_menu() {
    add_menu_page( 'SomoHuru LMS', 'SomoHuru', 'manage_options', 'somohuru', 'somo_admin_dashboard', 'dashicons-welcome-learn-more', 3 );
    add_submenu_page( 'somohuru', 'Courses',    'Courses',    'manage_options', 'somo-courses',    'somo_admin_courses' );
    add_submenu_page( 'somohuru', 'Students',   'Students',   'manage_options', 'somo-students',   'somo_admin_students' );
    add_submenu_page( 'somohuru', 'DAO',        'DAO',        'manage_options', 'somo-dao',        'somo_admin_dao' );
    add_submenu_page( 'somohuru', 'NFTs',       'NFTs',       'manage_options', 'somo-nfts',       'somo_admin_nfts' );
    add_submenu_page( 'somohuru', 'Web3 Settings', 'Web3 Settings', 'manage_options', 'somo-settings', 'somo_admin_settings' );
}

/* ── STYLES ── */
add_action( 'admin_head', 'somo_admin_styles' );
function somo_admin_styles() {
    if ( ! isset($_GET['page']) || strpos($_GET['page'], 'somo') === false ) return;
    echo '<style>
    .somo-admin-wrap { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; max-width: 1200px; }
    .somo-admin-header { background: linear-gradient(135deg,#1A56A0,#1A7A4A); color:#fff; padding:24px 28px; border-radius:10px; margin:16px 0 24px; display:flex; align-items:center; gap:16px; }
    .somo-admin-header h1 { margin:0; font-size:26px; color:#fff; }
    .somo-admin-header p { margin:4px 0 0; opacity:.85; font-size:14px; }
    .somo-cards { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:16px; margin-bottom:28px; }
    .somo-card { background:#fff; border:1px solid #e2e8f0; border-radius:10px; padding:20px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,.06); }
    .somo-card-num { font-size:36px; font-weight:700; color:#1A56A0; }
    .somo-card-label { font-size:13px; color:#666; margin-top:4px; }
    .somo-table-wrap { background:#fff; border:1px solid #e2e8f0; border-radius:10px; overflow:hidden; margin-bottom:24px; }
    .somo-table-wrap table { width:100%; border-collapse:collapse; }
    .somo-table-wrap th { background:#1A56A0; color:#fff; padding:12px 16px; text-align:left; font-size:13px; font-weight:600; }
    .somo-table-wrap td { padding:11px 16px; border-bottom:1px solid #f1f5f9; font-size:13px; vertical-align:middle; }
    .somo-table-wrap tr:last-child td { border-bottom:none; }
    .somo-table-wrap tr:hover td { background:#f8fafc; }
    .somo-form-box { background:#fff; border:1px solid #e2e8f0; border-radius:10px; padding:24px; margin-bottom:24px; }
    .somo-form-box h2 { margin:0 0 16px; font-size:18px; }
    .somo-form-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px; }
    .somo-form-group { display:flex; flex-direction:column; gap:4px; }
    .somo-form-group label { font-size:12px; font-weight:600; color:#444; text-transform:uppercase; letter-spacing:.5px; }
    .somo-form-group input, .somo-form-group select, .somo-form-group textarea { border:1px solid #d1d5db; border-radius:6px; padding:8px 12px; font-size:14px; }
    .somo-badge { display:inline-block; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:600; }
    .somo-badge-blue   { background:#dbeafe; color:#1e40af; }
    .somo-badge-green  { background:#dcfce7; color:#166534; }
    .somo-badge-gold   { background:#fef9c3; color:#854d0e; }
    .somo-badge-purple { background:#ede9fe; color:#5b21b6; }
    .somo-badge-red    { background:#fee2e2; color:#991b1b; }
    .somo-shortcode-box { background:#f0f9ff; border:1px solid #bae6fd; border-radius:8px; padding:12px 16px; margin-bottom:12px; font-size:13px; }
    .somo-shortcode-box code { background:#0369a1; color:#fff; padding:3px 8px; border-radius:4px; font-size:13px; }
    </style>';
}

/* ── DASHBOARD ── */
function somo_admin_dashboard() {
    global $wpdb;
    $courses  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}somo_courses" );
    $students = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}somo_progress" );
    $nfts     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}somo_nfts" );
    $tokens   = (int) $wpdb->get_var( "SELECT SUM(amount) FROM {$wpdb->prefix}somo_tokens" );
    $proposals = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}somo_proposals WHERE status='open'" );
    ?>
    <div class="somo-admin-wrap wrap">
      <div class="somo-admin-header">
        <span style="font-size:42px">🌍</span>
        <div>
          <h1>SomoHuru Web3 LMS</h1>
          <p>AI-Powered Inclusive Learning Platform — Admin Dashboard</p>
        </div>
      </div>
      <div class="somo-cards">
        <div class="somo-card"><div class="somo-card-num"><?= $courses ?></div><div class="somo-card-label">📚 Courses</div></div>
        <div class="somo-card"><div class="somo-card-num"><?= $students ?></div><div class="somo-card-label">👩‍🎓 Active Students</div></div>
        <div class="somo-card"><div class="somo-card-num"><?= $nfts ?></div><div class="somo-card-label">🏆 NFTs Minted</div></div>
        <div class="somo-card"><div class="somo-card-num"><?= number_format($tokens) ?></div><div class="somo-card-label">🪙 SOMO Awarded</div></div>
        <div class="somo-card"><div class="somo-card-num"><?= $proposals ?></div><div class="somo-card-label">🗳️ Open Proposals</div></div>
      </div>
      <div class="somo-form-box">
        <h2>📋 Shortcode Reference</h2>
        <div class="somo-shortcode-box">Full Dashboard: <code>[somo_dashboard]</code> — Paste on any page to show the complete student learning portal.</div>
        <div class="somo-shortcode-box">Course Viewer: <code>[somo_course]</code> — Shows lessons, quizzes, and completion. Works with <code>?somo_course=ID</code> URL params.</div>
        <div class="somo-shortcode-box">Wallet Widget: <code>[somo_wallet]</code> — MetaMask connect/disconnect button with SOMO balance.</div>
        <div class="somo-shortcode-box">DAO Governance: <code>[somo_dao]</code> — Proposals, voting, and DAO participation.</div>
        <div class="somo-shortcode-box">NFT Gallery: <code>[somo_nft_gallery]</code> — Displays all earned NFT certificates.</div>
      </div>
    </div>
    <?php
}

/* ── COURSES ADMIN ── */
function somo_admin_courses() {
    global $wpdb;

    // Handle save
    if ( isset($_POST['somo_save_course']) && check_admin_referer('somo_course_nonce') ) {
        $data = [
            'title'       => sanitize_text_field( $_POST['title'] ),
            'description' => sanitize_textarea_field( $_POST['description'] ),
            'category'    => sanitize_text_field( $_POST['category'] ),
            'difficulty'  => sanitize_text_field( $_POST['difficulty'] ),
            'somo_reward' => (int) $_POST['somo_reward'],
            'nft_enabled' => isset($_POST['nft_enabled']) ? 1 : 0,
        ];
        if ( isset($_POST['course_id']) && $_POST['course_id'] > 0 ) {
            $wpdb->update( $wpdb->prefix . 'somo_courses', $data, ['id' => (int)$_POST['course_id']] );
        } else {
            $wpdb->insert( $wpdb->prefix . 'somo_courses', $data );
            $cid = $wpdb->insert_id;
            // Add lessons if provided
            $lesson_titles   = $_POST['lesson_titles'] ?? [];
            $lesson_contents = $_POST['lesson_contents'] ?? [];
            $lesson_rewards  = $_POST['lesson_rewards'] ?? [];
            foreach ( $lesson_titles as $i => $lt ) {
                if ( ! trim($lt) ) continue;
                $wpdb->insert( $wpdb->prefix . 'somo_lessons', [
                    'course_id'   => $cid,
                    'title'       => sanitize_text_field($lt),
                    'content'     => sanitize_textarea_field($lesson_contents[$i] ?? ''),
                    'sort_order'  => $i + 1,
                    'somo_reward' => (int) ($lesson_rewards[$i] ?? 5),
                ] );
            }
        }
        echo '<div class="updated"><p>✅ Course saved!</p></div>';
    }

    $courses = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}somo_courses ORDER BY created_at DESC" );
    ?>
    <div class="somo-admin-wrap wrap">
      <div class="somo-admin-header"><span style="font-size:36px">📚</span><div><h1>Course Management</h1><p>Create and manage SomoHuru courses</p></div></div>
      <div class="somo-form-box">
        <h2>➕ Add New Course</h2>
        <form method="post">
          <?php wp_nonce_field('somo_course_nonce'); ?>
          <input type="hidden" name="course_id" value="0">
          <div class="somo-form-row">
            <div class="somo-form-group"><label>Course Title *</label><input name="title" required placeholder="e.g. Introduction to Science"></div>
            <div class="somo-form-group"><label>Category</label><input name="category" placeholder="e.g. Science, Math, English"></div>
          </div>
          <div class="somo-form-group" style="margin-bottom:16px"><label>Description</label><textarea name="description" rows="3" style="width:100%"></textarea></div>
          <div class="somo-form-row">
            <div class="somo-form-group"><label>Difficulty</label>
              <select name="difficulty"><option value="beginner">Beginner</option><option value="intermediate">Intermediate</option><option value="advanced">Advanced</option></select>
            </div>
            <div class="somo-form-group"><label>SOMO Reward (course completion)</label><input name="somo_reward" type="number" value="50"></div>
          </div>
          <label><input type="checkbox" name="nft_enabled" checked> 🏆 Award NFT Certificate on completion</label>
          <hr style="margin:20px 0">
          <h3>📖 Lessons</h3>
          <div id="somoLessonRows">
            <?php for($i=0;$i<3;$i++): ?>
            <div class="somo-form-row" style="border:1px solid #e2e8f0;border-radius:8px;padding:12px;margin-bottom:8px">
              <div class="somo-form-group"><label>Lesson <?= $i+1 ?> Title</label><input name="lesson_titles[]" placeholder="Lesson title"></div>
              <div class="somo-form-group"><label>SOMO Reward</label><input name="lesson_rewards[]" type="number" value="5"></div>
              <div class="somo-form-group" style="grid-column:1/-1"><label>Content</label><textarea name="lesson_contents[]" rows="2" style="width:100%" placeholder="Lesson content or instructions..."></textarea></div>
            </div>
            <?php endfor; ?>
          </div>
          <p><input type="submit" name="somo_save_course" class="button button-primary button-large" value="💾 Save Course"></p>
        </form>
      </div>
      <div class="somo-table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Difficulty</th><th>SOMO</th><th>NFT</th><th>Created</th></tr></thead>
          <tbody>
            <?php foreach($courses as $c): ?>
            <tr>
              <td><?= $c->id ?></td>
              <td><strong><?= esc_html($c->title) ?></strong></td>
              <td><?= esc_html($c->category) ?></td>
              <td><span class="somo-badge somo-badge-blue"><?= $c->difficulty ?></span></td>
              <td>🪙 <?= $c->somo_reward ?></td>
              <td><?= $c->nft_enabled ? '✅' : '—' ?></td>
              <td><?= date('M j Y', strtotime($c->created_at)) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
}

/* ── STUDENTS ADMIN ── */
function somo_admin_students() {
    global $wpdb;
    $students = $wpdb->get_results( "
        SELECT u.ID, u.display_name, u.user_email,
               um.meta_value as wallet,
               COALESCE(SUM(t.amount),0) as balance,
               COUNT(DISTINCT p.course_id) as courses
        FROM {$wpdb->users} u
        LEFT JOIN {$wpdb->usermeta} um ON um.user_id=u.ID AND um.meta_key='somo_wallet_address'
        LEFT JOIN {$wpdb->prefix}somo_tokens t ON t.user_id=u.ID
        LEFT JOIN {$wpdb->prefix}somo_progress p ON p.user_id=u.ID AND p.status='completed' AND p.lesson_id IS NULL
        GROUP BY u.ID ORDER BY balance DESC LIMIT 50
    " );
    ?>
    <div class="somo-admin-wrap wrap">
      <div class="somo-admin-header"><span style="font-size:36px">👩‍🎓</span><div><h1>Students</h1><p>View learner progress and Web3 data</p></div></div>
      <div class="somo-table-wrap">
        <table>
          <thead><tr><th>Student</th><th>Email</th><th>Wallet</th><th>SOMO Balance</th><th>Courses Done</th></tr></thead>
          <tbody>
            <?php foreach($students as $s): ?>
            <tr>
              <td><strong><?= esc_html($s->display_name) ?></strong></td>
              <td><?= esc_html($s->user_email) ?></td>
              <td><?= $s->wallet ? '<span class="somo-badge somo-badge-green">'.esc_html(substr($s->wallet,0,8).'...').'</span>' : '<span class="somo-badge somo-badge-red">No wallet</span>' ?></td>
              <td>🪙 <?= number_format($s->balance) ?></td>
              <td><?= $s->courses ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
}

/* ── DAO ADMIN ── */
function somo_admin_dao() {
    global $wpdb;
    $proposals = $wpdb->get_results( "SELECT p.*, u.display_name as author FROM {$wpdb->prefix}somo_proposals p LEFT JOIN {$wpdb->users} u ON u.ID=p.author_id ORDER BY p.created_at DESC" );

    // Handle status update
    if ( isset($_POST['somo_update_proposal']) && check_admin_referer('somo_dao_nonce') ) {
        $wpdb->update( $wpdb->prefix . 'somo_proposals', ['status' => sanitize_text_field($_POST['status'])], ['id' => (int)$_POST['proposal_id']] );
        echo '<div class="updated"><p>Proposal updated.</p></div>';
    }
    ?>
    <div class="somo-admin-wrap wrap">
      <div class="somo-admin-header"><span style="font-size:36px">🗳️</span><div><h1>DAO Governance</h1><p>Manage community proposals and votes</p></div></div>
      <div class="somo-table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Title</th><th>Author</th><th>Yes</th><th>No</th><th>Status</th><th>Ends</th><th>Action</th></tr></thead>
          <tbody>
            <?php foreach($proposals as $p): ?>
            <tr>
              <td><?= $p->id ?></td>
              <td><strong><?= esc_html($p->title) ?></strong><br><small><?= esc_html(wp_trim_words($p->description,15)) ?></small></td>
              <td><?= esc_html($p->author) ?></td>
              <td style="color:green">✅ <?= $p->votes_yes ?></td>
              <td style="color:red">❌ <?= $p->votes_no ?></td>
              <td><span class="somo-badge somo-badge-<?= $p->status==='open'?'green':($p->status==='passed'?'blue':'red') ?>"><?= $p->status ?></span></td>
              <td><?= $p->ends_at ? date('M j Y', strtotime($p->ends_at)) : '—' ?></td>
              <td>
                <form method="post" style="display:flex;gap:4px">
                  <?php wp_nonce_field('somo_dao_nonce'); ?>
                  <input type="hidden" name="proposal_id" value="<?= $p->id ?>">
                  <select name="status" style="font-size:12px;padding:4px">
                    <?php foreach(['open','closed','passed','rejected'] as $st): ?>
                    <option value="<?= $st ?>" <?= selected($p->status,$st,false) ?>><?= $st ?></option>
                    <?php endforeach; ?>
                  </select>
                  <input type="submit" name="somo_update_proposal" value="Save" class="button button-small">
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
}

/* ── NFT ADMIN ── */
function somo_admin_nfts() {
    global $wpdb;
    $nfts = $wpdb->get_results( "SELECT n.*, u.display_name, c.title as course_title FROM {$wpdb->prefix}somo_nfts n LEFT JOIN {$wpdb->users} u ON u.ID=n.user_id LEFT JOIN {$wpdb->prefix}somo_courses c ON c.id=n.course_id ORDER BY n.minted_at DESC" );
    ?>
    <div class="somo-admin-wrap wrap">
      <div class="somo-admin-header"><span style="font-size:36px">🏆</span><div><h1>NFT Certificates</h1><p>All minted NFT certificates</p></div></div>
      <div class="somo-table-wrap">
        <table>
          <thead><tr><th>Student</th><th>Course</th><th>Wallet</th><th>IPFS Hash</th><th>TX Hash</th><th>Date</th></tr></thead>
          <tbody>
            <?php foreach($nfts as $n): ?>
            <tr>
              <td><?= esc_html($n->display_name) ?></td>
              <td><?= esc_html($n->course_title) ?></td>
              <td><?= $n->wallet ? esc_html(substr($n->wallet,0,10).'...') : '—' ?></td>
              <td><?= $n->ipfs_hash ? '<a href="https://ipfs.io/ipfs/'.esc_attr($n->ipfs_hash).'" target="_blank">'.esc_html(substr($n->ipfs_hash,0,12).'...').'</a>' : '<em>Pending</em>' ?></td>
              <td><?= $n->tx_hash ? '<a href="https://mumbai.polygonscan.com/tx/'.esc_attr($n->tx_hash).'" target="_blank">'.esc_html(substr($n->tx_hash,0,12).'...').'</a>' : '<em>Pending</em>' ?></td>
              <td><?= date('M j Y', strtotime($n->minted_at)) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
}

/* ── SETTINGS ── */
function somo_admin_settings() {
    if ( isset($_POST['somo_save_settings']) && check_admin_referer('somo_settings_nonce') ) {
        $fields = ['somo_polygon_rpc','somo_contract_nft','somo_contract_token','somo_contract_dao','somo_pinata_api_key','somo_pinata_secret','somo_backend_url','somo_token_symbol','somo_platform_name'];
        foreach ($fields as $f) update_option($f, sanitize_text_field($_POST[$f] ?? ''));
        echo '<div class="updated"><p>✅ Settings saved!</p></div>';
    }
    ?>
    <div class="somo-admin-wrap wrap">
      <div class="somo-admin-header"><span style="font-size:36px">⚙️</span><div><h1>Web3 Settings</h1><p>Configure blockchain and API connections</p></div></div>
      <form method="post">
        <?php wp_nonce_field('somo_settings_nonce'); ?>
        <div class="somo-form-box">
          <h2>🌐 Platform</h2>
          <div class="somo-form-row">
            <div class="somo-form-group"><label>Platform Name</label><input name="somo_platform_name" value="<?= esc_attr(get_option('somo_platform_name','SomoHuru')) ?>"></div>
            <div class="somo-form-group"><label>Token Symbol</label><input name="somo_token_symbol" value="<?= esc_attr(get_option('somo_token_symbol','SOMO')) ?>"></div>
          </div>
        </div>
        <div class="somo-form-box">
          <h2>⛓️ Blockchain (Polygon)</h2>
          <div class="somo-form-group" style="margin-bottom:16px"><label>Polygon RPC URL</label><input name="somo_polygon_rpc" value="<?= esc_attr(get_option('somo_polygon_rpc','https://rpc-mumbai.maticvigil.com')) ?>" placeholder="https://rpc-mumbai.maticvigil.com"></div>
          <div class="somo-form-row">
            <div class="somo-form-group"><label>NFT Certificate Contract Address</label><input name="somo_contract_nft" value="<?= esc_attr(get_option('somo_contract_nft')) ?>" placeholder="0x..."></div>
            <div class="somo-form-group"><label>SOMO Token Contract Address</label><input name="somo_contract_token" value="<?= esc_attr(get_option('somo_contract_token')) ?>" placeholder="0x..."></div>
          </div>
          <div class="somo-form-group"><label>DAO Contract Address</label><input name="somo_contract_dao" value="<?= esc_attr(get_option('somo_contract_dao')) ?>" placeholder="0x..."></div>
        </div>
        <div class="somo-form-box">
          <h2>📦 IPFS (Pinata)</h2>
          <div class="somo-form-row">
            <div class="somo-form-group"><label>Pinata API Key</label><input name="somo_pinata_api_key" value="<?= esc_attr(get_option('somo_pinata_api_key')) ?>"></div>
            <div class="somo-form-group"><label>Pinata Secret</label><input type="password" name="somo_pinata_secret" value="<?= esc_attr(get_option('somo_pinata_secret')) ?>"></div>
          </div>
        </div>
        <div class="somo-form-box">
          <h2>🖥️ Backend API</h2>
          <div class="somo-form-group"><label>Node.js Backend URL (for minting)</label><input name="somo_backend_url" value="<?= esc_attr(get_option('somo_backend_url')) ?>" placeholder="https://your-backend.com"></div>
          <p style="font-size:12px;color:#666">This is your Node.js server that handles smart contract interactions. Leave blank to use simulated mode.</p>
        </div>
        <input type="submit" name="somo_save_settings" class="button button-primary button-large" value="💾 Save All Settings">
      </form>
    </div>
    <?php
}
