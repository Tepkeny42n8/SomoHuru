<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ── Save wallet address ── */
add_action( 'wp_ajax_somo_save_wallet', 'somo_ajax_save_wallet' );
function somo_ajax_save_wallet() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    $wallet = sanitize_text_field( $_POST['wallet'] ?? '' );
    if ( ! $wallet || ! preg_match('/^0x[a-fA-F0-9]{40}$/', $wallet) ) {
        wp_send_json_error( 'Invalid wallet address.' );
    }
    update_user_meta( get_current_user_id(), 'somo_wallet_address', $wallet );
    wp_send_json_success( [ 'wallet' => $wallet, 'message' => 'Wallet connected!' ] );
}

/* ── Disconnect wallet ── */
add_action( 'wp_ajax_somo_disconnect_wallet', 'somo_ajax_disconnect_wallet' );
function somo_ajax_disconnect_wallet() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    delete_user_meta( get_current_user_id(), 'somo_wallet_address' );
    wp_send_json_success( 'Wallet disconnected.' );
}

/* ── Complete a lesson ── */
add_action( 'wp_ajax_somo_complete_lesson', 'somo_ajax_complete_lesson' );
function somo_ajax_complete_lesson() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    $uid       = get_current_user_id();
    $lesson_id = (int) ( $_POST['lesson_id'] ?? 0 );
    $course_id = (int) ( $_POST['course_id'] ?? 0 );
    if ( ! $uid || ! $lesson_id || ! $course_id ) wp_send_json_error( 'Missing data.' );

    global $wpdb;

    // Check if already completed
    $done = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND lesson_id=%d AND status='completed'", $uid, $lesson_id
    ) );
    if ( $done ) wp_send_json_success( [ 'already_done' => true, 'balance' => somo_get_token_balance($uid) ] );

    // Mark lesson complete
    $existing = $wpdb->get_row( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND lesson_id=%d", $uid, $lesson_id
    ) );
    if ( $existing ) {
        $wpdb->update( $wpdb->prefix . 'somo_progress',
            [ 'status' => 'completed', 'completed_at' => current_time('mysql') ],
            [ 'id' => $existing->id ]
        );
    } else {
        $wpdb->insert( $wpdb->prefix . 'somo_progress', [
            'user_id'      => $uid,
            'course_id'    => $course_id,
            'lesson_id'    => $lesson_id,
            'status'       => 'completed',
            'completed_at' => current_time('mysql'),
        ] );
    }

    // Award tokens
    $lesson = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_lessons WHERE id=%d", $lesson_id ) );
    $reward = $lesson ? (int) $lesson->somo_reward : 5;
    somo_award_tokens( $uid, $reward, "Completed lesson: {$lesson->title}" );

    // Update course progress
    $wpdb->update( $wpdb->prefix . 'somo_progress',
        [ 'status' => 'in_progress' ],
        [ 'user_id' => $uid, 'course_id' => $course_id, 'lesson_id' => null ]
    );

    // Check if all lessons done
    $total  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}somo_lessons WHERE course_id=%d", $course_id ) );
    $done_c = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND course_id=%d AND lesson_id IS NOT NULL AND status='completed'", $uid, $course_id
    ) );
    $course_completed = ( $done_c >= $total );
    $nft_minted = false;

    if ( $course_completed ) {
        // Mark course complete
        $wpdb->update( $wpdb->prefix . 'somo_progress',
            [ 'status' => 'completed', 'completed_at' => current_time('mysql') ],
            [ 'user_id' => $uid, 'course_id' => $course_id, 'lesson_id' => null ]
        );
        // Course completion bonus
        $course = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_courses WHERE id=%d", $course_id ) );
        somo_award_tokens( $uid, $course->somo_reward, "Completed course: {$course->title}" );

        // Create NFT record (actual minting via backend)
        $wallet = get_user_meta( $uid, 'somo_wallet_address', true );
        if ( $wallet && $course->nft_enabled ) {
            $already_nft = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}somo_nfts WHERE user_id=%d AND course_id=%d", $uid, $course_id
            ) );
            if ( ! $already_nft ) {
                $wpdb->insert( $wpdb->prefix . 'somo_nfts', [
                    'user_id'    => $uid,
                    'course_id'  => $course_id,
                    'wallet'     => $wallet,
                    'minted_at'  => current_time('mysql'),
                ] );
                $nft_minted = true;
            }
        }
    }

    wp_send_json_success( [
        'tokens_awarded'   => $reward,
        'new_balance'      => somo_get_token_balance( $uid ),
        'course_completed' => $course_completed,
        'nft_minted'       => $nft_minted,
        'lesson_done'      => true,
    ] );
}

/* ── Submit quiz answer ── */
add_action( 'wp_ajax_somo_submit_quiz', 'somo_ajax_submit_quiz' );
function somo_ajax_submit_quiz() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    $quiz_id = (int) ( $_POST['quiz_id'] ?? 0 );
    $answer  = strtoupper( sanitize_text_field( $_POST['answer'] ?? '' ) );
    global $wpdb;
    $quiz    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_quizzes WHERE id=%d", $quiz_id ) );
    if ( ! $quiz ) wp_send_json_error( 'Quiz not found.' );
    $correct = ( $answer === strtoupper($quiz->answer) );
    $tokens  = 0;
    if ( $correct ) {
        $tokens = (int) $quiz->points;
        somo_award_tokens( get_current_user_id(), $tokens, 'Correct quiz answer' );
    }
    wp_send_json_success( [ 'correct' => $correct, 'tokens' => $tokens, 'correct_answer' => $quiz->answer, 'balance' => somo_get_token_balance(get_current_user_id()) ] );
}

/* ── Submit DAO proposal ── */
add_action( 'wp_ajax_somo_submit_proposal', 'somo_ajax_submit_proposal' );
function somo_ajax_submit_proposal() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    $uid   = get_current_user_id();
    $title = sanitize_text_field( $_POST['title'] ?? '' );
    $desc  = sanitize_textarea_field( $_POST['description'] ?? '' );
    if ( ! $title ) wp_send_json_error( 'Title required.' );
    // Require 10 tokens to submit
    if ( somo_get_token_balance($uid) < 10 ) wp_send_json_error( 'You need at least 10 SOMO tokens to submit a proposal.' );
    global $wpdb;
    $wpdb->insert( $wpdb->prefix . 'somo_proposals', [
        'author_id'   => $uid,
        'title'       => $title,
        'description' => $desc,
        'status'      => 'open',
        'ends_at'     => date( 'Y-m-d H:i:s', strtotime('+7 days') ),
        'created_at'  => current_time('mysql'),
    ] );
    wp_send_json_success( [ 'id' => $wpdb->insert_id, 'message' => 'Proposal submitted!' ] );
}

/* ── Cast DAO vote ── */
add_action( 'wp_ajax_somo_cast_vote', 'somo_ajax_cast_vote' );
function somo_ajax_cast_vote() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    $uid         = get_current_user_id();
    $proposal_id = (int) ( $_POST['proposal_id'] ?? 0 );
    $vote        = sanitize_text_field( $_POST['vote'] ?? '' );
    if ( ! in_array($vote, ['yes','no']) ) wp_send_json_error( 'Invalid vote.' );
    global $wpdb;
    $already = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}somo_votes WHERE proposal_id=%d AND user_id=%d", $proposal_id, $uid
    ) );
    if ( $already ) wp_send_json_error( 'Already voted.' );
    $wpdb->insert( $wpdb->prefix . 'somo_votes', [
        'proposal_id' => $proposal_id,
        'user_id'     => $uid,
        'vote'        => $vote,
        'created_at'  => current_time('mysql'),
    ] );
    $col = $vote === 'yes' ? 'votes_yes' : 'votes_no';
    $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}somo_proposals SET $col = $col + 1 WHERE id=%d", $proposal_id ) );
    wp_send_json_success( 'Vote cast!' );
}

/* ── Save NFT mint result from frontend ── */
add_action( 'wp_ajax_somo_save_nft_mint', 'somo_ajax_save_nft_mint' );
function somo_ajax_save_nft_mint() {
    check_ajax_referer( 'somo_nonce', 'nonce' );
    $uid       = get_current_user_id();
    $course_id = (int) sanitize_text_field( $_POST['course_id'] ?? 0 );
    $tx_hash   = sanitize_text_field( $_POST['tx_hash'] ?? '' );
    $ipfs_hash = sanitize_text_field( $_POST['ipfs_hash'] ?? '' );
    $token_id  = sanitize_text_field( $_POST['token_id'] ?? '' );
    global $wpdb;
    $wpdb->update( $wpdb->prefix . 'somo_nfts',
        [ 'tx_hash' => $tx_hash, 'ipfs_hash' => $ipfs_hash, 'token_id' => $token_id ],
        [ 'user_id' => $uid, 'course_id' => $course_id ]
    );
    wp_send_json_success( 'NFT record updated.' );
}
