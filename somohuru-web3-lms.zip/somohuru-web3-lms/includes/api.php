<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'rest_api_init', 'somo_register_routes' );
function somo_register_routes() {
    register_rest_route( 'somohuru/v1', '/leaderboard', [
        'methods'  => 'GET',
        'callback' => 'somo_api_leaderboard',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( 'somohuru/v1', '/student/(?P<id>\d+)', [
        'methods'  => 'GET',
        'callback' => 'somo_api_student',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( 'somohuru/v1', '/nft/confirm', [
        'methods'  => 'POST',
        'callback' => 'somo_api_nft_confirm',
        'permission_callback' => '__return_true',
    ] );
}

function somo_api_leaderboard() {
    global $wpdb;
    $rows = $wpdb->get_results( "
        SELECT u.ID, u.display_name, COALESCE(SUM(t.amount),0) as balance,
               COUNT(DISTINCT n.id) as nfts
        FROM {$wpdb->users} u
        LEFT JOIN {$wpdb->prefix}somo_tokens t ON t.user_id=u.ID
        LEFT JOIN {$wpdb->prefix}somo_nfts n ON n.user_id=u.ID
        GROUP BY u.ID ORDER BY balance DESC LIMIT 20
    " );
    return rest_ensure_response( $rows );
}

function somo_api_student( $request ) {
    $uid = (int) $request['id'];
    global $wpdb;
    $data = [
        'balance'   => somo_get_token_balance($uid),
        'wallet'    => get_user_meta($uid,'somo_wallet_address',true),
        'nfts'      => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}somo_nfts WHERE user_id=%d",$uid)),
        'completed' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND status='completed' AND lesson_id IS NULL",$uid)),
    ];
    return rest_ensure_response( $data );
}

function somo_api_nft_confirm( $request ) {
    $params = $request->get_json_params();
    $user_id   = (int) ($params['user_id'] ?? 0);
    $course_id = (int) ($params['course_id'] ?? 0);
    $tx_hash   = sanitize_text_field($params['tx_hash'] ?? '');
    $ipfs_hash = sanitize_text_field($params['ipfs_hash'] ?? '');
    $token_id  = sanitize_text_field($params['token_id'] ?? '');
    if ( ! $user_id || ! $course_id ) return new WP_Error('missing_data','Missing data',['status'=>400]);
    global $wpdb;
    $wpdb->update( $wpdb->prefix . 'somo_nfts',
        ['tx_hash'=>$tx_hash,'ipfs_hash'=>$ipfs_hash,'token_id'=>$token_id],
        ['user_id'=>$user_id,'course_id'=>$course_id]
    );
    return rest_ensure_response(['success'=>true]);
}
