<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ══════════════════════════════════════════════════════
   [somo_dashboard]  — Student home
══════════════════════════════════════════════════════ */
add_shortcode( 'somo_dashboard', 'somo_sc_dashboard' );
function somo_sc_dashboard( $atts ) {
    if ( ! is_user_logged_in() ) return '<p class="somo-msg">Please <a href="' . wp_login_url() . '">log in</a> to access your dashboard.</p>';
    $user    = wp_get_current_user();
    $uid     = $user->ID;
    $wallet  = get_user_meta( $uid, 'somo_wallet_address', true );
    $balance = somo_get_token_balance( $uid );
    global $wpdb;
    $completed = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND status='completed' AND lesson_id IS NULL", $uid
    ) );
    $nfts = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}somo_nfts WHERE user_id=%d", $uid
    ) );
    $courses = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}somo_courses ORDER BY created_at DESC" );
    ob_start(); ?>
<div class="somo-wrap">
  <!-- TOP BAR -->
  <div class="somo-topbar">
    <div class="somo-brand">
      <span class="somo-logo-icon">🌍</span>
      <span class="somo-logo-text">SomoHuru</span>
    </div>
    <div class="somo-wallet-bar">
      <?php if ( $wallet ) : ?>
        <span class="somo-badge somo-badge-green">✅ <?= esc_html( substr($wallet,0,6) . '...' . substr($wallet,-4) ) ?></span>
        <span class="somo-badge somo-badge-gold">🪙 <?= $balance ?> SOMO</span>
      <?php else : ?>
        <button class="somo-btn somo-btn-connect" id="somoConnectWallet">🦊 Connect Wallet</button>
      <?php endif; ?>
      <span class="somo-user-name">👋 <?= esc_html( $user->display_name ) ?></span>
    </div>
  </div>

  <!-- STATS ROW -->
  <div class="somo-stats-row">
    <div class="somo-stat-card somo-stat-blue">
      <div class="somo-stat-num"><?= count($courses) ?></div>
      <div class="somo-stat-label">Available Courses</div>
    </div>
    <div class="somo-stat-card somo-stat-green">
      <div class="somo-stat-num"><?= $completed ?></div>
      <div class="somo-stat-label">Courses Completed</div>
    </div>
    <div class="somo-stat-card somo-stat-gold">
      <div class="somo-stat-num"><?= $balance ?></div>
      <div class="somo-stat-label">SOMO Tokens</div>
    </div>
    <div class="somo-stat-card somo-stat-purple">
      <div class="somo-stat-num"><?= $nfts ?></div>
      <div class="somo-stat-label">NFT Certificates</div>
    </div>
  </div>

  <!-- COURSES GRID -->
  <h2 class="somo-section-title">📚 Available Courses</h2>
  <div class="somo-courses-grid">
    <?php foreach ( $courses as $c ) :
        $progress = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND course_id=%d AND lesson_id IS NULL LIMIT 1", $uid, $c->id
        ) );
        $status   = $progress ? $progress->status : 'not_started';
        $lessons_total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}somo_lessons WHERE course_id=%d", $c->id ) );
        $lessons_done  = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND course_id=%d AND lesson_id IS NOT NULL AND status='completed'", $uid, $c->id
        ) );
        $pct = $lessons_total > 0 ? round( $lessons_done / $lessons_total * 100 ) : 0;
    ?>
    <div class="somo-course-card">
      <div class="somo-course-cat"><?= esc_html($c->category) ?></div>
      <div class="somo-course-diff somo-diff-<?= $c->difficulty ?>"><?= ucfirst($c->difficulty) ?></div>
      <h3 class="somo-course-title"><?= esc_html($c->title) ?></h3>
      <p class="somo-course-desc"><?= esc_html( wp_trim_words($c->description, 20) ) ?></p>
      <div class="somo-progress-bar-wrap">
        <div class="somo-progress-bar" style="width:<?= $pct ?>%"></div>
      </div>
      <div class="somo-course-meta">
        <span>📖 <?= $lessons_total ?> lessons</span>
        <span>🪙 <?= $c->somo_reward ?> SOMO</span>
        <?php if($c->nft_enabled): ?><span>🏆 NFT Cert</span><?php endif; ?>
      </div>
      <a href="?somo_course=<?= $c->id ?>" class="somo-btn somo-btn-primary">
        <?= $status === 'completed' ? '✅ Review' : ($status === 'in_progress' ? '▶ Continue' : '🚀 Start') ?>
      </a>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- DAO SECTION -->
  <h2 class="somo-section-title">🗳️ Community DAO</h2>
  <?= do_shortcode('[somo_dao]') ?>

  <!-- NFT GALLERY -->
  <h2 class="somo-section-title">🏆 My NFT Certificates</h2>
  <?= do_shortcode('[somo_nft_gallery]') ?>
</div>
<?php
    return ob_get_clean();
}

/* ══════════════════════════════════════════════════════
   [somo_course]  — Single course & lesson viewer
══════════════════════════════════════════════════════ */
add_shortcode( 'somo_course', 'somo_sc_course' );
function somo_sc_course( $atts ) {
    if ( ! is_user_logged_in() ) return '<p class="somo-msg">Please log in.</p>';
    $uid       = get_current_user_id();
    $course_id = isset($_GET['somo_course']) ? (int)$_GET['somo_course'] : (int)($atts['id'] ?? 0);
    $lesson_id = isset($_GET['somo_lesson']) ? (int)$_GET['somo_lesson'] : 0;
    if ( ! $course_id ) return somo_sc_dashboard([]);
    global $wpdb;
    $course  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_courses WHERE id=%d", $course_id ) );
    if ( ! $course ) return '<p class="somo-msg">Course not found.</p>';
    $lessons = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_lessons WHERE course_id=%d ORDER BY sort_order", $course_id ) );

    // Auto-enroll
    $enrolment = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND course_id=%d AND lesson_id IS NULL", $uid, $course_id
    ) );
    if ( ! $enrolment ) {
        $wpdb->insert( $wpdb->prefix . 'somo_progress', [
            'user_id'   => $uid, 'course_id' => $course_id, 'status' => 'enrolled'
        ] );
    }

    $lesson  = $lesson_id ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_lessons WHERE id=%d AND course_id=%d", $lesson_id, $course_id ) ) : null;
    $quiz    = $lesson ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}somo_quizzes WHERE lesson_id=%d LIMIT 1", $lesson->id ) ) : null;

    ob_start(); ?>
<div class="somo-wrap">
  <div class="somo-topbar">
    <div class="somo-brand"><span class="somo-logo-icon">🌍</span><span class="somo-logo-text">SomoHuru</span></div>
    <a href="?" class="somo-btn somo-btn-outline">← Dashboard</a>
  </div>

  <div class="somo-course-layout">
    <!-- SIDEBAR -->
    <div class="somo-sidebar">
      <div class="somo-sidebar-title"><?= esc_html($course->title) ?></div>
      <div class="somo-lesson-list">
        <?php foreach ( $lessons as $i => $l ) :
            $done = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}somo_progress WHERE user_id=%d AND lesson_id=%d AND status='completed'", $uid, $l->id
            ) );
        ?>
        <a href="?somo_course=<?= $course_id ?>&somo_lesson=<?= $l->id ?>"
           class="somo-lesson-item <?= $lesson_id == $l->id ? 'active' : '' ?> <?= $done ? 'done' : '' ?>">
          <span class="somo-lesson-num"><?= $done ? '✅' : ($i+1) ?></span>
          <span class="somo-lesson-name"><?= esc_html($l->title) ?></span>
          <span class="somo-lesson-tokens">+<?= $l->somo_reward ?></span>
        </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="somo-lesson-main">
      <?php if ( $lesson ) : ?>
        <h1 class="somo-lesson-title"><?= esc_html($lesson->title) ?></h1>
        <?php if ( $lesson->video_url ) : ?>
          <div class="somo-video-wrap">
            <iframe src="<?= esc_url($lesson->video_url) ?>" allowfullscreen></iframe>
          </div>
        <?php endif; ?>
        <div class="somo-lesson-content"><?= wpautop( $lesson->content ) ?></div>

        <?php if ( $quiz ) :
            $opts = json_decode( $quiz->options, true ); ?>
        <div class="somo-quiz-box" id="somoQuiz" data-lesson="<?= $lesson->id ?>" data-answer="<?= esc_attr($quiz->answer) ?>" data-points="<?= $quiz->points ?>">
          <div class="somo-quiz-title">📝 Quick Quiz</div>
          <p class="somo-quiz-q"><?= esc_html($quiz->question) ?></p>
          <div class="somo-quiz-options">
            <?php foreach ( $opts as $key => $val ) : ?>
            <button class="somo-quiz-opt" data-key="<?= $key ?>"><?= $key ?>. <?= esc_html($val) ?></button>
            <?php endforeach; ?>
          </div>
          <div class="somo-quiz-result" id="somoQuizResult"></div>
        </div>
        <?php endif; ?>

        <div class="somo-lesson-actions">
          <button class="somo-btn somo-btn-primary somo-btn-lg" id="somoCompleteLesson"
            data-lesson="<?= $lesson->id ?>" data-course="<?= $course_id ?>" data-reward="<?= $lesson->somo_reward ?>">
            ✅ Mark as Complete (+<?= $lesson->somo_reward ?> SOMO)
          </button>
        </div>
        <div id="somoLessonMsg" class="somo-msg-box" style="display:none"></div>

      <?php else : ?>
        <div class="somo-course-intro">
          <h1><?= esc_html($course->title) ?></h1>
          <p><?= esc_html($course->description) ?></p>
          <div class="somo-course-meta-big">
            <span>📖 <?= count($lessons) ?> Lessons</span>
            <span>🪙 <?= $course->somo_reward ?> SOMO on completion</span>
            <?php if($course->nft_enabled): ?><span>🏆 NFT Certificate awarded</span><?php endif; ?>
          </div>
          <?php if ( $lessons ) : ?>
          <a href="?somo_course=<?= $course_id ?>&somo_lesson=<?= $lessons[0]->id ?>" class="somo-btn somo-btn-primary somo-btn-lg">
            🚀 Start First Lesson
          </a>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
    <?php return ob_get_clean();
}

/* ══════════════════════════════════════════════════════
   [somo_dao]  — DAO Governance
══════════════════════════════════════════════════════ */
add_shortcode( 'somo_dao', 'somo_sc_dao' );
function somo_sc_dao() {
    if ( ! is_user_logged_in() ) return '<p class="somo-msg">Log in to participate.</p>';
    $uid = get_current_user_id();
    global $wpdb;
    $proposals = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}somo_proposals ORDER BY created_at DESC LIMIT 10" );
    ob_start(); ?>
<div class="somo-dao-wrap">
  <div class="somo-dao-header">
    <h3>🗳️ DAO Proposals</h3>
    <button class="somo-btn somo-btn-outline" id="somoNewProposal">+ New Proposal</button>
  </div>
  <div class="somo-dao-form" id="somoProposalForm" style="display:none">
    <input type="text" id="somoProposalTitle" placeholder="Proposal Title" class="somo-input">
    <textarea id="somoProposalDesc" placeholder="Describe your proposal..." class="somo-textarea"></textarea>
    <button class="somo-btn somo-btn-primary" id="somoSubmitProposal">Submit Proposal</button>
  </div>
  <div class="somo-proposals-list">
    <?php if ( empty($proposals) ) : ?>
      <div class="somo-empty">No proposals yet. Be the first to submit one!</div>
    <?php endif; ?>
    <?php foreach ( $proposals as $p ) :
        $voted = $wpdb->get_var( $wpdb->prepare(
            "SELECT vote FROM {$wpdb->prefix}somo_votes WHERE proposal_id=%d AND user_id=%d", $p->id, $uid
        ) );
        $total = $p->votes_yes + $p->votes_no;
        $yes_pct = $total > 0 ? round($p->votes_yes / $total * 100) : 0;
    ?>
    <div class="somo-proposal-card somo-status-<?= $p->status ?>">
      <div class="somo-proposal-header">
        <span class="somo-proposal-title"><?= esc_html($p->title) ?></span>
        <span class="somo-dao-badge somo-dao-<?= $p->status ?>"><?= ucfirst($p->status) ?></span>
      </div>
      <p class="somo-proposal-desc"><?= esc_html($p->description) ?></p>
      <div class="somo-vote-bar-wrap">
        <div class="somo-vote-bar-yes" style="width:<?= $yes_pct ?>%"></div>
      </div>
      <div class="somo-vote-counts">
        <span>✅ <?= $p->votes_yes ?> Yes</span>
        <span>❌ <?= $p->votes_no ?> No</span>
      </div>
      <?php if ( $p->status === 'open' && ! $voted ) : ?>
      <div class="somo-vote-actions">
        <button class="somo-btn somo-btn-green somo-vote-btn" data-proposal="<?= $p->id ?>" data-vote="yes">✅ Vote Yes</button>
        <button class="somo-btn somo-btn-red somo-vote-btn" data-proposal="<?= $p->id ?>" data-vote="no">❌ Vote No</button>
      </div>
      <?php elseif ( $voted ) : ?>
        <div class="somo-voted-label">You voted: <strong><?= $voted ?></strong></div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
</div>
    <?php return ob_get_clean();
}

/* ══════════════════════════════════════════════════════
   [somo_nft_gallery]  — Show user's NFT certs
══════════════════════════════════════════════════════ */
add_shortcode( 'somo_nft_gallery', 'somo_sc_nft_gallery' );
function somo_sc_nft_gallery() {
    if ( ! is_user_logged_in() ) return '';
    global $wpdb;
    $uid  = get_current_user_id();
    $nfts = $wpdb->get_results( $wpdb->prepare(
        "SELECT n.*, c.title as course_title FROM {$wpdb->prefix}somo_nfts n
         LEFT JOIN {$wpdb->prefix}somo_courses c ON c.id=n.course_id
         WHERE n.user_id=%d ORDER BY n.minted_at DESC", $uid
    ) );
    if ( empty($nfts) ) return '<div class="somo-empty">Complete a course to earn your first NFT certificate! 🏆</div>';
    ob_start(); ?>
<div class="somo-nft-grid">
  <?php foreach ( $nfts as $nft ) : ?>
  <div class="somo-nft-card">
    <div class="somo-nft-badge">🏆</div>
    <div class="somo-nft-course"><?= esc_html($nft->course_title) ?></div>
    <div class="somo-nft-date">Earned: <?= date('M j, Y', strtotime($nft->minted_at)) ?></div>
    <?php if ( $nft->ipfs_hash ) : ?>
      <a href="https://ipfs.io/ipfs/<?= esc_attr($nft->ipfs_hash) ?>" target="_blank" class="somo-btn somo-btn-outline somo-btn-sm">View on IPFS</a>
    <?php endif; ?>
    <?php if ( $nft->tx_hash ) : ?>
      <a href="https://mumbai.polygonscan.com/tx/<?= esc_attr($nft->tx_hash) ?>" target="_blank" class="somo-btn somo-btn-outline somo-btn-sm">View on Chain</a>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
    <?php return ob_get_clean();
}

/* ══════════════════════════════════════════════════════
   [somo_wallet]  — Wallet connect widget
══════════════════════════════════════════════════════ */
add_shortcode( 'somo_wallet', 'somo_sc_wallet' );
function somo_sc_wallet() {
    $uid    = get_current_user_id();
    $wallet = get_user_meta( $uid, 'somo_wallet_address', true );
    $bal    = somo_get_token_balance( $uid );
    ob_start(); ?>
<div class="somo-wallet-widget">
  <?php if ( $wallet ) : ?>
    <div class="somo-wallet-connected">
      <span class="somo-wallet-icon">🦊</span>
      <div>
        <div class="somo-wallet-addr"><?= esc_html( substr($wallet,0,8) . '...' . substr($wallet,-6) ) ?></div>
        <div class="somo-wallet-balance">🪙 <?= $bal ?> SOMO</div>
      </div>
      <button class="somo-btn somo-btn-outline somo-btn-sm" id="somoDisconnectWallet">Disconnect</button>
    </div>
  <?php else : ?>
    <button class="somo-btn somo-btn-connect" id="somoConnectWallet">
      🦊 Connect MetaMask Wallet
    </button>
    <p class="somo-wallet-hint">Connect your wallet to earn NFT certificates and SOMO tokens.</p>
  <?php endif; ?>
</div>
    <?php return ob_get_clean();
}
