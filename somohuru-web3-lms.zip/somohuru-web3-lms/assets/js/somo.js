/* SomoHuru Web3 LMS — Main JS */
(function($) {
  'use strict';

  const SOMO = window.somoData || {};
  let web3, currentAccount;

  /* ────────────────────────────────────────
     METAMASK WALLET CONNECTION
  ──────────────────────────────────────── */
  async function connectWallet() {
    if (typeof window.ethereum === 'undefined') {
      showToast('Please install MetaMask to use Web3 features! 🦊', 'warn');
      window.open('https://metamask.io/download/', '_blank');
      return;
    }
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      currentAccount = accounts[0];
      web3 = new Web3(window.ethereum);

      // Try switch to Polygon Mumbai
      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: '0x13881' }], // Mumbai testnet
        });
      } catch (sw) {
        if (sw.code === 4902) {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: '0x13881',
              chainName: 'Polygon Mumbai Testnet',
              nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
              rpcUrls: ['https://rpc-mumbai.maticvigil.com'],
              blockExplorerUrls: ['https://mumbai.polygonscan.com'],
            }]
          });
        }
      }

      // Save to WordPress
      $.post(SOMO.ajaxUrl, {
        action: 'somo_save_wallet',
        nonce:  SOMO.nonce,
        wallet: currentAccount,
      }, function(res) {
        if (res.success) {
          showToast('✅ Wallet connected! ' + shortAddr(currentAccount), 'success');
          setTimeout(() => location.reload(), 1200);
        } else {
          showToast('Error: ' + res.data, 'error');
        }
      });
    } catch (err) {
      if (err.code === 4001) {
        showToast('Connection rejected. Please try again.', 'warn');
      } else {
        showToast('Error connecting wallet: ' + err.message, 'error');
      }
    }
  }

  function disconnectWallet() {
    $.post(SOMO.ajaxUrl, { action: 'somo_disconnect_wallet', nonce: SOMO.nonce }, function() {
      showToast('Wallet disconnected.', 'info');
      setTimeout(() => location.reload(), 800);
    });
  }

  /* ────────────────────────────────────────
     LESSON COMPLETION
  ──────────────────────────────────────── */
  function completeLesson($btn) {
    const lessonId = $btn.data('lesson');
    const courseId = $btn.data('course');
    const reward   = $btn.data('reward');
    $btn.prop('disabled', true).text('Processing...');

    $.post(SOMO.ajaxUrl, {
      action:    'somo_complete_lesson',
      nonce:     SOMO.nonce,
      lesson_id: lessonId,
      course_id: courseId,
    }, function(res) {
      if (res.success) {
        const d = res.data;
        if (d.already_done) {
          showMsg('#somoLessonMsg', 'You already completed this lesson! ✅', 'success');
          $btn.text('✅ Already Completed');
          return;
        }
        $btn.text('✅ Completed!').addClass('somo-btn-done');
        showMsg('#somoLessonMsg', `🎉 Lesson complete! +${reward} SOMO tokens awarded. Balance: ${d.new_balance} SOMO`, 'success');

        if (d.course_completed) {
          setTimeout(() => {
            showModal(
              '🏆 Course Complete!',
              `<p>Congratulations! You've completed the course and earned <strong>${d.new_balance} SOMO</strong> tokens!</p>
               ${d.nft_minted ? '<p>🏆 Your NFT Certificate is being minted and will appear in your wallet shortly!</p>' : ''}
               <p>Your achievement is recorded on the Polygon blockchain.</p>`,
              'Go to Dashboard', '?'
            );
          }, 600);
        }
      } else {
        showMsg('#somoLessonMsg', 'Error: ' + res.data, 'error');
        $btn.prop('disabled', false).text(`✅ Mark as Complete (+${reward} SOMO)`);
      }
    });
  }

  /* ────────────────────────────────────────
     QUIZ
  ──────────────────────────────────────── */
  $(document).on('click', '.somo-quiz-opt', function() {
    const $box    = $(this).closest('.somo-quiz-box');
    const correct = $box.data('answer');
    const chosen  = $(this).data('key');
    $('.somo-quiz-opt').prop('disabled', true);
    if (chosen === correct) {
      $(this).addClass('somo-opt-correct');
      $('#somoQuizResult').html('<div class="somo-quiz-correct">✅ Correct! Well done!</div>');
    } else {
      $(this).addClass('somo-opt-wrong');
      $(`.somo-quiz-opt[data-key="${correct}"]`).addClass('somo-opt-correct');
      $('#somoQuizResult').html(`<div class="somo-quiz-wrong">❌ Not quite. The correct answer was <strong>${correct}</strong>.</div>`);
    }
  });

  /* ────────────────────────────────────────
     DAO
  ──────────────────────────────────────── */
  $('#somoNewProposal').on('click', function() {
    $('#somoProposalForm').slideToggle();
  });

  $('#somoSubmitProposal').on('click', function() {
    const title = $('#somoProposalTitle').val().trim();
    const desc  = $('#somoProposalDesc').val().trim();
    if (!title) { showToast('Please enter a proposal title.', 'warn'); return; }
    $(this).prop('disabled', true).text('Submitting...');
    $.post(SOMO.ajaxUrl, {
      action: 'somo_submit_proposal',
      nonce:  SOMO.nonce,
      title, description: desc,
    }, function(res) {
      if (res.success) {
        showToast('✅ Proposal submitted!', 'success');
        setTimeout(() => location.reload(), 1000);
      } else {
        showToast('Error: ' + res.data, 'error');
        $('#somoSubmitProposal').prop('disabled', false).text('Submit Proposal');
      }
    });
  });

  $(document).on('click', '.somo-vote-btn', function() {
    const $btn       = $(this);
    const proposalId = $btn.data('proposal');
    const vote       = $btn.data('vote');
    $btn.siblings().addBack().prop('disabled', true);
    $.post(SOMO.ajaxUrl, {
      action: 'somo_cast_vote',
      nonce:  SOMO.nonce,
      proposal_id: proposalId,
      vote,
    }, function(res) {
      if (res.success) {
        showToast('🗳️ Vote cast!', 'success');
        setTimeout(() => location.reload(), 800);
      } else {
        showToast('Error: ' + res.data, 'error');
        $btn.siblings().addBack().prop('disabled', false);
      }
    });
  });

  /* ────────────────────────────────────────
     UTILITIES
  ──────────────────────────────────────── */
  function shortAddr(addr) {
    return addr ? addr.substring(0,6) + '...' + addr.slice(-4) : '';
  }

  function showToast(msg, type='info') {
    const colors = { success:'#166534', error:'#991b1b', warn:'#854d0e', info:'#1e40af' };
    const $t = $('<div class="somo-toast">').text(msg).css('background', colors[type]||colors.info);
    $('body').append($t);
    setTimeout(() => $t.addClass('somo-toast-show'), 50);
    setTimeout(() => { $t.removeClass('somo-toast-show'); setTimeout(()=>$t.remove(),300); }, 3000);
  }

  function showMsg(selector, msg, type) {
    const $el = $(selector);
    $el.removeClass('somo-msg-success somo-msg-error').addClass('somo-msg-' + type).html(msg).slideDown();
  }

  function showModal(title, body, btnText, btnHref) {
    const $m = $(`
      <div class="somo-modal-overlay">
        <div class="somo-modal">
          <h2>${title}</h2>
          <div class="somo-modal-body">${body}</div>
          <a href="${btnHref}" class="somo-btn somo-btn-primary">${btnText}</a>
          <button class="somo-modal-close">✕</button>
        </div>
      </div>
    `);
    $('body').append($m);
    $m.find('.somo-modal-close').on('click', () => $m.remove());
  }

  /* ────────────────────────────────────────
     BIND EVENTS
  ──────────────────────────────────────── */
  $(document).ready(function() {
    $(document).on('click', '#somoConnectWallet', connectWallet);
    $(document).on('click', '#somoDisconnectWallet', disconnectWallet);
    $(document).on('click', '#somoCompleteLesson', function() { completeLesson($(this)); });

    // MetaMask account change
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accs) => {
        if (accs.length === 0) disconnectWallet();
        else { currentAccount = accs[0]; }
      });
    }
  });

})(jQuery);
