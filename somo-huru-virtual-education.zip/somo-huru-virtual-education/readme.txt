=== Somo Huru Virtual Education System ===
Contributors: somohuru
Tags: education, kenya, cbe, kcse, elearning, ai tutor, accessibility
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 8.0
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered Virtual Learning Platform for Kenyan CBE and KCSE learners (PP1–Form 4).

== Description ==

Somo Huru Virtual Education System is a production-grade WordPress plugin that transforms any WordPress site into a full-featured virtual learning platform for Kenyan learners from PP1 to Form 4.

**IMPORTANT LEGAL NOTICE**
This plugin does NOT store, display, or reproduce any official KICD (Kenya Institute of Curriculum Development) curriculum documents. Teachers upload ONLY their own interpreted schemes of work, lesson notes, lesson plans, assessments, and other original materials. All uploaded content must comply with Kenyan copyright law.

= Features =

**Learning Content Types**
* Schemes of Work
* Lesson Plans
* Lesson Notes
* Assessments
* Revision Questions
* Printable Worksheets
* Teacher Resources
* Learner Resources
* Vocational Content

**Taxonomies**
* Grade (PP1, PP2, Grade 1–9, Form 1–4)
* Subject
* Strand & Sub-Strand
* Term (1–3)
* Week (1–14)
* Curriculum Level

**AI Tutor (RAG-based)**
* Searches teacher-uploaded lesson notes first (local RAG)
* Falls back to OpenAI API only if no local match found
* Responds in simplified, learner-friendly English
* Supports weak learners with encouraging tone

**Accessibility**
* Text-to-speech read-aloud
* Adjustable font size (3 levels)
* High contrast mode
* Dyslexia-friendly font (OpenDyslexic)
* Preferences saved in localStorage

**SEO**
* schema.org Course JSON-LD on every resource
* Auto-generated meta title & description
* SEO-friendly URLs: /grade-4/english/writing/term-1/week-3/
* OpenGraph & Twitter Card tags

**Security**
* Three roles: Admin, Somo Huru Teacher, Somo Huru Student
* Custom capability-based access control
* Nonce verification on all AJAX requests
* File type & size validation on uploads

= Shortcodes =

[shve_ai_tutor grade="grade-4" subject="english"]
[shve_ask_teacher]
[shve_resources grade="grade-4" subject="english" term="term-1"]
[shve_download_button post_id="123"]
[shve_read_aloud target=".entry-content"]

== Installation ==

1. Upload the `somo-huru-virtual-education` folder to `/wp-content/plugins/`
2. Activate the plugin through the Plugins menu
3. Go to **Somo Huru → Settings** and enter your OpenAI API key
4. Go to **Somo Huru → Upload Resource** to start adding content
5. Add the [shve_ai_tutor] shortcode to any page

**Roles**
After activation, assign the `Somo Huru Teacher` role to teachers and `Somo Huru Student` role to learners.

**Font**
To enable the dyslexia-friendly font, download OpenDyslexic-Regular.otf and place it at:
`/wp-content/plugins/somo-huru-virtual-education/assets/fonts/OpenDyslexic-Regular.otf`
Download from: https://opendyslexic.org/

== Frequently Asked Questions ==

= Does this plugin store KICD curriculum documents? =
No. This plugin is designed to store ONLY teacher-created materials. It is the responsibility of each teacher to ensure their uploads are original work and do not reproduce official KICD documents.

= Can students access resources without logging in? =
Published resources are publicly viewable. File downloads require a student account.

= How does the AI Tutor work? =
It first searches the lesson notes teachers have uploaded on your site. If it finds relevant content, it uses OpenAI to formulate an answer based on that content only. If no local notes match, it can optionally fall back to a general OpenAI response. This is the RAG (Retrieval-Augmented Generation) pattern.

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release of Somo Huru Virtual Education System.
