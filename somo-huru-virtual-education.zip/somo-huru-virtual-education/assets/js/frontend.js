/* Somo Huru – Frontend JS */
(function ($) {
  'use strict';

  $(function () {

    // ---- Mobile nav toggle for accessibility toolbar ----
    // Handled by accessibility.js

    // ---- Lazy load enhancement ----
    if ('IntersectionObserver' in window) {
      var imgObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var img = entry.target;
            if (img.dataset.src) {
              img.src = img.dataset.src;
              img.removeAttribute('data-src');
            }
            imgObserver.unobserve(img);
          }
        });
      });
      document.querySelectorAll('img[data-src]').forEach(function (img) {
        imgObserver.observe(img);
      });
    }

    // ---- Animate cards on scroll ----
    if ('IntersectionObserver' in window) {
      var cardObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.style.opacity   = '1';
            entry.target.style.transform = 'translateY(0)';
            cardObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.1 });

      document.querySelectorAll('.shve-card').forEach(function (card, i) {
        card.style.opacity    = '0';
        card.style.transform  = 'translateY(20px)';
        card.style.transition = 'opacity .35s ease ' + (i * 0.06) + 's, transform .35s ease ' + (i * 0.06) + 's';
        cardObserver.observe(card);
      });
    }

    // ---- Smooth anchor links ----
    $('a[href^="#"]').on('click', function (e) {
      var target = $($(this).attr('href'));
      if (target.length) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: target.offset().top - 80 }, 400);
        target.focus();
      }
    });

  });

}(jQuery));
