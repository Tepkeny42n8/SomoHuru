/* Somo Huru – AI Tutor Frontend JS */
(function ($) {
  'use strict';

  var SHVE_AI = {

    init: function () {
      this.$tutor  = $('#shve-ai-tutor');
      if (!this.$tutor.length) return;

      this.$form    = $('#shve-ai-form');
      this.$input   = $('#shve-ai-question');
      this.$log     = $('#shve-ai-chat-log');
      this.$submit  = $('#shve-ai-submit');
      this.$clear   = $('#shve-ai-clear');
      this.grade    = this.$tutor.data('grade')   || '';
      this.subject  = this.$tutor.data('subject') || '';
      this.busy     = false;

      this.$form.on('submit', this.handleSubmit.bind(this));
      this.$clear.on('click', this.clearChat.bind(this));

      // Ask-a-teacher
      this.initAskTeacher();
    },

    handleSubmit: function (e) {
      e.preventDefault();
      if (this.busy) return;
      var question = $.trim(this.$input.val());
      if (!question) { this.$input.focus(); return; }

      this.addBubble(question, 'user');
      this.$input.val('');
      this.setLoading(true);
      this.addThinkingBubble();

      $.ajax({
        url: shve_ajax.ajax_url,
        type: 'POST',
        data: {
          action:   'shve_ai_question',
          nonce:    shve_ajax.nonce,
          question: question,
          grade:    this.grade,
          subject:  this.subject,
        },
        success: function (res) {
          this.removeThinkingBubble();
          this.setLoading(false);
          if (res.success) {
            this.addBubble(this.formatAnswer(res.data.answer), 'assistant');
          } else {
            this.addBubble(res.data.message || shve_ajax.strings.error, 'assistant error');
          }
        }.bind(this),
        error: function () {
          this.removeThinkingBubble();
          this.setLoading(false);
          this.addBubble(shve_ajax.strings.error, 'assistant error');
        }.bind(this),
      });
    },

    addBubble: function (html, type) {
      var $bubble = $('<div class="shve-ai-bubble shve-ai-bubble--' + type + '"></div>').html(html);
      this.$log.append($bubble);
      this.scrollToBottom();
    },

    addThinkingBubble: function () {
      this.$thinking = $('<div class="shve-ai-bubble shve-ai-bubble--assistant shve-ai-bubble--thinking" id="shve-ai-thinking"><span class="shve-dots"><span>.</span><span>.</span><span>.</span></span> ' + shve_ajax.strings.thinking + '</div>');
      this.$log.append(this.$thinking);
      this.scrollToBottom();
    },

    removeThinkingBubble: function () {
      if (this.$thinking) { this.$thinking.remove(); this.$thinking = null; }
    },

    scrollToBottom: function () {
      this.$log.scrollTop(this.$log[0].scrollHeight);
    },

    setLoading: function (loading) {
      this.busy = loading;
      this.$submit.find('.shve-ai-submit__text').toggle(!loading);
      this.$submit.find('.shve-ai-submit__loading').prop('hidden', !loading);
      this.$submit.prop('disabled', loading);
      this.$input.prop('disabled', loading);
    },

    formatAnswer: function (text) {
      // Convert newlines to <br>, wrap numbered lists
      return text
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>')
        .replace(/^/, '<p>').replace(/$/, '</p>');
    },

    clearChat: function () {
      this.$log.children().not(':first').remove();
      this.$input.val('').focus();
    },

    initAskTeacher: function () {
      var $form = $('#shve-ask-teacher-form');
      if (!$form.length) return;
      var $response = $('#shve-ask-teacher-response');

      $form.on('submit', function (e) {
        e.preventDefault();
        var question = $.trim($form.find('[name="question"]').val());
        var post_id  = $form.find('[name="post_id"]').val();
        if (!question) return;

        var $btn = $form.find('[type="submit"]');
        $btn.text('Sending…').prop('disabled', true);

        $.ajax({
          url: shve_ajax.ajax_url,
          type: 'POST',
          data: {
            action:   'shve_ask_teacher',
            nonce:    shve_ajax.nonce,
            post_id:  post_id,
            question: question,
          },
          success: function (res) {
            $btn.text('Send Question to Teacher').prop('disabled', false);
            $response.removeAttr('hidden').removeClass('shve-notice--error');
            if (res.success) {
              $response.addClass('shve-notice shve-notice--success').text(res.data.message);
              $form.find('[name="question"]').val('');
            } else {
              $response.addClass('shve-notice shve-notice--error').text(res.data.message);
            }
          },
          error: function () {
            $btn.text('Send Question to Teacher').prop('disabled', false);
            $response.removeAttr('hidden').addClass('shve-notice shve-notice--error').text(shve_ajax.strings.error);
          },
        });
      });
    },
  };

  $(function () { SHVE_AI.init(); });

}(jQuery));
