/* Somo Huru – Accessibility JS */
(function () {
  'use strict';

  var PREFS_KEY = 'shve_a11y_prefs';
  var fontSizes  = ['', 'shve-font-lg', 'shve-font-xl', 'shve-font-xxl'];
  var prefs      = loadPrefs();

  /* ---- Helpers ---- */
  function loadPrefs() {
    try {
      return JSON.parse(localStorage.getItem(PREFS_KEY)) || {};
    } catch (e) { return {}; }
  }
  function savePrefs() {
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch(e){}
  }
  function applyPrefs() {
    var body = document.body;
    // Font size
    fontSizes.forEach(function (cls) { if (cls) body.classList.remove(cls); });
    if (prefs.fontSize && fontSizes[prefs.fontSize]) {
      body.classList.add(fontSizes[prefs.fontSize]);
    }
    // High contrast
    body.classList.toggle('shve-high-contrast', !!prefs.highContrast);
    // Dyslexia font
    body.classList.toggle('shve-dyslexia-font', !!prefs.dyslexiaFont);
  }

  /* ---- Toolbar init ---- */
  document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.getElementById('shve-a11y-toggle');
    var panel  = document.getElementById('shve-a11y-panel');
    if (!toggle || !panel) return;

    // Apply saved prefs
    applyPrefs();
    updateToggleBtns();

    toggle.addEventListener('click', function () {
      var open = panel.hasAttribute('hidden');
      if (open) { panel.removeAttribute('hidden'); toggle.setAttribute('aria-expanded', 'true'); }
      else       { panel.setAttribute('hidden', ''); toggle.setAttribute('aria-expanded', 'false'); }
    });

    // Close on outside click
    document.addEventListener('click', function (e) {
      if (!toggle.contains(e.target) && !panel.contains(e.target)) {
        panel.setAttribute('hidden', '');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });

    // Action buttons
    panel.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-action]');
      if (!btn) return;
      var action = btn.dataset.action;

      switch (action) {
        case 'font-increase':
          prefs.fontSize = Math.min((prefs.fontSize || 0) + 1, fontSizes.length - 1);
          break;
        case 'font-decrease':
          prefs.fontSize = Math.max((prefs.fontSize || 0) - 1, 0);
          break;
        case 'font-reset':
          prefs.fontSize = 0;
          break;
        case 'high-contrast':
          prefs.highContrast = !prefs.highContrast;
          break;
        case 'dyslexia-font':
          prefs.dyslexiaFont = !prefs.dyslexiaFont;
          break;
      }

      savePrefs();
      applyPrefs();
      updateToggleBtns();
    });

    /* ---- Text-to-Speech ---- */
    var playBtn  = document.getElementById('shve-tts-play');
    var pauseBtn = document.getElementById('shve-tts-pause');
    var stopBtn  = document.getElementById('shve-tts-stop');
    var utterance = null;

    if (playBtn && 'speechSynthesis' in window) {
      playBtn.addEventListener('click', function () {
        var target  = document.querySelector('.entry-content, .shve-ai-tutor__chat, main');
        var text    = target ? target.innerText : document.body.innerText;
        if (!text) return;

        window.speechSynthesis.cancel();
        utterance = new SpeechSynthesisUtterance(text);
        utterance.lang  = 'en-KE';
        utterance.rate  = 0.9;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
      });

      if (pauseBtn) {
        pauseBtn.addEventListener('click', function () {
          if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
            window.speechSynthesis.pause();
          } else if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
          }
        });
      }

      if (stopBtn) {
        stopBtn.addEventListener('click', function () { window.speechSynthesis.cancel(); });
      }
    } else if (playBtn) {
      playBtn.disabled  = true;
      playBtn.title     = 'Text-to-speech not supported in this browser.';
      if (pauseBtn) pauseBtn.disabled = true;
      if (stopBtn)  stopBtn.disabled  = true;
    }

    /* ---- Standalone read-aloud buttons ---- */
    document.querySelectorAll('.shve-btn--read-aloud').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var selector = btn.dataset.target || '.entry-content';
        var target   = document.querySelector(selector);
        var text     = target ? target.innerText : '';
        if (!text || !('speechSynthesis' in window)) return;
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(text);
        u.lang = 'en-KE'; u.rate = 0.9;
        window.speechSynthesis.speak(u);
      });
    });
  });

  function updateToggleBtns() {
    var panel = document.getElementById('shve-a11y-panel');
    if (!panel) return;
    var hcBtn = panel.querySelector('[data-action="high-contrast"]');
    var dyBtn = panel.querySelector('[data-action="dyslexia-font"]');
    if (hcBtn) hcBtn.setAttribute('aria-pressed', prefs.highContrast ? 'true' : 'false');
    if (dyBtn) dyBtn.setAttribute('aria-pressed', prefs.dyslexiaFont ? 'true' : 'false');
  }

}());
