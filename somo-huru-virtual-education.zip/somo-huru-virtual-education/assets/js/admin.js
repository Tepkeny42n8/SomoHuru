/* Somo Huru – Admin JS */
(function ($) {
  'use strict';
  $(function () {

    // Confirm file removal
    $('input[name="shve_remove_file"]').on('change', function () {
      if (this.checked && !window.confirm('Are you sure you want to remove the attached file?')) {
        this.checked = false;
      }
    });

    // Character counters for SEO fields
    function addCounter($field, max) {
      var $counter = $('<span class="shve-char-counter"></span>');
      $field.after($counter);
      function update() {
        var len = $field.val().length;
        $counter.text(len + ' / ' + max + ' characters');
        $counter.css('color', len > max ? '#dc2626' : '#64748b');
      }
      $field.on('input', update);
      update();
    }

    if ($('#shve_meta_title').length) addCounter($('#shve_meta_title'), 60);
    if ($('#shve_meta_desc').length)  addCounter($('#shve_meta_desc'),  160);

    // Show/hide OpenAI key
    $('input[name="shve_openai_api_key"]').each(function () {
      var $input  = $(this);
      var $toggle = $('<button type="button" class="button" style="margin-left:8px;">Show</button>');
      $input.after($toggle);
      $toggle.on('click', function () {
        var type = $input.attr('type') === 'password' ? 'text' : 'password';
        $input.attr('type', type);
        $toggle.text(type === 'password' ? 'Show' : 'Hide');
      });
    });

  });
}(jQuery));
