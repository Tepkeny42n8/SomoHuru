<?php
/**
 * Plugin Name: Somo Huru Virtual Education System
 * Plugin URI:  https://somohuru.com
 * Description: AI-powered Virtual Learning Platform for Kenyan CBE and KCSE learners (PP1–Form 4). Teachers upload their own interpreted learning materials. No KICD curriculum documents are stored or reproduced.
 * Version:     1.0.0
 * Author:      Somo Huru Team
 * Author URI:  https://somohuru.com
 * License:     GPL-2.0+
 * Text Domain: somo-huru
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

// Constants
define( 'SHVE_VERSION',     '1.0.0' );
define( 'SHVE_PLUGIN_FILE', __FILE__ );
define( 'SHVE_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SHVE_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'SHVE_PLUGIN_SLUG', 'somo-huru' );

// Autoload includes
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-post-types.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-taxonomies.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-roles.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-upload-handler.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-shortcodes.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-ajax.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-admin.php';
require_once SHVE_PLUGIN_DIR . 'includes/class-shve-rewrite.php';
require_once SHVE_PLUGIN_DIR . 'modules/ai/class-shve-ai-tutor.php';
require_once SHVE_PLUGIN_DIR . 'modules/seo/class-shve-seo.php';
require_once SHVE_PLUGIN_DIR . 'modules/accessibility/class-shve-accessibility.php';

/**
 * Main plugin class.
 */
final class Somo_Huru_VE {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );
        add_action( 'init',           [ $this, 'init' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'somo-huru', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    public function init() {
        SHVE_Post_Types::instance()->register();
        SHVE_Taxonomies::instance()->register();
        SHVE_Roles::instance()->register();
        SHVE_Shortcodes::instance()->register();
        SHVE_Ajax::instance()->register();
        SHVE_Admin::instance()->init();
        SHVE_Rewrite::instance()->init();
        SHVE_SEO::instance()->init();
        SHVE_Accessibility::instance()->init();
    }

    public function enqueue_frontend() {
        wp_enqueue_style( 'shve-main', SHVE_PLUGIN_URL . 'assets/css/frontend.css', [], SHVE_VERSION );
        wp_enqueue_style( 'shve-accessibility', SHVE_PLUGIN_URL . 'assets/css/accessibility.css', [], SHVE_VERSION );
        wp_enqueue_script( 'shve-main', SHVE_PLUGIN_URL . 'assets/js/frontend.js', [ 'jquery' ], SHVE_VERSION, true );
        wp_enqueue_script( 'shve-accessibility', SHVE_PLUGIN_URL . 'assets/js/accessibility.js', [ 'jquery' ], SHVE_VERSION, true );
        wp_enqueue_script( 'shve-ai-tutor', SHVE_PLUGIN_URL . 'assets/js/ai-tutor.js', [ 'jquery' ], SHVE_VERSION, true );
        wp_localize_script( 'shve-main', 'shve_ajax', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'shve_nonce' ),
            'strings'  => [
                'ask_placeholder' => __( 'Ask your question here…', 'somo-huru' ),
                'thinking'        => __( 'Thinking…', 'somo-huru' ),
                'error'           => __( 'Sorry, something went wrong. Try again.', 'somo-huru' ),
            ],
        ] );
    }

    public function enqueue_admin() {
        $screen = get_current_screen();
        if ( ! $screen ) return;
        wp_enqueue_style( 'shve-admin', SHVE_PLUGIN_URL . 'assets/css/admin.css', [], SHVE_VERSION );
        wp_enqueue_script( 'shve-admin', SHVE_PLUGIN_URL . 'assets/js/admin.js', [ 'jquery', 'wp-util' ], SHVE_VERSION, true );
        wp_localize_script( 'shve-admin', 'shve_admin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'shve_admin_nonce' ),
        ] );
    }
}

// Activation / Deactivation hooks
register_activation_hook( __FILE__, function () {
    SHVE_Post_Types::instance()->register();
    SHVE_Taxonomies::instance()->register();
    SHVE_Roles::instance()->register();
    SHVE_Rewrite::instance()->init();
    flush_rewrite_rules();
    SHVE_Roles::instance()->add_roles();
} );

register_deactivation_hook( __FILE__, function () {
    flush_rewrite_rules();
} );

// Boot
Somo_Huru_VE::instance();
