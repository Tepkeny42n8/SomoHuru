<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Accessibility {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function init() {
        add_action( 'wp_footer', [ $this, 'render_accessibility_toolbar' ] );
        add_action( 'wp_head',   [ $this, 'output_user_prefs_css' ] );
    }

    public function render_accessibility_toolbar() {
        if ( ! is_singular() && ! is_archive() ) return;
        ?>
        <div id="shve-a11y-toolbar" class="shve-a11y-toolbar" role="region" aria-label="<?php esc_attr_e( 'Accessibility Options', 'somo-huru' ); ?>">
            <button id="shve-a11y-toggle" aria-expanded="false" aria-controls="shve-a11y-panel" class="shve-a11y-toggle-btn" title="<?php esc_attr_e( 'Accessibility', 'somo-huru' ); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
                <span class="screen-reader-text"><?php esc_html_e( 'Accessibility Options', 'somo-huru' ); ?></span>
            </button>
            <div id="shve-a11y-panel" class="shve-a11y-panel" hidden>
                <h2 class="shve-a11y-heading"><?php esc_html_e( 'Reading Options', 'somo-huru' ); ?></h2>

                <!-- Text size -->
                <div class="shve-a11y-group">
                    <span><?php esc_html_e( 'Text Size', 'somo-huru' ); ?></span>
                    <div class="shve-a11y-controls">
                        <button class="shve-btn-a11y" data-action="font-decrease" aria-label="<?php esc_attr_e( 'Decrease font size', 'somo-huru' ); ?>">A−</button>
                        <button class="shve-btn-a11y" data-action="font-reset"    aria-label="<?php esc_attr_e( 'Reset font size', 'somo-huru' ); ?>">A</button>
                        <button class="shve-btn-a11y" data-action="font-increase" aria-label="<?php esc_attr_e( 'Increase font size', 'somo-huru' ); ?>">A+</button>
                    </div>
                </div>

                <!-- High contrast -->
                <div class="shve-a11y-group">
                    <span><?php esc_html_e( 'High Contrast', 'somo-huru' ); ?></span>
                    <button class="shve-btn-a11y shve-toggle-btn" data-action="high-contrast" aria-pressed="false">
                        <?php esc_html_e( 'On / Off', 'somo-huru' ); ?>
                    </button>
                </div>

                <!-- Dyslexia font -->
                <div class="shve-a11y-group">
                    <span><?php esc_html_e( 'Dyslexia-Friendly Font', 'somo-huru' ); ?></span>
                    <button class="shve-btn-a11y shve-toggle-btn" data-action="dyslexia-font" aria-pressed="false">
                        <?php esc_html_e( 'On / Off', 'somo-huru' ); ?>
                    </button>
                </div>

                <!-- Read aloud -->
                <div class="shve-a11y-group">
                    <span><?php esc_html_e( 'Read Page Aloud', 'somo-huru' ); ?></span>
                    <div class="shve-a11y-controls">
                        <button class="shve-btn-a11y" id="shve-tts-play"  aria-label="<?php esc_attr_e( 'Play', 'somo-huru' ); ?>">▶ <?php esc_html_e( 'Play', 'somo-huru' ); ?></button>
                        <button class="shve-btn-a11y" id="shve-tts-pause" aria-label="<?php esc_attr_e( 'Pause', 'somo-huru' ); ?>">⏸ <?php esc_html_e( 'Pause', 'somo-huru' ); ?></button>
                        <button class="shve-btn-a11y" id="shve-tts-stop"  aria-label="<?php esc_attr_e( 'Stop', 'somo-huru' ); ?>">■ <?php esc_html_e( 'Stop', 'somo-huru' ); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function output_user_prefs_css() {
        // The JS reads from localStorage and applies a class to <body>;
        // We preload OpenDyslexic font here.
        echo '<style>
@font-face {
    font-family: "OpenDyslexic";
    src: url("' . esc_url( SHVE_PLUGIN_URL . 'assets/fonts/OpenDyslexic-Regular.otf' ) . '") format("opentype");
    font-display: swap;
}
body.shve-dyslexia-font,
body.shve-dyslexia-font * {
    font-family: "OpenDyslexic", sans-serif !important;
    letter-spacing: 0.05em;
    line-height: 1.8;
}
body.shve-high-contrast {
    background: #000 !important;
    color: #ffff00 !important;
}
body.shve-high-contrast a { color: #00ffff !important; }
body.shve-high-contrast .shve-card,
body.shve-high-contrast .shve-ai-bubble--assistant {
    background: #1a1a00 !important;
    border-color: #ffff00 !important;
}
</style>' . "\n";
    }
}
