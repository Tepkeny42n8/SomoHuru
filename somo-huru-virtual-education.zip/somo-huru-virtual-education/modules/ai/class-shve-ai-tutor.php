<?php
defined( 'ABSPATH' ) || exit;

/**
 * AI Tutor Module – RAG (Retrieval Augmented Generation)
 *
 * Flow:
 * 1. Search teacher-uploaded lesson notes / schemes for relevant content (local RAG).
 * 2. If sufficient context found → build a prompt and call OpenAI with local context.
 * 3. If no local context found and fallback is enabled → call OpenAI with general instruction.
 * 4. Always respond in simplified learner-friendly English suitable for the stated grade.
 */
class SHVE_AI_Tutor {

    private static $instance = null;
    private $api_key;
    private $model;
    private $ai_fallback;
    private $rag_post_count;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->api_key       = get_option( 'shve_openai_api_key', '' );
        $this->model         = get_option( 'shve_openai_model', 'gpt-4o-mini' );
        $this->ai_fallback   = (bool) get_option( 'shve_ai_fallback', 1 );
        $this->rag_post_count = (int) get_option( 'shve_rag_context_posts', 5 );
    }

    /**
     * Main entry point: answer a student question.
     *
     * @param string $question
     * @param string $grade   Slug of grade (e.g. "grade-4")
     * @param string $subject Slug of subject (e.g. "english")
     * @return string|WP_Error
     */
    public function answer( $question, $grade = '', $subject = '' ) {
        // 1. Local RAG search
        $context = $this->retrieve_local_context( $question, $grade, $subject );

        // 2. Build prompt
        $grade_label   = $this->slug_to_label( $grade );
        $subject_label = $this->slug_to_label( $subject );

        if ( ! empty( $context ) ) {
            $system = $this->system_prompt( $grade_label, $subject_label, true );
            $prompt = "Use ONLY the following learning material to answer the student's question. If the answer is not in the material, say so kindly.\n\n--- LEARNING MATERIAL ---\n{$context}\n--- END ---\n\nStudent question: {$question}";
        } elseif ( $this->ai_fallback && ! empty( $this->api_key ) ) {
            $system = $this->system_prompt( $grade_label, $subject_label, false );
            $prompt = $question;
        } else {
            return __( 'I could not find an answer in our learning materials. Please ask your teacher directly.', 'somo-huru' );
        }

        return $this->call_openai( $system, $prompt );
    }

    /**
     * Retrieve relevant content from teacher-uploaded posts using keyword matching.
     */
    private function retrieve_local_context( $question, $grade, $subject ) {
        // Build keyword list from the question
        $keywords = $this->extract_keywords( $question );

        $tax_query = [ 'relation' => 'AND' ];
        if ( $grade ) {
            $tax_query[] = [ 'taxonomy' => 'shve_grade', 'field' => 'slug', 'terms' => $grade ];
        }
        if ( $subject ) {
            $tax_query[] = [ 'taxonomy' => 'shve_subject', 'field' => 'slug', 'terms' => $subject ];
        }

        $args = [
            'post_type'      => [ 'shve_lesson_note', 'shve_lesson_plan', 'shve_scheme', 'shve_revision', 'shve_assessment' ],
            'post_status'    => 'publish',
            'posts_per_page' => $this->rag_post_count,
            's'              => implode( ' ', $keywords ),
        ];

        if ( count( $tax_query ) > 1 ) {
            $args['tax_query'] = $tax_query;
        }

        $query = new WP_Query( $args );
        $chunks = [];

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $post_id = get_the_ID();

                // Prefer the dedicated AI index field; fall back to post content
                $ai_index = get_post_meta( $post_id, '_shve_ai_index', true );
                $content  = ! empty( $ai_index ) ? $ai_index : wp_strip_all_tags( get_the_content() );

                // Score by keyword hits
                $score = 0;
                $lower = strtolower( $content );
                foreach ( $keywords as $kw ) {
                    $score += substr_count( $lower, strtolower( $kw ) );
                }

                if ( $score > 0 ) {
                    $chunks[] = [
                        'score'   => $score,
                        'title'   => get_the_title(),
                        'content' => $this->truncate_chunk( $content, 600 ),
                    ];
                }
            }
            wp_reset_postdata();
        }

        if ( empty( $chunks ) ) return '';

        // Sort by relevance score
        usort( $chunks, fn( $a, $b ) => $b['score'] - $a['score'] );

        $context_parts = [];
        foreach ( array_slice( $chunks, 0, 3 ) as $chunk ) {
            $context_parts[] = "[{$chunk['title']}]\n{$chunk['content']}";
        }

        return implode( "\n\n", $context_parts );
    }

    private function extract_keywords( $text ) {
        $text      = strtolower( $text );
        $stop_words = [ 'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'shall', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into', 'that', 'this', 'it', 'its', 'what', 'how', 'why', 'when', 'where', 'who', 'which', 'about', 'my', 'me', 'i' ];
        preg_match_all( '/\b[a-z]{3,}\b/', $text, $matches );
        $words = array_diff( $matches[0], $stop_words );
        $words = array_unique( $words );
        return array_values( $words );
    }

    private function truncate_chunk( $text, $max_chars ) {
        $text = wp_strip_all_tags( $text );
        if ( strlen( $text ) <= $max_chars ) return $text;
        return substr( $text, 0, $max_chars ) . '…';
    }

    private function slug_to_label( $slug ) {
        return ucwords( str_replace( '-', ' ', $slug ) );
    }

    private function system_prompt( $grade, $subject, $has_context ) {
        $context_note = $has_context
            ? 'You will be given teacher-uploaded learning material. Use ONLY that material to answer.'
            : 'No specific lesson material was found. Give a helpful, general explanation.';

        return "You are Somo Huru AI Tutor, a friendly and encouraging learning assistant for Kenyan learners.
- The student is in {$grade}" . ( $subject ? ", studying {$subject}" : '' ) . ".
- {$context_note}
- Use simple, clear English suitable for their grade level.
- Break explanations into short, numbered steps where possible.
- If the student seems to be struggling, offer extra encouragement.
- Never reproduce official KICD curriculum documents word-for-word.
- If you don't know the answer, say: 'Great question! Your teacher can explain this better. Write it in your notebook and ask them.'
- Keep responses concise (under 250 words).";
    }

    private function call_openai( $system, $user_message ) {
        if ( empty( $this->api_key ) ) {
            return new WP_Error( 'no_api_key', __( 'AI Tutor is not configured. Please contact your school administrator.', 'somo-huru' ) );
        }

        $body = wp_json_encode( [
            'model'       => $this->model,
            'messages'    => [
                [ 'role' => 'system', 'content' => $system ],
                [ 'role' => 'user',   'content' => $user_message ],
            ],
            'max_tokens'  => 500,
            'temperature' => 0.4,
        ] );

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'timeout'     => 30,
            'headers'     => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'        => $body,
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            $error_msg = $data['error']['message'] ?? 'Unknown error from AI service.';
            return new WP_Error( 'openai_error', esc_html( $error_msg ) );
        }

        return trim( $data['choices'][0]['message']['content'] ?? '' );
    }

    /**
     * Cache wrapper for repeated identical questions.
     */
    public function answer_cached( $question, $grade = '', $subject = '' ) {
        $cache_key = 'shve_ai_' . md5( $question . $grade . $subject );
        $cached    = get_transient( $cache_key );
        if ( $cached !== false ) return $cached;

        $answer = $this->answer( $question, $grade, $subject );
        if ( ! is_wp_error( $answer ) ) {
            set_transient( $cache_key, $answer, HOUR_IN_SECONDS );
        }
        return $answer;
    }
}
