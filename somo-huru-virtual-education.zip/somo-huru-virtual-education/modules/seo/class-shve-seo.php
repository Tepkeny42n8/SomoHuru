<?php
defined( 'ABSPATH' ) || exit;

class SHVE_SEO {

    private static $instance = null;
    private $shve_post_types = [
        'shve_scheme', 'shve_lesson_plan', 'shve_lesson_note',
        'shve_assessment', 'shve_revision', 'shve_worksheet',
        'shve_teacher_res', 'shve_learner_res', 'shve_vocational',
    ];

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function init() {
        add_action( 'wp_head',                   [ $this, 'output_meta_and_schema' ], 1 );
        add_action( 'save_post',                 [ $this, 'auto_generate_seo_meta' ], 20 );
        add_filter( 'document_title_parts',      [ $this, 'filter_title' ] );
    }

    public function output_meta_and_schema() {
        if ( ! is_singular( $this->shve_post_types ) ) return;

        global $post;
        $this->output_meta_tags( $post );
        $this->output_schema( $post );
    }

    private function output_meta_tags( $post ) {
        $meta_title = get_post_meta( $post->ID, '_shve_meta_title', true );
        $meta_desc  = get_post_meta( $post->ID, '_shve_meta_desc', true );

        if ( empty( $meta_title ) ) $meta_title = $this->auto_title( $post );
        if ( empty( $meta_desc ) )  $meta_desc  = $this->auto_desc( $post );

        // Canonical
        echo '<link rel="canonical" href="' . esc_url( get_permalink( $post->ID ) ) . '">' . "\n";
        // Meta description
        echo '<meta name="description" content="' . esc_attr( $meta_desc ) . '">' . "\n";
        // OG tags
        echo '<meta property="og:title" content="' . esc_attr( $meta_title ) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr( $meta_desc ) . '">' . "\n";
        echo '<meta property="og:type" content="article">' . "\n";
        echo '<meta property="og:url" content="' . esc_url( get_permalink( $post->ID ) ) . '">' . "\n";
        if ( has_post_thumbnail( $post->ID ) ) {
            echo '<meta property="og:image" content="' . esc_url( get_the_post_thumbnail_url( $post->ID, 'large' ) ) . '">' . "\n";
        }
        // Twitter card
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr( $meta_title ) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr( $meta_desc ) . '">' . "\n";
    }

    private function output_schema( $post ) {
        $grade_terms   = get_the_terms( $post->ID, 'shve_grade' );
        $subject_terms = get_the_terms( $post->ID, 'shve_subject' );
        $strand_terms  = get_the_terms( $post->ID, 'shve_strand' );
        $term_terms    = get_the_terms( $post->ID, 'shve_term' );

        $grade   = ( $grade_terms   && ! is_wp_error( $grade_terms ) )   ? $grade_terms[0]->name   : '';
        $subject = ( $subject_terms && ! is_wp_error( $subject_terms ) ) ? $subject_terms[0]->name : '';
        $strand  = ( $strand_terms  && ! is_wp_error( $strand_terms ) )  ? $strand_terms[0]->name  : '';
        $term    = ( $term_terms    && ! is_wp_error( $term_terms ) )    ? $term_terms[0]->name    : '';

        $duration  = get_post_meta( $post->ID, '_shve_duration', true );
        $outcomes  = get_post_meta( $post->ID, '_shve_outcomes', true );
        $post_type_obj = get_post_type_object( $post->post_type );
        $type_label = $post_type_obj ? $post_type_obj->labels->singular_name : 'Learning Resource';

        $schema = [
            '@context'        => 'https://schema.org',
            '@type'           => 'Course',
            'name'            => get_the_title( $post->ID ),
            'description'     => wp_trim_words( wp_strip_all_tags( $post->post_content ), 40 ),
            'url'             => get_permalink( $post->ID ),
            'provider'        => [
                '@type' => 'Organization',
                'name'  => get_bloginfo( 'name' ),
                'url'   => home_url(),
            ],
            'educationalLevel'    => $grade,
            'about'               => $subject,
            'courseCode'          => $strand,
            'typicalAgeRange'     => $this->grade_to_age( $grade ),
            'inLanguage'          => 'en',
            'datePublished'       => get_the_date( 'Y-m-d', $post->ID ),
            'dateModified'        => get_the_modified_date( 'Y-m-d', $post->ID ),
            'hasCourseInstance'   => [
                '@type'          => 'CourseInstance',
                'courseMode'     => 'online',
                'name'           => $term,
            ],
        ];

        if ( $outcomes ) {
            $schema['coursePrerequisites'] = [];
            $schema['teaches'] = $outcomes;
        }

        if ( $duration ) {
            $schema['timeRequired'] = $duration;
        }

        if ( has_post_thumbnail( $post->ID ) ) {
            $schema['image'] = get_the_post_thumbnail_url( $post->ID, 'large' );
        }

        $attachment_id = get_post_meta( $post->ID, '_shve_file_id', true );
        if ( $attachment_id ) {
            $file_url  = wp_get_attachment_url( $attachment_id );
            $file_mime = get_post_mime_type( $attachment_id );
            $schema['hasPart'] = [
                '@type'       => 'MediaObject',
                'contentUrl'  => $file_url,
                'encodingFormat' => $file_mime,
                'name'        => $type_label . ' – ' . get_the_title( $post->ID ),
            ];
        }

        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }

    public function filter_title( $title ) {
        if ( ! is_singular( $this->shve_post_types ) ) return $title;
        global $post;
        $meta_title = get_post_meta( $post->ID, '_shve_meta_title', true );
        if ( $meta_title ) $title['title'] = $meta_title;
        return $title;
    }

    public function auto_generate_seo_meta( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_type, $this->shve_post_types, true ) ) return;
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;

        $meta_title = get_post_meta( $post_id, '_shve_meta_title', true );
        if ( empty( $meta_title ) ) {
            update_post_meta( $post_id, '_shve_meta_title', $this->auto_title( $post ) );
        }

        $meta_desc = get_post_meta( $post_id, '_shve_meta_desc', true );
        if ( empty( $meta_desc ) ) {
            update_post_meta( $post_id, '_shve_meta_desc', $this->auto_desc( $post ) );
        }
    }

    private function auto_title( $post ) {
        $grade_terms   = get_the_terms( $post->ID, 'shve_grade' );
        $subject_terms = get_the_terms( $post->ID, 'shve_subject' );
        $term_terms    = get_the_terms( $post->ID, 'shve_term' );
        $site          = get_bloginfo( 'name' );

        $parts = [ get_the_title( $post->ID ) ];
        if ( $grade_terms   && ! is_wp_error( $grade_terms ) )   $parts[] = $grade_terms[0]->name;
        if ( $subject_terms && ! is_wp_error( $subject_terms ) ) $parts[] = $subject_terms[0]->name;
        if ( $term_terms    && ! is_wp_error( $term_terms ) )    $parts[] = $term_terms[0]->name;
        $parts[] = $site;

        $title = implode( ' | ', $parts );
        return mb_substr( $title, 0, 60 );
    }

    private function auto_desc( $post ) {
        $grade_terms   = get_the_terms( $post->ID, 'shve_grade' );
        $subject_terms = get_the_terms( $post->ID, 'shve_subject' );
        $strand_terms  = get_the_terms( $post->ID, 'shve_strand' );
        $term_terms    = get_the_terms( $post->ID, 'shve_term' );

        $grade   = ( $grade_terms   && ! is_wp_error( $grade_terms ) )   ? $grade_terms[0]->name   : '';
        $subject = ( $subject_terms && ! is_wp_error( $subject_terms ) ) ? $subject_terms[0]->name : '';
        $strand  = ( $strand_terms  && ! is_wp_error( $strand_terms ) )  ? $strand_terms[0]->name  : '';
        $term    = ( $term_terms    && ! is_wp_error( $term_terms ) )    ? $term_terms[0]->name    : '';

        $post_type_obj = get_post_type_object( $post->post_type );
        $type_label    = $post_type_obj ? $post_type_obj->labels->singular_name : 'Resource';

        $desc = sprintf(
            '%s for %s %s%s%s – Somo Huru Virtual Learning Platform. Aligned to Kenya CBE / KCSE curriculum.',
            $type_label,
            $grade,
            $subject ? ' ' . $subject : '',
            $strand  ? ', ' . $strand  : '',
            $term    ? ', ' . $term    : ''
        );

        $content_snippet = wp_trim_words( wp_strip_all_tags( $post->post_content ), 20 );
        if ( $content_snippet ) {
            $desc .= ' ' . $content_snippet;
        }

        return mb_substr( $desc, 0, 160 );
    }

    private function grade_to_age( $grade ) {
        $map = [
            'PP1' => '4-5', 'PP2' => '5-6',
            'Grade 1' => '6-7', 'Grade 2' => '7-8', 'Grade 3' => '8-9',
            'Grade 4' => '9-10', 'Grade 5' => '10-11', 'Grade 6' => '11-12',
            'Grade 7' => '12-13', 'Grade 8' => '13-14', 'Grade 9' => '14-15',
            'Form 1' => '14-15', 'Form 2' => '15-16', 'Form 3' => '16-17', 'Form 4' => '17-18',
        ];
        return $map[ $grade ] ?? '5-18';
    }
}
