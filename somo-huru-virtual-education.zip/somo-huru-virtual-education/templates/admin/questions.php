<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( 'shve_upload_resources' ) ) {
    wp_die( esc_html__( 'Permission denied.', 'somo-huru' ) );
}

// Handle reply
if ( isset( $_POST['shve_reply_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['shve_reply_nonce'] ) ), 'shve_reply' ) && current_user_can( 'shve_upload_resources' ) ) {
    $comment_id = intval( $_POST['comment_id'] ?? 0 );
    $reply      = sanitize_textarea_field( wp_unslash( $_POST['shve_reply'] ?? '' ) );

    if ( $comment_id && $reply ) {
        $comment = get_comment( $comment_id );
        if ( $comment ) {
            wp_insert_comment( [
                'comment_post_ID'      => $comment->comment_post_ID,
                'comment_author'       => wp_get_current_user()->display_name,
                'comment_author_email' => wp_get_current_user()->user_email,
                'comment_content'      => $reply,
                'comment_type'         => 'shve_answer',
                'comment_parent'       => $comment_id,
                'comment_approved'     => 1,
                'user_id'              => get_current_user_id(),
            ] );
            // Approve original question
            wp_set_comment_status( $comment_id, 'approve' );
            // Notify student
            $student = get_user_by( 'email', $comment->comment_author_email );
            if ( $student ) {
                wp_mail(
                    $student->user_email,
                    __( '[Somo Huru] Your question has been answered!', 'somo-huru' ),
                    sprintf( __( "Your question:\n%s\n\nTeacher's answer:\n%s\n\nView the resource: %s", 'somo-huru' ), $comment->comment_content, $reply, get_permalink( $comment->comment_post_ID ) )
                );
            }
            echo '<div class="notice notice-success"><p>' . esc_html__( 'Reply sent successfully.', 'somo-huru' ) . '</p></div>';
        }
    }
}

$questions = get_comments( [
    'type'    => 'shve_question',
    'status'  => 'all',
    'number'  => 50,
    'orderby' => 'comment_date',
    'order'   => 'DESC',
] );
?>
<div class="wrap shve-admin-wrap">
    <h1><?php esc_html_e( 'Student Questions', 'somo-huru' ); ?></h1>

    <?php if ( empty( $questions ) ) : ?>
        <p><?php esc_html_e( 'No student questions yet.', 'somo-huru' ); ?></p>
    <?php else : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Student', 'somo-huru' ); ?></th>
                    <th><?php esc_html_e( 'Question', 'somo-huru' ); ?></th>
                    <th><?php esc_html_e( 'Resource', 'somo-huru' ); ?></th>
                    <th><?php esc_html_e( 'Date', 'somo-huru' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'somo-huru' ); ?></th>
                    <th><?php esc_html_e( 'Reply', 'somo-huru' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $questions as $q ) :
                    $children = get_comments( [ 'parent' => $q->comment_ID, 'type' => 'shve_answer' ] );
                    $answered = ! empty( $children );
                    ?>
                    <tr class="<?php echo $answered ? 'shve-answered' : 'shve-unanswered'; ?>">
                        <td><?php echo esc_html( $q->comment_author ); ?></td>
                        <td><?php echo esc_html( wp_trim_words( $q->comment_content, 20 ) ); ?></td>
                        <td>
                            <a href="<?php echo esc_url( get_permalink( $q->comment_post_ID ) ); ?>" target="_blank">
                                <?php echo esc_html( get_the_title( $q->comment_post_ID ) ); ?>
                            </a>
                        </td>
                        <td><?php echo esc_html( mysql2date( 'd M Y', $q->comment_date ) ); ?></td>
                        <td>
                            <?php if ( $answered ) : ?>
                                <span class="shve-badge shve-badge--green"><?php esc_html_e( 'Answered', 'somo-huru' ); ?></span>
                                <p style="margin:4px 0 0;font-style:italic;font-size:12px;"><?php echo esc_html( wp_trim_words( $children[0]->comment_content, 10 ) ); ?></p>
                            <?php else : ?>
                                <span class="shve-badge shve-badge--yellow"><?php esc_html_e( 'Pending', 'somo-huru' ); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( ! $answered ) : ?>
                                <form method="post" style="margin:0;">
                                    <?php wp_nonce_field( 'shve_reply', 'shve_reply_nonce' ); ?>
                                    <input type="hidden" name="comment_id" value="<?php echo intval( $q->comment_ID ); ?>">
                                    <p><?php echo esc_html( $q->comment_content ); ?></p>
                                    <textarea name="shve_reply" rows="3" style="width:100%;" placeholder="<?php esc_attr_e( 'Type your reply…', 'somo-huru' ); ?>" required></textarea>
                                    <button type="submit" class="button button-primary"><?php esc_html_e( 'Send Reply', 'somo-huru' ); ?></button>
                                </form>
                            <?php else : ?>
                                —
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
