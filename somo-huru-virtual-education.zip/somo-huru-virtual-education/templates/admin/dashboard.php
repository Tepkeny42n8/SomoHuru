<?php defined( 'ABSPATH' ) || exit; if ( ! current_user_can( 'read' ) ) return; ?>

<div class="wrap shve-admin-wrap">
    <h1><?php esc_html_e( 'Somo Huru Dashboard', 'somo-huru' ); ?></h1>

    <?php
    $post_types = [
        'shve_scheme'      => __( 'Schemes of Work',      'somo-huru' ),
        'shve_lesson_plan' => __( 'Lesson Plans',         'somo-huru' ),
        'shve_lesson_note' => __( 'Lesson Notes',         'somo-huru' ),
        'shve_assessment'  => __( 'Assessments',          'somo-huru' ),
        'shve_revision'    => __( 'Revision Questions',   'somo-huru' ),
        'shve_worksheet'   => __( 'Printable Worksheets', 'somo-huru' ),
        'shve_learner_res' => __( 'Learner Resources',    'somo-huru' ),
        'shve_vocational'  => __( 'Vocational Content',   'somo-huru' ),
    ];
    ?>

    <div class="shve-dashboard-stats">
        <?php foreach ( $post_types as $pt => $label ) :
            $count = wp_count_posts( $pt );
            $total = isset( $count->publish ) ? (int) $count->publish : 0;
            ?>
            <div class="shve-stat-card">
                <span class="shve-stat-card__count"><?php echo esc_html( $total ); ?></span>
                <span class="shve-stat-card__label"><?php echo esc_html( $label ); ?></span>
                <?php if ( current_user_can( 'shve_upload_resources' ) ) : ?>
                    <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . $pt ) ); ?>" class="shve-stat-card__link">
                        + <?php esc_html_e( 'Add New', 'somo-huru' ); ?>
                    </a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="shve-dashboard-grid">
        <div class="shve-dashboard-panel">
            <h2><?php esc_html_e( 'Quick Actions', 'somo-huru' ); ?></h2>
            <ul>
                <?php if ( current_user_can( 'shve_upload_resources' ) ) : ?>
                    <li><a href="<?php echo esc_url( admin_url( 'admin.php?page=shve-upload' ) ); ?>" class="button button-primary"><?php esc_html_e( '+ Upload Resource', 'somo-huru' ); ?></a></li>
                    <li><a href="<?php echo esc_url( admin_url( 'admin.php?page=shve-questions' ) ); ?>" class="button"><?php esc_html_e( 'View Student Questions', 'somo-huru' ); ?></a></li>
                <?php endif; ?>
                <?php if ( current_user_can( 'manage_options' ) ) : ?>
                    <li><a href="<?php echo esc_url( admin_url( 'admin.php?page=shve-settings' ) ); ?>" class="button"><?php esc_html_e( 'Settings', 'somo-huru' ); ?></a></li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="shve-dashboard-panel">
            <h2><?php esc_html_e( 'Recent Resources', 'somo-huru' ); ?></h2>
            <?php
            $recent = new WP_Query( [
                'post_type'      => array_keys( $post_types ),
                'post_status'    => 'publish',
                'posts_per_page' => 8,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ] );
            if ( $recent->have_posts() ) :
            ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Title', 'somo-huru' ); ?></th>
                            <th><?php esc_html_e( 'Type', 'somo-huru' ); ?></th>
                            <th><?php esc_html_e( 'Date', 'somo-huru' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ( $recent->have_posts() ) : $recent->the_post(); ?>
                            <tr>
                                <td><a href="<?php echo esc_url( get_edit_post_link() ); ?>"><?php the_title(); ?></a></td>
                                <td><?php echo esc_html( $post_types[ get_post_type() ] ?? get_post_type() ); ?></td>
                                <td><?php echo esc_html( get_the_date() ); ?></td>
                            </tr>
                        <?php endwhile; wp_reset_postdata(); ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p><?php esc_html_e( 'No resources uploaded yet.', 'somo-huru' ); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="shve-legal-notice notice notice-warning inline">
        <p>
            <strong><?php esc_html_e( 'Legal Notice:', 'somo-huru' ); ?></strong>
            <?php esc_html_e( 'Somo Huru does not store or reproduce official KICD curriculum documents. All materials uploaded here must be teachers\' own interpreted notes and resources. Please ensure compliance with Kenya copyright law.', 'somo-huru' ); ?>
        </p>
    </div>
</div>
