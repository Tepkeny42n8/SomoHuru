<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( 'shve_upload_resources' ) ) {
    wp_die( esc_html__( 'You do not have permission to upload resources.', 'somo-huru' ) );
}
?>
<div class="wrap shve-admin-wrap">
    <h1><?php esc_html_e( 'Upload Learning Resource', 'somo-huru' ); ?></h1>

    <div class="notice notice-info inline">
        <p><?php esc_html_e( 'Upload your own lesson notes, schemes of work, worksheets, or other resources. Do NOT upload official KICD documents.', 'somo-huru' ); ?></p>
    </div>

    <p>
        <?php esc_html_e( 'To upload a resource, please create a new post for the appropriate resource type:', 'somo-huru' ); ?>
    </p>

    <ul class="shve-upload-links">
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_lesson_note' ) ); ?>" class="button button-primary"><?php esc_html_e( 'New Lesson Note', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_lesson_plan' ) ); ?>" class="button"><?php esc_html_e( 'New Lesson Plan', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_scheme' ) ); ?>" class="button"><?php esc_html_e( 'New Scheme of Work', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_assessment' ) ); ?>" class="button"><?php esc_html_e( 'New Assessment', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_revision' ) ); ?>" class="button"><?php esc_html_e( 'New Revision Questions', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_worksheet' ) ); ?>" class="button"><?php esc_html_e( 'New Printable Worksheet', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_learner_res' ) ); ?>" class="button"><?php esc_html_e( 'New Learner Resource', 'somo-huru' ); ?></a></li>
        <li><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=shve_vocational' ) ); ?>" class="button"><?php esc_html_e( 'New Vocational Content', 'somo-huru' ); ?></a></li>
    </ul>

    <h2><?php esc_html_e( 'Resource Checklist', 'somo-huru' ); ?></h2>
    <ul class="shve-checklist">
        <li>✅ <?php esc_html_e( 'Set the correct Grade, Subject, Strand, Term and Week', 'somo-huru' ); ?></li>
        <li>✅ <?php esc_html_e( 'Add a clear title and excerpt (used for SEO)', 'somo-huru' ); ?></li>
        <li>✅ <?php esc_html_e( 'Fill in the "AI Tutor Searchable Content" field with plain-text notes', 'somo-huru' ); ?></li>
        <li>✅ <?php esc_html_e( 'Attach a PDF or Word document in the "Attached File" panel', 'somo-huru' ); ?></li>
        <li>✅ <?php esc_html_e( 'Add a featured image for visual appeal', 'somo-huru' ); ?></li>
        <li>⚠️ <?php esc_html_e( 'Do NOT upload official KICD curriculum PDFs – use your own interpreted notes', 'somo-huru' ); ?></li>
    </ul>
</div>
