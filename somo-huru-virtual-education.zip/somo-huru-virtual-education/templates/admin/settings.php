<?php defined( 'ABSPATH' ) || exit; if ( ! current_user_can( 'manage_options' ) ) return; ?>

<div class="wrap shve-admin-wrap">
    <h1><?php esc_html_e( 'Somo Huru Settings', 'somo-huru' ); ?></h1>

    <form method="post">
        <?php wp_nonce_field( 'shve_save_settings', 'shve_settings_nonce' ); ?>

        <h2><?php esc_html_e( 'AI Tutor (OpenAI) Settings', 'somo-huru' ); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="shve_openai_api_key"><?php esc_html_e( 'OpenAI API Key', 'somo-huru' ); ?></label></th>
                <td>
                    <input type="password" id="shve_openai_api_key" name="shve_openai_api_key"
                        value="<?php echo esc_attr( get_option( 'shve_openai_api_key', '' ) ); ?>"
                        class="regular-text" autocomplete="new-password">
                    <p class="description"><?php esc_html_e( 'Your OpenAI secret key. Stored encrypted in the database.', 'somo-huru' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="shve_openai_model"><?php esc_html_e( 'OpenAI Model', 'somo-huru' ); ?></label></th>
                <td>
                    <select id="shve_openai_model" name="shve_openai_model">
                        <?php
                        $models = [ 'gpt-4o-mini', 'gpt-4o', 'gpt-4-turbo', 'gpt-3.5-turbo' ];
                        $current_model = get_option( 'shve_openai_model', 'gpt-4o-mini' );
                        foreach ( $models as $m ) :
                        ?>
                            <option value="<?php echo esc_attr( $m ); ?>" <?php selected( $current_model, $m ); ?>><?php echo esc_html( $m ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'gpt-4o-mini is recommended for cost-effectiveness.', 'somo-huru' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Use OpenAI Fallback', 'somo-huru' ); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="shve_ai_fallback" value="1" <?php checked( get_option( 'shve_ai_fallback', 1 ), 1 ); ?>>
                        <?php esc_html_e( 'If no local lesson notes match, fall back to OpenAI for a general answer', 'somo-huru' ); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th><label for="shve_rag_context_posts"><?php esc_html_e( 'RAG: Max Posts to Search', 'somo-huru' ); ?></label></th>
                <td>
                    <input type="number" id="shve_rag_context_posts" name="shve_rag_context_posts"
                        value="<?php echo esc_attr( get_option( 'shve_rag_context_posts', 5 ) ); ?>"
                        min="1" max="20" class="small-text">
                    <p class="description"><?php esc_html_e( 'Number of lesson notes to search before calling OpenAI.', 'somo-huru' ); ?></p>
                </td>
            </tr>
        </table>

        <?php submit_button( __( 'Save Settings', 'somo-huru' ) ); ?>
    </form>
</div>
