<?php defined( 'ABSPATH' ) || exit; ?>

<section class="shve-resource-grid" aria-label="<?php esc_attr_e( 'Learning Resources', 'somo-huru' ); ?>">

    <?php if ( ! $resources->have_posts() ) : ?>
        <p class="shve-resource-grid__empty"><?php esc_html_e( 'No resources found for the selected filters.', 'somo-huru' ); ?></p>
    <?php else : ?>

        <div class="shve-resource-grid__inner">
            <?php while ( $resources->have_posts() ) : $resources->the_post(); ?>
                <?php
                $post_id        = get_the_ID();
                $attachment_id  = get_post_meta( $post_id, '_shve_file_id', true );
                $has_file       = ! empty( $attachment_id );
                $grade_terms    = get_the_terms( $post_id, 'shve_grade' );
                $subject_terms  = get_the_terms( $post_id, 'shve_subject' );
                $term_terms     = get_the_terms( $post_id, 'shve_term' );
                $post_type_obj  = get_post_type_object( get_post_type() );
                $type_label     = $post_type_obj ? $post_type_obj->labels->singular_name : '';
                ?>
                <article class="shve-card" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="shve-card__thumb">
                            <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
                                <?php the_post_thumbnail( 'medium', [ 'loading' => 'lazy' ] ); ?>
                            </a>
                        </div>
                    <?php else : ?>
                        <div class="shve-card__thumb shve-card__thumb--placeholder" aria-hidden="true">📄</div>
                    <?php endif; ?>

                    <div class="shve-card__body">
                        <span class="shve-card__type-badge"><?php echo esc_html( $type_label ); ?></span>

                        <h3 class="shve-card__title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>

                        <div class="shve-card__meta">
                            <?php if ( $grade_terms && ! is_wp_error( $grade_terms ) ) : ?>
                                <span class="shve-tag"><?php echo esc_html( $grade_terms[0]->name ); ?></span>
                            <?php endif; ?>
                            <?php if ( $subject_terms && ! is_wp_error( $subject_terms ) ) : ?>
                                <span class="shve-tag shve-tag--subject"><?php echo esc_html( $subject_terms[0]->name ); ?></span>
                            <?php endif; ?>
                            <?php if ( $term_terms && ! is_wp_error( $term_terms ) ) : ?>
                                <span class="shve-tag shve-tag--term"><?php echo esc_html( $term_terms[0]->name ); ?></span>
                            <?php endif; ?>
                        </div>

                        <?php if ( has_excerpt() ) : ?>
                            <p class="shve-card__excerpt"><?php the_excerpt(); ?></p>
                        <?php endif; ?>

                        <div class="shve-card__actions">
                            <a href="<?php the_permalink(); ?>" class="shve-btn shve-btn--ghost shve-btn--sm">
                                <?php esc_html_e( 'View', 'somo-huru' ); ?>
                            </a>
                            <?php if ( $has_file && ( current_user_can( 'shve_download_resources' ) || current_user_can( 'shve_upload_resources' ) ) ) : ?>
                                <a href="<?php echo esc_url( wp_get_attachment_url( $attachment_id ) ); ?>" class="shve-btn shve-btn--primary shve-btn--sm" download>
                                    ↓ <?php esc_html_e( 'Download', 'somo-huru' ); ?>
                                </a>
                            <?php elseif ( $has_file && ! is_user_logged_in() ) : ?>
                                <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="shve-btn shve-btn--ghost shve-btn--sm">
                                    <?php esc_html_e( 'Login to Download', 'somo-huru' ); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <?php if ( $resources->max_num_pages > 1 ) : ?>
            <div class="shve-pagination">
                <?php
                echo paginate_links( [
                    'total'   => $resources->max_num_pages,
                    'current' => max( 1, get_query_var( 'paged' ) ),
                ] );
                ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</section>
