<?php defined( 'ABSPATH' ) || exit; ?>

<div class="shve-ask-teacher" id="shve-ask-teacher">
    <h3 class="shve-ask-teacher__title">
        <span aria-hidden="true">✉️</span> <?php esc_html_e( 'Ask Your Teacher', 'somo-huru' ); ?>
    </h3>
    <p class="shve-ask-teacher__desc"><?php esc_html_e( 'Have a question your AI Tutor couldn\'t answer? Send it directly to your teacher.', 'somo-huru' ); ?></p>

    <div id="shve-ask-teacher-response" class="shve-notice" hidden></div>

    <form id="shve-ask-teacher-form" novalidate>
        <?php wp_nonce_field( 'shve_nonce', 'shve_ask_teacher_nonce' ); ?>
        <input type="hidden" name="post_id" value="<?php echo esc_attr( $atts['post_id'] ); ?>">

        <label for="shve-teacher-question" class="shve-label">
            <?php esc_html_e( 'Your Question', 'somo-huru' ); ?>
        </label>
        <textarea
            id="shve-teacher-question"
            name="question"
            class="shve-textarea"
            rows="4"
            placeholder="<?php esc_attr_e( 'Write your question here…', 'somo-huru' ); ?>"
            maxlength="1000"
            required
        ></textarea>

        <button type="submit" class="shve-btn shve-btn--secondary">
            <?php esc_html_e( 'Send Question to Teacher', 'somo-huru' ); ?>
        </button>
    </form>
</div>
