<?php defined( 'ABSPATH' ) || exit; ?>

<div class="shve-ai-tutor" id="shve-ai-tutor" data-grade="<?php echo esc_attr( $atts['grade'] ); ?>" data-subject="<?php echo esc_attr( $atts['subject'] ); ?>" role="region" aria-label="<?php esc_attr_e( 'AI Tutor', 'somo-huru' ); ?>">

    <div class="shve-ai-tutor__header">
        <div class="shve-ai-tutor__avatar" aria-hidden="true">🤖</div>
        <div>
            <h3 class="shve-ai-tutor__title"><?php echo esc_html( $atts['title'] ); ?></h3>
            <p class="shve-ai-tutor__subtitle"><?php esc_html_e( 'Ask me anything about your lessons. I\'m here to help!', 'somo-huru' ); ?></p>
        </div>
    </div>

    <div class="shve-ai-tutor__chat" id="shve-ai-chat-log" aria-live="polite" aria-relevant="additions" role="log">
        <div class="shve-ai-bubble shve-ai-bubble--assistant">
            <?php
            $grade_label = $atts['grade'] ? ucwords( str_replace( '-', ' ', $atts['grade'] ) ) : '';
            $subj_label  = $atts['subject'] ? ucwords( str_replace( '-', ' ', $atts['subject'] ) ) : '';
            $greeting    = sprintf(
                /* translators: 1: Grade 2: Subject */
                esc_html__( 'Hello! I\'m your Somo Huru AI Tutor%s%s. Type your question below and I\'ll help you understand!', 'somo-huru' ),
                $grade_label ? ' for ' . esc_html( $grade_label ) : '',
                $subj_label  ? ' ' . esc_html( $subj_label ) : ''
            );
            echo $greeting;
            ?>
        </div>
    </div>

    <form class="shve-ai-tutor__form" id="shve-ai-form" novalidate>
        <label for="shve-ai-question" class="screen-reader-text"><?php esc_html_e( 'Your question', 'somo-huru' ); ?></label>
        <textarea
            id="shve-ai-question"
            name="question"
            class="shve-ai-tutor__input"
            placeholder="<?php esc_attr_e( 'Type your question here… e.g. What is photosynthesis?', 'somo-huru' ); ?>"
            rows="3"
            maxlength="500"
            required
        ></textarea>
        <div class="shve-ai-tutor__actions">
            <button type="submit" class="shve-btn shve-btn--primary" id="shve-ai-submit">
                <span class="shve-ai-submit__text"><?php esc_html_e( 'Ask AI Tutor', 'somo-huru' ); ?></span>
                <span class="shve-ai-submit__loading" hidden aria-live="polite"><?php esc_html_e( 'Thinking…', 'somo-huru' ); ?></span>
            </button>
            <button type="button" class="shve-btn shve-btn--ghost" id="shve-ai-clear"><?php esc_html_e( 'Clear', 'somo-huru' ); ?></button>
        </div>
        <p class="shve-ai-tutor__disclaimer">
            <?php esc_html_e( 'AI answers are based on uploaded lesson notes. Always verify with your teacher.', 'somo-huru' ); ?>
        </p>
    </form>
</div>
