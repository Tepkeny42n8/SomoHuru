<?php
defined( 'ABSPATH' ) || exit;
get_header();

$grade   = get_query_var( 'shve_grade' );
$subject = get_query_var( 'shve_subject' );
$strand  = get_query_var( 'shve_strand' );
$term    = get_query_var( 'shve_term' );
$week    = get_query_var( 'shve_week' );

$to_label = fn( $s ) => ucwords( str_replace( '-', ' ', $s ) );
$parts    = array_filter( [ $to_label( $grade ), $to_label( $subject ), $to_label( $strand ), $to_label( $term ), $to_label( $week ) ] );
$title    = implode( ' › ', $parts );

$query = $GLOBALS['shve_archive_query'] ?? null;
?>

<main id="shve-archive" class="shve-main">
    <div class="shve-container">

        <nav class="shve-breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'somo-huru' ); ?>">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'somo-huru' ); ?></a>
            <?php foreach ( array_filter( [ $grade, $subject, $strand, $term, $week ] ) as $crumb ) : ?>
                <span aria-hidden="true"> › </span>
                <span><?php echo esc_html( $to_label( $crumb ) ); ?></span>
            <?php endforeach; ?>
        </nav>

        <h1 class="shve-archive-title"><?php echo esc_html( $title ?: __( 'Learning Resources', 'somo-huru' ) ); ?></h1>

        <?php if ( $query && $query->have_posts() ) :
            $atts = [];
            include SHVE_PLUGIN_DIR . 'templates/shortcodes/resource-grid.php';
            wp_reset_postdata();
        else : ?>
            <div class="shve-empty-state">
                <p><?php esc_html_e( 'No resources found for this filter. Check back soon or ask your teacher to upload notes.', 'somo-huru' ); ?></p>
            </div>
        <?php endif; ?>

        <?php echo do_shortcode( '[shve_ai_tutor grade="' . esc_attr( $grade ) . '" subject="' . esc_attr( $subject ) . '"]' ); ?>

    </div>
</main>

<?php get_footer(); ?>
