<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Shortcodes {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function register() {
        add_shortcode( 'shve_ai_tutor',        [ $this, 'ai_tutor' ] );
        add_shortcode( 'shve_ask_teacher',     [ $this, 'ask_teacher' ] );
        add_shortcode( 'shve_resources',       [ $this, 'resource_grid' ] );
        add_shortcode( 'shve_download_button', [ $this, 'download_button' ] );
        add_shortcode( 'shve_read_aloud',      [ $this, 'read_aloud_button' ] );
    }

    public function ai_tutor( $atts ) {
        $atts = shortcode_atts( [
            'grade'   => '',
            'subject' => '',
            'title'   => __( 'Ask the AI Tutor', 'somo-huru' ),
        ], $atts, 'shve_ai_tutor' );

        ob_start();
        include SHVE_PLUGIN_DIR . 'templates/shortcodes/ai-tutor.php';
        return ob_get_clean();
    }

    public function ask_teacher( $atts ) {
        $atts = shortcode_atts( [
            'post_id' => get_the_ID(),
        ], $atts, 'shve_ask_teacher' );

        if ( ! is_user_logged_in() ) {
            return '<p class="shve-login-notice">' . esc_html__( 'Please log in to ask a teacher.', 'somo-huru' ) . '</p>';
        }

        ob_start();
        include SHVE_PLUGIN_DIR . 'templates/shortcodes/ask-teacher.php';
        return ob_get_clean();
    }

    public function resource_grid( $atts ) {
        $atts = shortcode_atts( [
            'grade'     => '',
            'subject'   => '',
            'term'      => '',
            'week'      => '',
            'type'      => '',
            'per_page'  => 12,
        ], $atts, 'shve_resources' );

        $query_args = [
            'post_status'    => 'publish',
            'posts_per_page' => intval( $atts['per_page'] ),
            'tax_query'      => [ 'relation' => 'AND' ],
        ];

        if ( ! empty( $atts['type'] ) ) {
            $query_args['post_type'] = sanitize_key( $atts['type'] );
        } else {
            $query_args['post_type'] = [
                'shve_scheme', 'shve_lesson_plan', 'shve_lesson_note',
                'shve_assessment', 'shve_revision', 'shve_worksheet',
                'shve_learner_res', 'shve_vocational',
            ];
        }

        $tax_map = [
            'grade'   => 'shve_grade',
            'subject' => 'shve_subject',
            'term'    => 'shve_term',
            'week'    => 'shve_week',
        ];

        foreach ( $tax_map as $attr => $taxonomy ) {
            if ( ! empty( $atts[ $attr ] ) ) {
                $query_args['tax_query'][] = [
                    'taxonomy' => $taxonomy,
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field( $atts[ $attr ] ),
                ];
            }
        }

        $resources = new WP_Query( $query_args );

        ob_start();
        include SHVE_PLUGIN_DIR . 'templates/shortcodes/resource-grid.php';
        wp_reset_postdata();
        return ob_get_clean();
    }

    public function download_button( $atts ) {
        $atts = shortcode_atts( [
            'post_id' => get_the_ID(),
            'label'   => __( 'Download Resource', 'somo-huru' ),
        ], $atts, 'shve_download_button' );

        $post_id       = intval( $atts['post_id'] );
        $attachment_id = get_post_meta( $post_id, '_shve_file_id', true );
        if ( ! $attachment_id ) return '';

        $url = wp_get_attachment_url( $attachment_id );
        if ( ! $url ) return '';

        return sprintf(
            '<a href="%s" class="shve-btn shve-btn--download" download>%s</a>',
            esc_url( $url ),
            esc_html( $atts['label'] )
        );
    }

    public function read_aloud_button( $atts ) {
        $atts = shortcode_atts( [
            'target' => '.entry-content',
            'label'  => __( 'Read Aloud', 'somo-huru' ),
        ], $atts, 'shve_read_aloud' );

        return sprintf(
            '<button class="shve-btn shve-btn--read-aloud" data-target="%s" aria-label="%s">
                <span class="dashicons dashicons-controls-volumeon" aria-hidden="true"></span> %s
            </button>',
            esc_attr( $atts['target'] ),
            esc_attr( $atts['label'] ),
            esc_html( $atts['label'] )
        );
    }
}
