<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Roles {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function register() {
        add_filter( 'user_has_cap', [ $this, 'map_caps' ], 10, 4 );
    }

    public function add_roles() {
        // SHVE Teacher
        add_role( 'shve_teacher', __( 'Somo Huru Teacher', 'somo-huru' ), [
            'read'                         => true,
            'upload_files'                 => true,
            'edit_posts'                   => true,
            'edit_published_posts'         => true,
            'delete_posts'                 => false,
            // Custom resource caps
            'read_shve_resource'           => true,
            'edit_shve_resource'           => true,
            'edit_shve_resources'          => true,
            'edit_others_shve_resources'   => false,
            'publish_shve_resources'       => true,
            'read_private_shve_resources'  => false,
            'delete_shve_resource'         => false,
            'delete_shve_resources'        => false,
            'shve_upload_resources'        => true,
        ] );

        // SHVE Student
        add_role( 'shve_student', __( 'Somo Huru Student', 'somo-huru' ), [
            'read'                        => true,
            'read_shve_resource'          => true,
            'edit_shve_resources'         => false,
            'publish_shve_resources'      => false,
            'shve_ask_ai_tutor'           => true,
            'shve_ask_teacher'            => true,
            'shve_download_resources'     => true,
        ] );

        // Add resource caps to admin
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin_caps = [
                'read_shve_resource', 'edit_shve_resource', 'edit_shve_resources',
                'edit_others_shve_resources', 'publish_shve_resources',
                'read_private_shve_resources', 'delete_shve_resource',
                'delete_shve_resources', 'delete_others_shve_resources',
                'shve_upload_resources', 'shve_manage_settings',
                'shve_ask_ai_tutor', 'shve_ask_teacher', 'shve_download_resources',
            ];
            foreach ( $admin_caps as $cap ) {
                $admin->add_cap( $cap );
            }
        }
    }

    public function map_caps( $allcaps, $caps, $args, $user ) {
        if ( empty( $caps ) ) return $allcaps;
        foreach ( $caps as $cap ) {
            if ( in_array( $cap, [
                'read_shve_resource', 'edit_shve_resource', 'edit_shve_resources',
                'delete_shve_resource', 'publish_shve_resources',
            ], true ) ) {
                if ( ! empty( $allcaps['administrator'] ) || ! empty( $allcaps['shve_upload_resources'] ) ) {
                    $allcaps[ $cap ] = true;
                }
            }
        }
        return $allcaps;
    }
}
