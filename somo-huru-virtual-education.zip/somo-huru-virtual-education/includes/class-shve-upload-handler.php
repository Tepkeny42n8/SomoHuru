<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Upload_Handler {

    private static $instance = null;
    private $allowed_mime_types = [
        'pdf'  => 'application/pdf',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'doc'  => 'application/msword',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
    ];

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    /**
     * Handle a teacher resource file upload.
     * Returns attachment ID on success or WP_Error.
     *
     * @param array  $file      $_FILES element.
     * @param int    $post_id   Parent post ID.
     * @param string $field_key Meta key to store attachment ID.
     */
    public function handle_upload( $file, $post_id, $field_key = '_shve_file_id' ) {
        if ( ! current_user_can( 'shve_upload_resources' ) ) {
            return new WP_Error( 'permission_denied', __( 'You do not have permission to upload files.', 'somo-huru' ) );
        }

        if ( empty( $file['name'] ) || $file['error'] !== UPLOAD_ERR_OK ) {
            return new WP_Error( 'upload_error', __( 'File upload error.', 'somo-huru' ) );
        }

        // Validate MIME
        $finfo = new finfo( FILEINFO_MIME_TYPE );
        $mime  = $finfo->file( $file['tmp_name'] );
        if ( ! in_array( $mime, $this->allowed_mime_types, true ) ) {
            return new WP_Error( 'invalid_mime', __( 'File type not allowed.', 'somo-huru' ) );
        }

        // Validate file size (max 50 MB)
        if ( $file['size'] > 50 * MB_IN_BYTES ) {
            return new WP_Error( 'file_too_large', __( 'File exceeds the 50 MB upload limit.', 'somo-huru' ) );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $attachment_id = media_handle_upload( $this->get_file_key( $file ), $post_id );

        if ( is_wp_error( $attachment_id ) ) {
            return $attachment_id;
        }

        update_post_meta( $post_id, $field_key, $attachment_id );
        return $attachment_id;
    }

    private function get_file_key( $file ) {
        // WordPress media_handle_upload expects $_FILES key. We use a temp key approach.
        static $counter = 0;
        $key = 'shve_upload_' . $counter++;
        $_FILES[ $key ] = $file;
        return $key;
    }

    /**
     * Get the download URL for an attachment stored in post meta.
     */
    public function get_download_url( $post_id, $field_key = '_shve_file_id' ) {
        $attachment_id = get_post_meta( $post_id, $field_key, true );
        if ( ! $attachment_id ) return '';
        return wp_get_attachment_url( $attachment_id );
    }

    /**
     * Secure download redirect (checks capability).
     */
    public function secure_download( $post_id ) {
        if ( ! current_user_can( 'shve_download_resources' ) && ! current_user_can( 'shve_upload_resources' ) ) {
            wp_die( esc_html__( 'You need to be enrolled to download this resource.', 'somo-huru' ) );
        }
        $url = $this->get_download_url( $post_id );
        if ( empty( $url ) ) {
            wp_die( esc_html__( 'File not found.', 'somo-huru' ) );
        }
        wp_redirect( $url );
        exit;
    }
}
