<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Post_Types {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function register() {
        $post_types = [
            'shve_scheme'    => [ 'name' => 'Schemes of Work',     'singular' => 'Scheme of Work',    'slug' => 'scheme-of-work',    'menu_icon' => 'dashicons-book-alt',    'capability_type' => 'shve_resource' ],
            'shve_lesson_plan'  => [ 'name' => 'Lesson Plans',     'singular' => 'Lesson Plan',       'slug' => 'lesson-plan',       'menu_icon' => 'dashicons-clipboard',   'capability_type' => 'shve_resource' ],
            'shve_lesson_note'  => [ 'name' => 'Lesson Notes',     'singular' => 'Lesson Note',       'slug' => 'lesson-note',       'menu_icon' => 'dashicons-welcome-write-blog', 'capability_type' => 'shve_resource' ],
            'shve_assessment'   => [ 'name' => 'Assessments',      'singular' => 'Assessment',        'slug' => 'assessment',        'menu_icon' => 'dashicons-feedback',    'capability_type' => 'shve_resource' ],
            'shve_revision'     => [ 'name' => 'Revision Questions', 'singular' => 'Revision Question', 'slug' => 'revision-question', 'menu_icon' => 'dashicons-editor-help', 'capability_type' => 'shve_resource' ],
            'shve_worksheet'    => [ 'name' => 'Printable Worksheets', 'singular' => 'Printable Worksheet', 'slug' => 'worksheet',    'menu_icon' => 'dashicons-printer',     'capability_type' => 'shve_resource' ],
            'shve_teacher_res'  => [ 'name' => 'Teacher Resources', 'singular' => 'Teacher Resource',  'slug' => 'teacher-resource',  'menu_icon' => 'dashicons-groups',      'capability_type' => 'shve_resource' ],
            'shve_learner_res'  => [ 'name' => 'Learner Resources', 'singular' => 'Learner Resource',  'slug' => 'learner-resource',  'menu_icon' => 'dashicons-book',        'capability_type' => 'shve_resource' ],
            'shve_vocational'   => [ 'name' => 'Vocational Content', 'singular' => 'Vocational Content', 'slug' => 'vocational',      'menu_icon' => 'dashicons-hammer',      'capability_type' => 'shve_resource' ],
        ];

        foreach ( $post_types as $key => $args ) {
            register_post_type( $key, $this->build_args( $args ) );
        }
    }

    private function build_args( $data ) {
        return [
            'labels' => [
                'name'               => __( $data['name'], 'somo-huru' ),
                'singular_name'      => __( $data['singular'], 'somo-huru' ),
                'add_new'            => __( 'Add New', 'somo-huru' ),
                'add_new_item'       => sprintf( __( 'Add New %s', 'somo-huru' ), $data['singular'] ),
                'edit_item'          => sprintf( __( 'Edit %s', 'somo-huru' ), $data['singular'] ),
                'view_item'          => sprintf( __( 'View %s', 'somo-huru' ), $data['singular'] ),
                'search_items'       => sprintf( __( 'Search %s', 'somo-huru' ), $data['name'] ),
                'not_found'          => sprintf( __( 'No %s found', 'somo-huru' ), strtolower( $data['name'] ) ),
                'menu_name'          => __( $data['name'], 'somo-huru' ),
            ],
            'public'             => true,
            'show_ui'            => true,
            'show_in_menu'       => 'somo-huru',
            'show_in_rest'       => true,
            'has_archive'        => true,
            'rewrite'            => [ 'slug' => $data['slug'], 'with_front' => false ],
            'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'author' ],
            'menu_icon'          => $data['menu_icon'],
            'capability_type'    => [ $data['capability_type'], $data['capability_type'] . 's' ],
            'map_meta_cap'       => true,
            'show_in_nav_menus'  => true,
        ];
    }
}
