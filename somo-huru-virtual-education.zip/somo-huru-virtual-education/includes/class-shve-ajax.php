<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Ajax {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function register() {
        // AI Tutor
        add_action( 'wp_ajax_shve_ai_question',        [ $this, 'handle_ai_question' ] );
        add_action( 'wp_ajax_nopriv_shve_ai_question', [ $this, 'handle_ai_question' ] );

        // Ask a Teacher
        add_action( 'wp_ajax_shve_ask_teacher',        [ $this, 'handle_ask_teacher' ] );

        // Teacher upload
        add_action( 'wp_ajax_shve_teacher_upload',     [ $this, 'handle_teacher_upload' ] );

        // Secure download
        add_action( 'wp_ajax_shve_download',           [ $this, 'handle_download' ] );
        add_action( 'wp_ajax_nopriv_shve_download',    [ $this, 'handle_download' ] );
    }

    public function handle_ai_question() {
        check_ajax_referer( 'shve_nonce', 'nonce' );

        $question = sanitize_textarea_field( wp_unslash( $_POST['question'] ?? '' ) );
        $grade    = sanitize_text_field( wp_unslash( $_POST['grade'] ?? '' ) );
        $subject  = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );

        if ( empty( $question ) ) {
            wp_send_json_error( [ 'message' => __( 'Please enter a question.', 'somo-huru' ) ] );
        }

        $ai = SHVE_AI_Tutor::instance();
        $response = $ai->answer( $question, $grade, $subject );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => $response->get_error_message() ] );
        }

        wp_send_json_success( [ 'answer' => $response ] );
    }

    public function handle_ask_teacher() {
        check_ajax_referer( 'shve_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'You must be logged in.', 'somo-huru' ) ] );
        }

        $post_id  = intval( $_POST['post_id'] ?? 0 );
        $question = sanitize_textarea_field( wp_unslash( $_POST['question'] ?? '' ) );
        $user     = wp_get_current_user();

        if ( empty( $question ) || ! $post_id ) {
            wp_send_json_error( [ 'message' => __( 'Invalid request.', 'somo-huru' ) ] );
        }

        // Store as comment
        $comment_id = wp_insert_comment( [
            'comment_post_ID'      => $post_id,
            'comment_author'       => $user->display_name,
            'comment_author_email' => $user->user_email,
            'comment_content'      => $question,
            'comment_type'         => 'shve_question',
            'comment_approved'     => 0,
            'user_id'              => $user->ID,
        ] );

        if ( $comment_id ) {
            // Notify teachers by email
            $this->notify_teachers( $post_id, $question, $user );
            wp_send_json_success( [ 'message' => __( 'Your question has been sent to the teacher. You will receive a reply soon.', 'somo-huru' ) ] );
        } else {
            wp_send_json_error( [ 'message' => __( 'Could not send your question. Try again.', 'somo-huru' ) ] );
        }
    }

    private function notify_teachers( $post_id, $question, $user ) {
        $teachers = get_users( [ 'role' => 'shve_teacher' ] );
        $admins   = get_users( [ 'role' => 'administrator' ] );
        $notify   = array_merge( $teachers, $admins );
        $post     = get_post( $post_id );
        foreach ( $notify as $teacher ) {
            wp_mail(
                $teacher->user_email,
                sprintf( __( '[Somo Huru] New student question on: %s', 'somo-huru' ), get_the_title( $post_id ) ),
                sprintf(
                    __( "Student: %s\nQuestion: %s\n\nView resource: %s", 'somo-huru' ),
                    $user->display_name,
                    $question,
                    get_permalink( $post_id )
                )
            );
        }
    }

    public function handle_teacher_upload() {
        check_ajax_referer( 'shve_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'shve_upload_resources' ) ) {
            wp_send_json_error( [ 'message' => __( 'Permission denied.', 'somo-huru' ) ] );
        }

        $post_id  = intval( $_POST['post_id'] ?? 0 );
        $file_key = sanitize_key( $_POST['file_key'] ?? 'shve_file' );

        if ( ! isset( $_FILES[ $file_key ] ) ) {
            wp_send_json_error( [ 'message' => __( 'No file received.', 'somo-huru' ) ] );
        }

        $handler = SHVE_Upload_Handler::instance();
        $result  = $handler->handle_upload( $_FILES[ $file_key ], $post_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }

        wp_send_json_success( [
            'attachment_id' => $result,
            'url'           => wp_get_attachment_url( $result ),
            'message'       => __( 'File uploaded successfully.', 'somo-huru' ),
        ] );
    }

    public function handle_download() {
        $post_id = intval( $_GET['post_id'] ?? 0 );
        $nonce   = sanitize_text_field( wp_unslash( $_GET['nonce'] ?? '' ) );

        if ( ! wp_verify_nonce( $nonce, 'shve_download_' . $post_id ) ) {
            wp_die( esc_html__( 'Security check failed.', 'somo-huru' ) );
        }

        SHVE_Upload_Handler::instance()->secure_download( $post_id );
    }
}
