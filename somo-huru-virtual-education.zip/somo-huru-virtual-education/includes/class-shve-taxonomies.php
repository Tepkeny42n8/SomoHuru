<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Taxonomies {

    private static $instance = null;
    private $all_post_types = [
        'shve_scheme', 'shve_lesson_plan', 'shve_lesson_note',
        'shve_assessment', 'shve_revision', 'shve_worksheet',
        'shve_teacher_res', 'shve_learner_res', 'shve_vocational',
    ];

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function register() {
        // Grade Level taxonomy (CBC: PP1–Grade 6, Junior Secondary: Grade 7–9, Senior Secondary: Form 1–4)
        register_taxonomy( 'shve_grade', $this->all_post_types, [
            'label'             => __( 'Grade / Form', 'somo-huru' ),
            'labels'            => $this->tax_labels( 'Grade / Form', 'Grades / Forms' ),
            'hierarchical'      => true,
            'public'            => true,
            'show_ui'           => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'grade', 'hierarchical' => true ],
        ] );

        // Subject
        register_taxonomy( 'shve_subject', $this->all_post_types, [
            'label'             => __( 'Subject', 'somo-huru' ),
            'labels'            => $this->tax_labels( 'Subject', 'Subjects' ),
            'hierarchical'      => true,
            'public'            => true,
            'show_ui'           => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'subject' ],
        ] );

        // Strand
        register_taxonomy( 'shve_strand', $this->all_post_types, [
            'label'        => __( 'Strand', 'somo-huru' ),
            'labels'       => $this->tax_labels( 'Strand', 'Strands' ),
            'hierarchical' => true,
            'public'       => true,
            'show_ui'      => true,
            'show_in_rest' => true,
            'rewrite'      => [ 'slug' => 'strand' ],
        ] );

        // Sub-Strand
        register_taxonomy( 'shve_substrand', $this->all_post_types, [
            'label'        => __( 'Sub-Strand', 'somo-huru' ),
            'labels'       => $this->tax_labels( 'Sub-Strand', 'Sub-Strands' ),
            'hierarchical' => true,
            'public'       => true,
            'show_ui'      => true,
            'show_in_rest' => true,
            'rewrite'      => [ 'slug' => 'sub-strand' ],
        ] );

        // Term
        register_taxonomy( 'shve_term', $this->all_post_types, [
            'label'             => __( 'Term', 'somo-huru' ),
            'labels'            => $this->tax_labels( 'Term', 'Terms' ),
            'hierarchical'      => true,
            'public'            => true,
            'show_ui'           => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'term' ],
        ] );

        // Week
        register_taxonomy( 'shve_week', $this->all_post_types, [
            'label'        => __( 'Week', 'somo-huru' ),
            'labels'       => $this->tax_labels( 'Week', 'Weeks' ),
            'hierarchical' => false,
            'public'       => true,
            'show_ui'      => true,
            'show_in_rest' => true,
            'rewrite'      => [ 'slug' => 'week' ],
        ] );

        // Curriculum Level
        register_taxonomy( 'shve_level', $this->all_post_types, [
            'label'             => __( 'Curriculum Level', 'somo-huru' ),
            'labels'            => $this->tax_labels( 'Curriculum Level', 'Curriculum Levels' ),
            'hierarchical'      => true,
            'public'            => true,
            'show_ui'           => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'curriculum-level' ],
        ] );

        add_action( 'init', [ $this, 'insert_default_terms' ], 20 );
    }

    public function insert_default_terms() {
        // Grades
        $grades = [
            'PP1', 'PP2',
            'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6',
            'Grade 7', 'Grade 8', 'Grade 9',
            'Form 1', 'Form 2', 'Form 3', 'Form 4',
        ];
        foreach ( $grades as $grade ) {
            if ( ! term_exists( $grade, 'shve_grade' ) ) {
                wp_insert_term( $grade, 'shve_grade' );
            }
        }

        // Terms
        foreach ( [ 'Term 1', 'Term 2', 'Term 3' ] as $term ) {
            if ( ! term_exists( $term, 'shve_term' ) ) {
                wp_insert_term( $term, 'shve_term' );
            }
        }

        // Weeks
        for ( $w = 1; $w <= 14; $w++ ) {
            $label = 'Week ' . $w;
            if ( ! term_exists( $label, 'shve_week' ) ) {
                wp_insert_term( $label, 'shve_week' );
            }
        }

        // Curriculum Levels
        $levels = [ 'Early Years (PP1–PP2)', 'Lower Primary (Grade 1–3)', 'Upper Primary (Grade 4–6)', 'Junior Secondary (Grade 7–9)', 'Senior Secondary (Form 1–4)' ];
        foreach ( $levels as $lvl ) {
            if ( ! term_exists( $lvl, 'shve_level' ) ) {
                wp_insert_term( $lvl, 'shve_level' );
            }
        }
    }

    private function tax_labels( $singular, $plural ) {
        return [
            'name'              => __( $plural,   'somo-huru' ),
            'singular_name'     => __( $singular, 'somo-huru' ),
            'search_items'      => sprintf( __( 'Search %s', 'somo-huru' ), $plural ),
            'all_items'         => sprintf( __( 'All %s', 'somo-huru' ), $plural ),
            'parent_item'       => sprintf( __( 'Parent %s', 'somo-huru' ), $singular ),
            'parent_item_colon' => sprintf( __( 'Parent %s:', 'somo-huru' ), $singular ),
            'edit_item'         => sprintf( __( 'Edit %s', 'somo-huru' ), $singular ),
            'update_item'       => sprintf( __( 'Update %s', 'somo-huru' ), $singular ),
            'add_new_item'      => sprintf( __( 'Add New %s', 'somo-huru' ), $singular ),
            'new_item_name'     => sprintf( __( 'New %s Name', 'somo-huru' ), $singular ),
            'menu_name'         => __( $plural, 'somo-huru' ),
        ];
    }
}
