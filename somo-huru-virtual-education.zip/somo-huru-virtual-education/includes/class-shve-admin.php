<?php
defined( 'ABSPATH' ) || exit;

class SHVE_Admin {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function init() {
        add_action( 'admin_menu',            [ $this, 'register_menu' ] );
        add_action( 'add_meta_boxes',        [ $this, 'add_meta_boxes' ] );
        add_action( 'save_post',             [ $this, 'save_meta' ], 10, 2 );
        add_filter( 'manage_posts_columns',  [ $this, 'add_list_columns' ], 10, 2 );
        add_action( 'manage_posts_custom_column', [ $this, 'render_list_column' ], 10, 2 );
    }

    public function register_menu() {
        add_menu_page(
            __( 'Somo Huru', 'somo-huru' ),
            __( 'Somo Huru', 'somo-huru' ),
            'read',
            'somo-huru',
            [ $this, 'dashboard_page' ],
            'dashicons-welcome-learn-more',
            4
        );

        add_submenu_page( 'somo-huru', __( 'Dashboard', 'somo-huru' ),    __( 'Dashboard', 'somo-huru' ),    'read',                   'somo-huru',            [ $this, 'dashboard_page' ] );
        add_submenu_page( 'somo-huru', __( 'Upload Resource', 'somo-huru' ), __( 'Upload Resource', 'somo-huru' ), 'shve_upload_resources', 'shve-upload',       [ $this, 'upload_page' ] );
        add_submenu_page( 'somo-huru', __( 'Student Questions', 'somo-huru' ), __( 'Student Questions', 'somo-huru' ), 'shve_upload_resources', 'shve-questions', [ $this, 'questions_page' ] );
        add_submenu_page( 'somo-huru', __( 'Settings', 'somo-huru' ),      __( 'Settings', 'somo-huru' ),      'manage_options',         'shve-settings',        [ $this, 'settings_page' ] );
    }

    public function dashboard_page() {
        include SHVE_PLUGIN_DIR . 'templates/admin/dashboard.php';
    }

    public function upload_page() {
        include SHVE_PLUGIN_DIR . 'templates/admin/upload.php';
    }

    public function questions_page() {
        include SHVE_PLUGIN_DIR . 'templates/admin/questions.php';
    }

    public function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        if ( isset( $_POST['shve_settings_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['shve_settings_nonce'] ) ), 'shve_save_settings' ) ) {
            update_option( 'shve_openai_api_key', sanitize_text_field( wp_unslash( $_POST['shve_openai_api_key'] ?? '' ) ) );
            update_option( 'shve_openai_model',   sanitize_text_field( wp_unslash( $_POST['shve_openai_model'] ?? 'gpt-4o-mini' ) ) );
            update_option( 'shve_ai_fallback',    intval( $_POST['shve_ai_fallback'] ?? 1 ) );
            update_option( 'shve_rag_context_posts', intval( $_POST['shve_rag_context_posts'] ?? 5 ) );
            echo '<div class="notice notice-success"><p>' . esc_html__( 'Settings saved.', 'somo-huru' ) . '</p></div>';
        }

        include SHVE_PLUGIN_DIR . 'templates/admin/settings.php';
    }

    public function add_meta_boxes() {
        $post_types = [
            'shve_scheme', 'shve_lesson_plan', 'shve_lesson_note',
            'shve_assessment', 'shve_revision', 'shve_worksheet',
            'shve_teacher_res', 'shve_learner_res', 'shve_vocational',
        ];

        foreach ( $post_types as $pt ) {
            add_meta_box( 'shve_resource_file',    __( 'Attached File / PDF', 'somo-huru' ),     [ $this, 'meta_box_file' ],     $pt, 'side', 'high' );
            add_meta_box( 'shve_resource_details', __( 'Resource Details', 'somo-huru' ),         [ $this, 'meta_box_details' ],  $pt, 'normal', 'high' );
            add_meta_box( 'shve_seo_box',          __( 'SEO / Schema Settings', 'somo-huru' ),    [ $this, 'meta_box_seo' ],      $pt, 'normal', 'default' );
        }
    }

    public function meta_box_file( $post ) {
        wp_nonce_field( 'shve_save_meta_' . $post->ID, 'shve_meta_nonce' );
        $attachment_id = get_post_meta( $post->ID, '_shve_file_id', true );
        $url           = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';
        ?>
        <div class="shve-meta-file">
            <p>
                <label for="shve_file_upload"><?php esc_html_e( 'Upload a PDF, Word Doc, or Presentation:', 'somo-huru' ); ?></label>
            </p>
            <input type="file" name="shve_file_upload" id="shve_file_upload" accept=".pdf,.doc,.docx,.pptx,.xlsx,.png,.jpg,.jpeg">
            <?php if ( $url ) : ?>
                <p class="shve-current-file">
                    <strong><?php esc_html_e( 'Current file:', 'somo-huru' ); ?></strong>
                    <a href="<?php echo esc_url( $url ); ?>" target="_blank"><?php esc_html_e( 'View / Download', 'somo-huru' ); ?></a>
                    <br>
                    <label>
                        <input type="checkbox" name="shve_remove_file" value="1">
                        <?php esc_html_e( 'Remove this file', 'somo-huru' ); ?>
                    </label>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    public function meta_box_details( $post ) {
        $duration      = get_post_meta( $post->ID, '_shve_duration', true );
        $learning_outcomes = get_post_meta( $post->ID, '_shve_outcomes', true );
        $materials     = get_post_meta( $post->ID, '_shve_materials', true );
        $ai_index      = get_post_meta( $post->ID, '_shve_ai_index', true );
        ?>
        <table class="form-table shve-meta-table">
            <tr>
                <th><label for="shve_duration"><?php esc_html_e( 'Duration (e.g. 40 minutes)', 'somo-huru' ); ?></label></th>
                <td><input type="text" id="shve_duration" name="shve_duration" value="<?php echo esc_attr( $duration ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th><label for="shve_outcomes"><?php esc_html_e( 'Learning Outcomes', 'somo-huru' ); ?></label></th>
                <td><textarea id="shve_outcomes" name="shve_outcomes" rows="4" class="large-text"><?php echo esc_textarea( $learning_outcomes ); ?></textarea></td>
            </tr>
            <tr>
                <th><label for="shve_materials"><?php esc_html_e( 'Materials / References', 'somo-huru' ); ?></label></th>
                <td><textarea id="shve_materials" name="shve_materials" rows="3" class="large-text"><?php echo esc_textarea( $materials ); ?></textarea></td>
            </tr>
            <tr>
                <th><label for="shve_ai_index"><?php esc_html_e( 'AI Tutor Searchable Content', 'somo-huru' ); ?></label></th>
                <td>
                    <textarea id="shve_ai_index" name="shve_ai_index" rows="6" class="large-text"><?php echo esc_textarea( $ai_index ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Plain-text content the AI Tutor will search when answering student questions. Do NOT paste KICD official curriculum text.', 'somo-huru' ); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }

    public function meta_box_seo( $post ) {
        $meta_title = get_post_meta( $post->ID, '_shve_meta_title', true );
        $meta_desc  = get_post_meta( $post->ID, '_shve_meta_desc', true );
        ?>
        <table class="form-table">
            <tr>
                <th><label for="shve_meta_title"><?php esc_html_e( 'SEO Title', 'somo-huru' ); ?></label></th>
                <td>
                    <input type="text" id="shve_meta_title" name="shve_meta_title" value="<?php echo esc_attr( $meta_title ); ?>" class="large-text" maxlength="60">
                    <p class="description"><?php esc_html_e( 'Leave blank to auto-generate. Max 60 chars.', 'somo-huru' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="shve_meta_desc"><?php esc_html_e( 'Meta Description', 'somo-huru' ); ?></label></th>
                <td>
                    <textarea id="shve_meta_desc" name="shve_meta_desc" rows="3" class="large-text" maxlength="160"><?php echo esc_textarea( $meta_desc ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Leave blank to auto-generate. Max 160 chars.', 'somo-huru' ); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }

    public function save_meta( $post_id, $post ) {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;
        if ( ! isset( $_POST['shve_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['shve_meta_nonce'] ) ), 'shve_save_meta_' . $post_id ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Handle file upload
        if ( ! empty( $_FILES['shve_file_upload']['name'] ) ) {
            $handler = SHVE_Upload_Handler::instance();
            $handler->handle_upload( $_FILES['shve_file_upload'], $post_id );
        }

        // Remove file
        if ( ! empty( $_POST['shve_remove_file'] ) ) {
            delete_post_meta( $post_id, '_shve_file_id' );
        }

        // Text meta
        $text_fields = [
            '_shve_duration'   => 'shve_duration',
            '_shve_outcomes'   => 'shve_outcomes',
            '_shve_materials'  => 'shve_materials',
            '_shve_ai_index'   => 'shve_ai_index',
            '_shve_meta_title' => 'shve_meta_title',
            '_shve_meta_desc'  => 'shve_meta_desc',
        ];

        foreach ( $text_fields as $meta_key => $post_key ) {
            if ( isset( $_POST[ $post_key ] ) ) {
                update_post_meta( $post_id, $meta_key, sanitize_textarea_field( wp_unslash( $_POST[ $post_key ] ) ) );
            }
        }
    }

    public function add_list_columns( $columns, $post_type = '' ) {
        $shve_types = [
            'shve_scheme', 'shve_lesson_plan', 'shve_lesson_note',
            'shve_assessment', 'shve_revision', 'shve_worksheet',
            'shve_teacher_res', 'shve_learner_res', 'shve_vocational',
        ];
        if ( ! in_array( $post_type, $shve_types, true ) ) return $columns;
        $columns['shve_grade']   = __( 'Grade', 'somo-huru' );
        $columns['shve_subject'] = __( 'Subject', 'somo-huru' );
        $columns['shve_file']    = __( 'File', 'somo-huru' );
        return $columns;
    }

    public function render_list_column( $column, $post_id ) {
        switch ( $column ) {
            case 'shve_grade':
                $terms = get_the_terms( $post_id, 'shve_grade' );
                echo $terms ? esc_html( implode( ', ', wp_list_pluck( $terms, 'name' ) ) ) : '—';
                break;
            case 'shve_subject':
                $terms = get_the_terms( $post_id, 'shve_subject' );
                echo $terms ? esc_html( implode( ', ', wp_list_pluck( $terms, 'name' ) ) ) : '—';
                break;
            case 'shve_file':
                $id = get_post_meta( $post_id, '_shve_file_id', true );
                if ( $id ) {
                    $url = wp_get_attachment_url( $id );
                    echo '<a href="' . esc_url( $url ) . '" target="_blank">📄 ' . esc_html__( 'View', 'somo-huru' ) . '</a>';
                } else {
                    echo '—';
                }
                break;
        }
    }
}
