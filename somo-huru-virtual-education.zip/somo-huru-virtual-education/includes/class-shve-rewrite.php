<?php
defined( 'ABSPATH' ) || exit;

/**
 * SEO-friendly URL structure:
 * somohuru.com/grade-4/english/writing/term-1/week-3
 */
class SHVE_Rewrite {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    public function init() {
        add_action( 'init',                  [ $this, 'add_rules' ] );
        add_filter( 'post_type_link',        [ $this, 'custom_permalink' ], 10, 2 );
        add_filter( 'term_link',             [ $this, 'custom_term_link' ], 10, 3 );
        add_filter( 'query_vars',            [ $this, 'add_query_vars' ] );
        add_action( 'template_redirect',     [ $this, 'handle_custom_urls' ] );
    }

    public function add_rules() {
        // Grade/Subject/Strand/Term/Week → resource archive
        // e.g. /grade-4/english/writing/term-1/week-3/
        add_rewrite_rule(
            '^([^/]+)/([^/]+)/([^/]+)/([^/]+)/([^/]+)/?$',
            'index.php?shve_grade=$matches[1]&shve_subject=$matches[2]&shve_strand=$matches[3]&shve_term=$matches[4]&shve_week=$matches[5]&shve_resource_archive=1',
            'top'
        );

        // Grade/Subject/Term
        add_rewrite_rule(
            '^([^/]+)/([^/]+)/([^/]+)/?$',
            'index.php?shve_grade=$matches[1]&shve_subject=$matches[2]&shve_term=$matches[3]&shve_resource_archive=1',
            'top'
        );
    }

    public function add_query_vars( $vars ) {
        $vars[] = 'shve_resource_archive';
        return $vars;
    }

    public function handle_custom_urls() {
        if ( ! get_query_var( 'shve_resource_archive' ) ) return;

        $grade   = get_query_var( 'shve_grade' );
        $subject = get_query_var( 'shve_subject' );
        $strand  = get_query_var( 'shve_strand' );
        $term    = get_query_var( 'shve_term' );
        $week    = get_query_var( 'shve_week' );

        $args = [
            'post_type'      => [ 'shve_lesson_note', 'shve_lesson_plan', 'shve_assessment', 'shve_revision', 'shve_worksheet', 'shve_learner_res' ],
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'tax_query'      => [ 'relation' => 'AND' ],
        ];

        if ( $grade )   $args['tax_query'][] = [ 'taxonomy' => 'shve_grade',   'field' => 'slug', 'terms' => $grade ];
        if ( $subject ) $args['tax_query'][] = [ 'taxonomy' => 'shve_subject', 'field' => 'slug', 'terms' => $subject ];
        if ( $strand )  $args['tax_query'][] = [ 'taxonomy' => 'shve_strand',  'field' => 'slug', 'terms' => $strand ];
        if ( $term )    $args['tax_query'][] = [ 'taxonomy' => 'shve_term',    'field' => 'slug', 'terms' => $term ];
        if ( $week )    $args['tax_query'][] = [ 'taxonomy' => 'shve_week',    'field' => 'slug', 'terms' => $week ];

        $GLOBALS['shve_archive_query'] = new WP_Query( $args );

        include SHVE_PLUGIN_DIR . 'templates/frontend/resource-archive.php';
        exit;
    }

    public function custom_permalink( $url, $post ) {
        $shve_types = [
            'shve_lesson_note', 'shve_lesson_plan', 'shve_assessment',
            'shve_revision', 'shve_worksheet', 'shve_learner_res',
        ];
        if ( ! in_array( $post->post_type, $shve_types, true ) ) return $url;

        $grade_terms   = get_the_terms( $post->ID, 'shve_grade' );
        $subject_terms = get_the_terms( $post->ID, 'shve_subject' );
        $strand_terms  = get_the_terms( $post->ID, 'shve_strand' );
        $term_terms    = get_the_terms( $post->ID, 'shve_term' );
        $week_terms    = get_the_terms( $post->ID, 'shve_week' );

        if ( $grade_terms && ! is_wp_error( $grade_terms ) && $subject_terms && ! is_wp_error( $subject_terms ) ) {
            $grade   = $grade_terms[0]->slug;
            $subject = $subject_terms[0]->slug;
            $strand  = ( $strand_terms && ! is_wp_error( $strand_terms ) ) ? $strand_terms[0]->slug : 'general';
            $term    = ( $term_terms && ! is_wp_error( $term_terms ) ) ? $term_terms[0]->slug : 'all';
            $week    = ( $week_terms && ! is_wp_error( $week_terms ) ) ? $week_terms[0]->slug : '';

            $path = trailingslashit( home_url() ) . implode( '/', array_filter( [ $grade, $subject, $strand, $term, $week, $post->post_name ] ) ) . '/';
            return $path;
        }

        return $url;
    }

    public function custom_term_link( $link, $term, $taxonomy ) {
        if ( $taxonomy === 'shve_grade' ) {
            return trailingslashit( home_url() ) . $term->slug . '/';
        }
        return $link;
    }
}
